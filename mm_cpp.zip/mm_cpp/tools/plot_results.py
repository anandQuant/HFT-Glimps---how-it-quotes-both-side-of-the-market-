"""plot_results.py - draws the three CSV files that mm_sim writes (mm_summary.csv, mm_daily.csv, mm_equity.csv).

    python tools/plot_results.py [folder_with_the_csv_files] [--show "A-S"]

Saves mm_results.png next to the CSV files (and opens a window if your Python can).
Needs: pandas, matplotlib   (pip install pandas matplotlib)
"""
import os
import sys

import pandas as pd
import matplotlib

args = [a for a in sys.argv[1:] if not a.startswith("--")]
folder = args[0] if args else "."
show = "A-S"
if "--show" in sys.argv:
    show = sys.argv[sys.argv.index("--show") + 1]
if os.environ.get("MPLBACKEND") is None and not os.environ.get("DISPLAY") and os.name != "nt":
    matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

eq = pd.read_csv(os.path.join(folder, "mm_equity.csv"), parse_dates=["utc_time"])
daily = pd.read_csv(os.path.join(folder, "mm_daily.csv"))
summ = pd.read_csv(os.path.join(folder, "mm_summary.csv"))
names = [c[:-4] for c in eq.columns if c.endswith(" net")]
main = [n for n in names if " dec " not in n and " lat " not in n]

fig, ax = plt.subplots(2, 2, figsize=(15, 9))
for n in main:
    ax[0, 0].plot(eq["utc_time"], eq[n + " net"], label=n, lw=1.2)
ax[0, 0].set_title("Net profit over time ($, after fees)")
ax[0, 0].legend(fontsize=8)
ax[0, 0].grid(alpha=.3)

if show + " inv" not in eq.columns:
    show = main[0]
ax[0, 1].plot(eq["utc_time"], eq[show + " inv"], lw=.8, color="tab:orange")
ax[0, 1].axhline(0, color="k", lw=.5)
ax[0, 1].set_title(f"Inventory of '{show}' (units, long > 0)")
ax[0, 1].grid(alpha=.3)

dd = daily.set_index("day")
dd[[c for c in dd.columns if c in main]].plot.bar(ax=ax[1, 0], width=.8)
ax[1, 0].set_title("Profit per trading day ($)")
ax[1, 0].legend(fontsize=8)
ax[1, 0].grid(alpha=.3, axis="y")

m = summ[summ["strategy"].isin(main)].set_index("strategy")
x = range(len(m))
ax[1, 1].bar([i - .2 for i in x], m["spread_capture"], width=.2, label="at the fill")
ax[1, 1].bar([i for i in x], m["mo1"], width=.2, label="1 s later")
ax[1, 1].bar([i + .2 for i in x], m["mo5"], width=.2, label="5 s later")
ax[1, 1].set_xticks(list(x))
ax[1, 1].set_xticklabels(m.index, rotation=20, fontsize=8)
ax[1, 1].axhline(0, color="k", lw=.5)
ax[1, 1].set_title("Markout: ticks earned per fill, measured at the fill and 1 s / 5 s later\n(if it falls to or below 0 later, we were picked off)")
ax[1, 1].legend(fontsize=8)
ax[1, 1].grid(alpha=.3, axis="y")

plt.tight_layout()
out = os.path.join(folder, "mm_results.png")
plt.savefig(out, dpi=110)
print("saved", out)
if matplotlib.get_backend().lower() != "agg":
    plt.show()
