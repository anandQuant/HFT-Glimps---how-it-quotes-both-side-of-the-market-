"""
Parity check: the same file through the Python/Numba engine and the C++ engine; the fill logs must match exactly.
Usage:  python tools/parity.py <file.mbo> <path to mm_sim executable> [--hours]
Needs numpy, pandas, numba (pip install -r reference_python/requirements.txt).
The Python reference is looked up in ../reference_python (or the folder in the MM_PY_DIR variable).
"""
import os, subprocess, sys, tempfile
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PYDIR = os.environ.get("MM_PY_DIR") or os.path.join(HERE, "..", "reference_python")
if not os.path.isdir(PYDIR):
    PYDIR = os.path.join(HERE, "..", "..", "mm_sim")
sys.path.insert(0, PYDIR)
path, exe = sys.argv[1], sys.argv[2]
use_hours = "--hours" in sys.argv
sys.argv = [sys.argv[0]]
import mm_backtest as B                                   # noqa: E402  (the Python runner; its settings are module variables)

B.TRADE_HOURS_UTC = (13.5, 20.0) if use_hours else None
st, fl, names, t0, nsec, done, secs = B.run_engine(path)
R = B.analyse(st, fl, names, t0, nsec)
S = R["summary"]

out = tempfile.mkdtemp()
cmd = [exe, path, "--out", out, "--dump-fills", os.path.join(out, "fills.csv"), "--quiet"] + ([] if use_hours else ["--allday"])
subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
cf = pd.read_csv(os.path.join(out, "fills.csv"))
cs = pd.read_csv(os.path.join(out, "mm_summary.csv")).set_index("strategy")

bad = 0
for i, n in enumerate(names):
    f = fl[i]
    g = cf[cf.strategy == n]
    same_n = len(g) == len(f["ts"])
    same = same_n and all(np.array_equal(f[k], g[c].to_numpy()) for k, c in
                          (("ts", "ts"), ("side", "side"), ("px", "px"), ("sz", "sz"), ("kind", "kind"), ("mid2", "mid2")))
    num = []
    for col, ccol in (("net", "net"), ("gross", "gross"), ("fees", "fees"), ("fills", "fills"), ("placed", "placed"),
                      ("rejects", "rejects"), ("spread_capture", "spread_capture"), ("mo1", "mo1"), ("mo5", "mo5"),
                      ("mo30", "mo30"), ("avg_inv", "avg_inv"), ("max_inv", "max_inv"), ("win_days", "win_days"),
                      ("worst_day", "worst_day")):
        a, b = float(S.loc[n, col]), float(cs.loc[n, ccol])
        if not (abs(a - b) <= 1e-6 * max(1.0, abs(a)) or (np.isnan(a) and np.isnan(b))):
            num.append(f"{col}: py {a:.6f} vs c++ {b:.6f}")
    ok = same and not num
    bad += 0 if ok else 1
    print(f"{n:<16s} fills py {len(f['ts']):>7,d} c++ {len(g):>7,d} | fill logs {'IDENTICAL' if same else 'DIFFERENT'} | "
          f"summary {'same' if not num else 'DIFF ' + '; '.join(num[:3])}")
print("PARITY:", "OK - the C++ engine reproduces the Python engine exactly" if bad == 0 else f"FAILED for {bad} strategies")
sys.exit(1 if bad else 0)
