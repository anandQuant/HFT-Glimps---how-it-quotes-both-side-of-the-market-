// dbn.hpp - reads Databento DBN files (market-by-order), plain or zstd-compressed, with no outside libraries.
//
// DBN layout (what we need of it):
//   "DBN" + version byte + u32 metadata length, then the metadata (dataset[16], schema u16, start u64, end u64, ...),
//   then records. Every record starts with: length u8 (in 4-byte words), rtype u8, publisher u16, instrument u32,
//   ts_event u64. An MBO record (rtype 0xA0) is 56 bytes:
//     16 order_id u64 | 24 price i64 | 32 size u32 | 36 flags u8 | 37 channel u8 | 38 action u8 | 39 side u8 | 40.. ts_recv ...
#pragma once
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <string>
#include <vector>

#include "common.hpp"
#include "zstd.h"

namespace mm {

struct DbnInfo {
    std::string path, dataset;
    u16 schema = 0xFFFF;
    u8 version = 0;
    u64 start_ns = 0, end_ns = 0;
    bool compressed = false;
    u64 file_bytes = 0;
};

class DbnReader {
public:
    DbnReader() = default;
    DbnReader(const DbnReader&) = delete;
    DbnReader& operator=(const DbnReader&) = delete;
    ~DbnReader() { close(); }

    // path: a DBN file (.dbn or .dbn.zst) or a folder (then the largest data file in it is used).
    bool open(const std::string& path_in, std::string& err) {
        close();
        namespace fs = std::filesystem;
        std::string path = path_in;
        std::error_code ec;
        if (fs::is_directory(path, ec)) {
            u64 best = 0;
            std::string pick;
            for (auto& e : fs::directory_iterator(path, ec)) {
                if (!e.is_regular_file()) continue;
                std::string ext = e.path().extension().string();
                for (auto& c : ext) c = (char)std::tolower((unsigned char)c);
                if (ext == ".json" || ext == ".txt" || ext == ".md") continue;
                u64 sz = (u64)e.file_size();
                if (sz > best) {
                    best = sz;
                    pick = e.path().string();
                }
            }
            if (pick.empty()) {
                err = "no data file found in folder " + path;
                return false;
            }
            std::printf("Using the largest file in the folder: %s\n", pick.c_str());
            path = pick;
        }
        f_ = std::fopen(path.c_str(), "rb");
        if (!f_) {
            err = "cannot open " + path;
            return false;
        }
        info_.path = path;
        info_.file_bytes = (u64)fs::file_size(path, ec);
        unsigned char magic[4] = {0, 0, 0, 0};
        size_t got = std::fread(magic, 1, 4, f_);
        std::fseek(f_, 0, SEEK_SET);
        if (got < 4) {
            err = "file is too short";
            return false;
        }
        if (magic[0] == 0x28 && magic[1] == 0xB5 && magic[2] == 0x2F && magic[3] == 0xFD) {
            info_.compressed = true;
            dctx_ = ZSTD_createDCtx();
            in_.resize(1 << 20);
        } else if (!(magic[0] == 'D' && magic[1] == 'B' && magic[2] == 'N')) {
            err = "not a DBN file (no DBN or zstd header): " + path;
            return false;
        }
        buf_.resize(8 << 20);
        // metadata
        if (!ensure(8)) {
            err = "truncated DBN header";
            return false;
        }
        const u8* h = buf_.data() + pos_;
        info_.version = h[3];
        u32 mlen;
        std::memcpy(&mlen, h + 4, 4);
        if (mlen < 50 || mlen > (64u << 20)) {
            err = "implausible DBN metadata length";
            return false;
        }
        if (!ensure(8 + (size_t)mlen)) {
            err = "truncated DBN metadata";
            return false;
        }
        const u8* m = buf_.data() + pos_ + 8;
        char ds[17] = {0};
        std::memcpy(ds, m, 16);
        info_.dataset = ds;
        std::memcpy(&info_.schema, m + 16, 2);
        std::memcpy(&info_.start_ns, m + 18, 8);
        std::memcpy(&info_.end_ns, m + 26, 8);
        pos_ += 8 + mlen;
        return true;
    }

    // Reads up to `max` MBO records (all instruments). Returns how many were read; 0 at the end of the file.
    size_t read(Msg* out, size_t max) {
        size_t n = 0;
        while (n < max) {
            if (!ensure(1)) break;
            size_t len = (size_t)buf_[pos_] * 4;
            if (len < 16) {                  // corrupt or padding
                ++bad_;
                pos_ += 1;
                continue;
            }
            if (!ensure(len)) break;
            const u8* r = buf_.data() + pos_;
            if (r[1] == 0xA0 && len >= 56) {
                Msg& m = out[n++];
                u32 inst, sz;
                u64 ts, oid;
                i64 px;
                std::memcpy(&inst, r + 4, 4);
                std::memcpy(&ts, r + 8, 8);
                std::memcpy(&oid, r + 16, 8);
                std::memcpy(&px, r + 24, 8);
                std::memcpy(&sz, r + 32, 4);
                m.ts = (i64)ts;
                m.oid = oid;
                m.px = px;
                m.sz = sz;
                m.inst = inst;
                m.flags = r[36];
                m.action = r[38];
                m.side = r[39];
                m.pad = 0;
            } else {
                ++skipped_;
            }
            pos_ += len;
            ++records_;
        }
        return n;
    }

    const DbnInfo& info() const { return info_; }
    u64 records() const { return records_; }
    u64 skipped() const { return skipped_; }
    u64 decoded_bytes() const { return decoded_; }
    u64 file_bytes_read() const { return file_read_; }

    void close() {
        if (f_) std::fclose(f_);
        f_ = nullptr;
        if (dctx_) ZSTD_freeDCtx(dctx_);
        dctx_ = nullptr;
    }

private:
    // make sure at least n bytes are available at pos_; false if the file ends first
    bool ensure(size_t n) {
        while (end_ - pos_ < n) {
            if (pos_ > 0) {                 // compact
                std::memmove(buf_.data(), buf_.data() + pos_, end_ - pos_);
                end_ -= pos_;
                pos_ = 0;
            }
            if (n > buf_.size()) buf_.resize(n * 2);
            if (!refill()) return end_ - pos_ >= n;
        }
        return true;
    }

    bool refill() {
        if (!info_.compressed) {
            size_t got = std::fread(buf_.data() + end_, 1, buf_.size() - end_, f_);
            file_read_ += got;
            decoded_ += got;
            end_ += got;
            return got > 0;
        }
        for (;;) {
            if (in_pos_ >= in_end_ && !eof_) {
                in_end_ = std::fread(in_.data(), 1, in_.size(), f_);
                file_read_ += in_end_;
                in_pos_ = 0;
                if (in_end_ == 0) eof_ = true;
            }
            if (in_pos_ >= in_end_) return false;
            ZSTD_inBuffer ib{in_.data(), in_end_, in_pos_};
            ZSTD_outBuffer ob{buf_.data(), buf_.size(), end_};
            size_t rc = ZSTD_decompressStream(dctx_, &ob, &ib);
            if (ZSTD_isError(rc)) {
                std::fprintf(stderr, "zstd error: %s\n", ZSTD_getErrorName(rc));
                eof_ = true;
                in_pos_ = in_end_ = 0;
                return false;
            }
            in_pos_ = ib.pos;
            size_t got = ob.pos - end_;
            end_ = ob.pos;
            decoded_ += got;
            if (got > 0) return true;
        }
    }

    FILE* f_ = nullptr;
    ZSTD_DCtx* dctx_ = nullptr;
    std::vector<unsigned char> in_;
    size_t in_pos_ = 0, in_end_ = 0;
    bool eof_ = false;
    std::vector<unsigned char> buf_;
    size_t pos_ = 0, end_ = 0;
    DbnInfo info_;
    u64 records_ = 0, skipped_ = 0, bad_ = 0, decoded_ = 0, file_read_ = 0;
};

}  // namespace mm
