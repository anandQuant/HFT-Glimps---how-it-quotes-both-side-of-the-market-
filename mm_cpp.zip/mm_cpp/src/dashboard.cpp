// dashboard.cpp - "mm_sim replay": watch the market and our orders in the terminal, the way a trading desk screen looks.
//
// What is on the screen (top to bottom):
//   PIPELINE   one market message travels  FEED -> BOOK -> SIGNALS -> STRATEGY -> GATEWAY -> EXCHANGE QUEUE -> FILLS,
//              with live counters and the time our code needs for each stage
//   LADDER     the real order book, price by price, with our orders and how many orders stand ahead of us
//   TAPE       the last market messages (trades, adds, cancels, modifies)
//   ORDERS     the life of OUR orders: sent -> arrives (after the latency) -> queued -> filled / cancelled / rejected
//   STRATEGIES all strategies side by side: inventory, fills and money
//   SIGNALS    volatility, fill-rate curve, order-flow imbalance
//   LATENCY    histogram of the time our code needs per market message
// It is a REPLAY of recorded data, driven by the same engine as the backtest (so what you see is what was simulated).
#include "dashboard.hpp"

#include <csignal>
#include <deque>
#include <thread>

#include "backtest.hpp"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <conio.h>
#include <windows.h>
#else
#include <poll.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#endif

namespace mm {
namespace {

// ------------------------------------------------------------------------------------------------
// terminal access
// ------------------------------------------------------------------------------------------------
struct Term {
    bool interactive = false;
    int cols = 120, rows = 45;
#ifndef _WIN32
    termios saved{};
    bool have_saved = false;
#else
    DWORD saved_mode = 0;
    UINT saved_cp = 0;
#endif
    void init(bool want_interactive) {
        interactive = want_interactive;
#ifdef _WIN32
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD mode = 0;
        if (GetConsoleMode(h, &mode)) {
            saved_mode = mode;
            if (interactive) SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
            saved_cp = GetConsoleOutputCP();
            SetConsoleOutputCP(CP_UTF8);
        }
#else
        if (interactive && isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &saved) == 0) {
            have_saved = true;
            termios raw = saved;
            raw.c_lflag &= ~(ICANON | ECHO);
            raw.c_cc[VMIN] = 0;
            raw.c_cc[VTIME] = 0;
            tcsetattr(STDIN_FILENO, TCSANOW, &raw);
        }
#endif
        refresh_size();
    }
    void refresh_size() {
#ifdef _WIN32
        CONSOLE_SCREEN_BUFFER_INFO info;
        if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info)) {
            cols = info.srWindow.Right - info.srWindow.Left + 1;
            rows = info.srWindow.Bottom - info.srWindow.Top + 1;
        }
#else
        winsize w{};
        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &w) == 0 && w.ws_col > 0) {
            cols = w.ws_col;
            rows = w.ws_row;
        }
#endif
    }
    int key() {            // -1 if no key is waiting
        if (!interactive) return -1;
#ifdef _WIN32
        if (_kbhit()) return _getch();
        return -1;
#else
        if (!have_saved) return -1;
        pollfd p{STDIN_FILENO, POLLIN, 0};
        if (poll(&p, 1, 0) > 0) {
            unsigned char c;
            if (read(STDIN_FILENO, &c, 1) == 1) return c;
        }
        return -1;
#endif
    }
    void restore() {
#ifdef _WIN32
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        if (saved_mode) SetConsoleMode(h, saved_mode);
        if (saved_cp) SetConsoleOutputCP(saved_cp);
#else
        if (have_saved) tcsetattr(STDIN_FILENO, TCSANOW, &saved);
        have_saved = false;
#endif
    }
};
Term* g_term = nullptr;
volatile std::sig_atomic_t g_stop = 0;
void on_signal(int) { g_stop = 1; }

// ------------------------------------------------------------------------------------------------
// styling
// ------------------------------------------------------------------------------------------------
struct Style {
    const char *R = "", *B = "", *D = "", *RED = "", *GRN = "", *YEL = "", *BLU = "", *CYN = "", *MAG = "", *REV = "";
    explicit Style(bool on) {
        if (!on) return;
        R = "\x1b[0m"; B = "\x1b[1m"; D = "\x1b[2m"; RED = "\x1b[31m"; GRN = "\x1b[32m"; YEL = "\x1b[33m";
        BLU = "\x1b[34m"; CYN = "\x1b[36m"; MAG = "\x1b[35m"; REV = "\x1b[7m";
    }
};

struct Glyphs {
    std::string h, v, tl, tr, bl, br, full, half, shade, arrow, up, dn, dot;
    std::vector<std::string> spark;
    explicit Glyphs(bool ascii) {
        if (ascii) {
            h = "-"; v = "|"; tl = "+"; tr = "+"; bl = "+"; br = "+"; full = "#"; half = "="; shade = "."; arrow = ">"; up = "^"; dn = "v"; dot = "*";
            spark = {" ", ".", ":", "-", "=", "+", "*", "#"};
        } else {
            h = "─"; v = "│"; tl = "┌"; tr = "┐"; bl = "└"; br = "┘"; full = "█"; half = "▌"; shade = "░"; arrow = "►"; up = "▲"; dn = "▼"; dot = "●";
            spark = {"▁", "▂", "▃", "▄", "▅", "▆", "▇", "█"};
        }
    }
};

// visible width of a string: UTF-8 code points, ignoring ANSI escape sequences
size_t vlen(const std::string& s) {
    size_t n = 0;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = (unsigned char)s[i];
        if (c == 0x1b) {
            while (i < s.size() && s[i] != 'm') ++i;
            ++i;
            continue;
        }
        if ((c & 0xC0) != 0x80) ++n;
        ++i;
    }
    return n;
}

// pad or cut to exactly w visible columns
std::string fit(const std::string& s, size_t w, const Style& st) {
    size_t n = vlen(s);
    if (n <= w) return s + std::string(w - n, ' ');
    std::string out;
    size_t cnt = 0;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = (unsigned char)s[i];
        if (c == 0x1b) {
            size_t j = i;
            while (j < s.size() && s[j] != 'm') ++j;
            out.append(s, i, j - i + 1);
            i = j + 1;
            continue;
        }
        if ((c & 0xC0) != 0x80) {
            if (cnt == w) break;
            ++cnt;
        }
        out += s[i++];
    }
    out += st.R;
    return out;
}

std::string repeat(const std::string& s, size_t n) {
    std::string o;
    for (size_t i = 0; i < n; ++i) o += s;
    return o;
}

// a box with a title, exactly w columns x h lines
std::vector<std::string> make_box(const std::string& title, const std::vector<std::string>& lines, size_t w, size_t h,
                                  const Style& st, const Glyphs& g) {
    std::vector<std::string> out;
    std::string t = " " + title + " ";
    size_t tl = vlen(t);
    std::string top = g.tl + g.h + std::string(st.B) + st.CYN + t + st.R + repeat(g.h, w > tl + 3 ? w - tl - 3 : 0) + g.tr;
    out.push_back(fit(top, w, st));
    for (size_t i = 0; i + 2 < h; ++i) {
        std::string ln = i < lines.size() ? lines[i] : "";
        out.push_back(g.v + fit(ln, w - 2, st) + st.R + g.v);
    }
    out.push_back(g.bl + repeat(g.h, w - 2) + g.br);
    return out;
}

std::vector<std::string> side_by_side(const std::vector<std::vector<std::string>>& cols) {
    size_t h = 0;
    for (auto& c : cols) h = std::max(h, c.size());
    std::vector<std::string> out(h);
    for (auto& c : cols)
        for (size_t i = 0; i < h; ++i) out[i] += i < c.size() ? c[i] : "";
    return out;
}

std::string f1(double x, int nd = 1) {
    char b[48];
    std::snprintf(b, sizeof b, "%.*f", nd, x);
    return b;
}
std::string sgn(double x, int nd = 0) {
    char b[48];
    std::snprintf(b, sizeof b, "%+.*f", nd, x);
    return b;
}
std::string money(double x) {
    std::string s = fmt(std::fabs(x), 0);
    return (x < 0 ? "-$" : "+$") + s;
}
std::string lat_str(double ns) {
    char b[32];
    if (ns < 1000) std::snprintf(b, sizeof b, "%.0f ns", ns);
    else if (ns < 1e6) std::snprintf(b, sizeof b, "%.1f us", ns / 1e3);
    else std::snprintf(b, sizeof b, "%.1f ms", ns / 1e6);
    return b;
}

// ------------------------------------------------------------------------------------------------
// the replay
// ------------------------------------------------------------------------------------------------
struct TapeRow {
    i64 ts;
    u8 action, side;
    i64 px;
    u32 sz;
};

class Feed {                 // sequential reader over the messages of the chosen instrument
public:
    Feed(Session& s, size_t first_n) : S(s), n_(first_n) { buf_ = S.first.data(); }
    const Msg* peek() {
        for (;;) {
            if (pos_ >= n_) {
                if (!refill()) return nullptr;
            }
            const Msg* m = &buf_[pos_];
            if ((i64)m->inst == (i64)S.target.id) return m;
            ++pos_;
        }
    }
    void next() { ++pos_; ++consumed_; }
    u64 consumed() const { return consumed_; }
    bool eof() const { return eof_; }

private:
    bool refill() {
        if (eof_) return false;
        more_.resize(1 << 16);
        n_ = S.reader.read(more_.data(), more_.size());
        buf_ = more_.data();
        pos_ = 0;
        if (n_ == 0) {
            eof_ = true;
            return false;
        }
        return true;
    }
    Session& S;
    const Msg* buf_ = nullptr;
    std::vector<Msg> more_;
    size_t n_ = 0, pos_ = 0;
    u64 consumed_ = 0;
    bool eof_ = false;
};

template <class T>
struct Ring {
    std::vector<T> v;
    size_t head = 0, count = 0;
    explicit Ring(size_t cap = 128) : v(cap) {}
    void push(const T& x) {
        v[head] = x;
        head = (head + 1) % v.size();
        if (count < v.size()) ++count;
    }
    const T& back(size_t k) const { return v[(head + v.size() - 1 - k) % v.size()]; }   // k = 0: newest
};

class Replay {
public:
    Replay(Session& S, const Settings& cfg, std::vector<Params> strategies)
        : S_(S), cfg_(cfg), feed_(S, S.first_n), style_(!cfg.no_color && !cfg.plain), glyph_(cfg.ascii), tape_(64) {
        i64 tick_fx = (i64)std::llround(cfg.tick * 1e9);
        eng_ = std::make_unique<Engine>(strategies, to_config(cfg), S.t0, S.nsec, tick_fx, (i64)S.target.id, false);
        eng_->enable_trace(16384);
        eng_->prof = true;
        sel_ = 0;
        for (size_t i = 0; i < eng_->S.size(); ++i)
            if (eng_->S[i].p.name == cfg.show) sel_ = i;
        net_hist_.assign(eng_->S.size(), Ring<double>(120));
        inv_hist_.assign(eng_->S.size(), Ring<double>(120));
        decimals_ = 0;
        for (int t = 0; t < 7; ++t) {
            double v = cfg.tick * std::pow(10.0, t);
            if (std::fabs(v - std::round(v)) < 1e-9) {
                decimals_ = t;
                break;
            }
        }
        speeds_ = {0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 100, 300, 1000, 0};
        speed_i_ = 5;
        double best = 1e18;
        for (size_t i = 0; i < speeds_.size(); ++i) {
            double d = std::fabs(std::log((speeds_[i] > 0 ? speeds_[i] : 1e6) / (cfg.speed > 0 ? cfg.speed : 1e6)));
            if (d < best) {
                best = d;
                speed_i_ = i;
            }
        }
        const Msg* m = feed_.peek();
        sim_clock_ = m ? m->ts : S.t0;
        wall_start_ = now_sec();
    }

    Engine& engine() { return *eng_; }
    bool finished() const { return finished_; }
    i64 sim_clock() const { return sim_clock_; }

    // advance the market up to `until_ns` (market time), or for wall_budget seconds in max-speed mode
    void advance(i64 until_ns, bool unlimited, double wall_budget) {
        double deadline = now_sec() + wall_budget;
        u64 n = 0;
        for (;;) {
            const Msg* m = feed_.peek();
            if (!m) {
                finished_ = true;
                break;
            }
            if (!unlimited && m->ts > until_ns) break;
            eng_->on_msg(*m);
            if (m->action == 84 || m->action == 65 || m->action == 67 || m->action == 77)
                tape_.push(TapeRow{m->ts, m->action, m->side, m->px, m->sz});
            last_ts_ = m->ts;
            if (eng_->bb >= 0 && eng_->ba < NT && eng_->bb < eng_->ba) {
                last_mid2_ = (double)(eng_->bb + eng_->ba);
                disp_bb_ = eng_->bb;
                disp_ba_ = eng_->ba;
            }
            i64 s = floordiv(m->ts, NS_PER_SEC);
            if (s != last_sample_sec_) sample(s);
            feed_.next();
            ++n;
            if ((n & 1023) == 0 && now_sec() > deadline) break;
        }
        total_msgs_ = feed_.consumed();
        if (last_ts_ > sim_clock_ || unlimited) sim_clock_ = std::max(sim_clock_, last_ts_);
    }

    void frame_step(double wall_dt) {
        double speed = speeds_[speed_i_];
        if (paused_ || finished_) return;
        if (speed <= 0) {                                   // as fast as possible: use most of the frame for the engine
            advance(0, true, 0.035);
            return;
        }
        i64 target = sim_clock_ + (i64)(speed * wall_dt * 1e9);
        const Msg* m = feed_.peek();
        idle_skip_ = false;
        if (m && m->ts - sim_clock_ > 3 * NS_PER_SEC && m->ts > target) {     // nothing happens for seconds: jump ahead
            target = m->ts - NS_PER_SEC;
            if (target > sim_clock_) {
                sim_clock_ = target;
                idle_skip_ = true;
            }
        } else {
            advance(target, false, 0.035);
            if (!feed_.peek()) finished_ = true;
            else if (feed_.peek()->ts > target) sim_clock_ = std::max(sim_clock_, target);
        }
    }

    void skip_to(i64 ts_ns) {                 // process everything up to ts_ns at full speed (no drawing)
        advance(ts_ns, false, 1e9);
        sim_clock_ = std::max(sim_clock_, ts_ns);
        if (!feed_.peek()) finished_ = true;
    }

    // keys: returns false to quit
    bool on_key(int k) {
        if (k < 0) return true;
        if (k == 'q' || k == 'Q' || k == 27 || k == 3) return false;
        if (k == ' ') paused_ = !paused_;
        else if (k == '+' || k == '=') speed_i_ = std::min(speed_i_ + 1, speeds_.size() - 1);
        else if (k == '-' || k == '_') speed_i_ = speed_i_ > 0 ? speed_i_ - 1 : 0;
        else if (k == '0') speed_i_ = speeds_.size() - 1;
        else if (k == '1') speed_i_ = 5;
        else if (k == 's' || k == 'S' || k == '\t') sel_ = (sel_ + 1) % eng_->S.size();
        else if (k == 'f' || k == 'F') skip_to(sim_clock_ + 60 * NS_PER_SEC);
        else if (k == 'g' || k == 'G') skip_to(sim_clock_ + 600 * NS_PER_SEC);
        return true;
    }

    std::vector<std::string> render(int term_cols);

private:
    void sample(i64 s) {
        last_sample_sec_ = s;
        for (size_t i = 0; i < eng_->S.size(); ++i) {
            net_hist_[i].push(net_usd(i));
            inv_hist_[i].push((double)eng_->S[i].acc.q);
        }
    }

    double mid_ticks() const { return last_mid2_ / 2.0; }
    double gross_usd(size_t i) const {
        const Acc& a = eng_->S[i].acc;
        return ((double)a.cash + (double)a.q * mid_ticks()) * cfg_.tick_value;
    }
    double net_usd(size_t i) const { return gross_usd(i) - cfg_.fee * (double)eng_->S[i].acc.vol; }
    std::string px(i64 ticks) const { return f1((double)ticks * cfg_.tick, decimals_); }
    std::string spark(const Ring<double>& r, size_t w, double lo, double hi) const {
        std::string out;
        size_t n = std::min(w, r.count);
        for (size_t k = n; k-- > 0;) {
            double v = r.back(k);
            double t = hi > lo ? (v - lo) / (hi - lo) : 0.5;
            int idx = (int)std::floor(t * 7.999);
            idx = std::max(0, std::min(7, idx));
            out += glyph_.spark[(size_t)idx];
        }
        return out;
    }
    std::string bar(double frac, size_t w) const {
        size_t n = (size_t)std::round(std::max(0.0, std::min(1.0, frac)) * (double)w);
        return repeat(glyph_.full, n) + repeat(" ", w - n);
    }

    std::vector<std::string> pipeline_lines();
    std::vector<std::string> ladder_lines();
    std::vector<std::string> tape_lines(size_t n);
    std::vector<std::string> orders_lines(size_t n);
    std::vector<std::string> strategies_lines();
    std::vector<std::string> signals_lines();
    std::vector<std::string> latency_lines();

    Session& S_;
    const Settings& cfg_;
    Feed feed_;
    Style style_;
    Glyphs glyph_;
    std::unique_ptr<Engine> eng_;
    Ring<TapeRow> tape_;
    std::vector<Ring<double>> net_hist_, inv_hist_;
    size_t sel_ = 0;
    int decimals_ = 2;
    std::vector<double> speeds_;
    size_t speed_i_ = 5;
    bool paused_ = false, finished_ = false, idle_skip_ = false;
    i64 sim_clock_ = 0, last_ts_ = 0, last_sample_sec_ = INT64_MIN;
    u64 total_msgs_ = 0;
    double last_mid2_ = 0;
    i64 disp_bb_ = -1, disp_ba_ = NT;     // last valid best bid / ask, for display
    double wall_start_ = 0;
    int term_cols_ = 120;
};

// ----------------------------------------------------------------------------------------------
std::vector<std::string> Replay::pipeline_lines() {
    const Style& st = style_;
    const Engine& E = *eng_;
    const Strat& sg = E.S[sel_];
    const DbnReader& rd = S_.reader;
    double wall = std::max(now_sec() - wall_start_, 1e-3);
    double rate = (double)total_msgs_ / wall;
    double mbs = (double)rd.decoded_bytes() / wall / 1e6;
    double pct = rd.info().file_bytes ? 100.0 * (double)rd.file_bytes_read() / (double)rd.info().file_bytes : 0.0;
    i64 bq = -1, aq = -1;
    if (sg.o[0].act == 1) bq = std::max<i64>(sg.o[0].ahead - sg.o[0].cons, 0);
    if (sg.o[1].act == 1) aq = std::max<i64>(sg.o[1].ahead - sg.o[1].cons, 0);
    std::string quote_b = sg.ds[0] >= 0 ? px(sg.ds[0]) : "--", quote_a = sg.ds[1] >= 0 ? px(sg.ds[1]) : "--";
    const char* names[7] = {"FEED", "BOOK", "SIGNALS", "STRATEGY", "GATEWAY", "EXCH QUEUE", "FILLS"};
    std::vector<std::string> c1(7), c2(7), c3(7), c4(7);
    c1[0] = f1(rate / 1e6, 2) + " M msg/s";
    c2[0] = f1(mbs, 0) + " MB/s decoded";
    c3[0] = "file " + f1(pct, 0) + "% read";
    c4[0] = "reader thread";
    c1[1] = fmt((double)E.live_orders()) + " orders";
    c2[1] = "bid " + (E.bb >= 0 ? px(E.bb) : "--");
    c3[1] = "ask " + (E.ba < NT ? px(E.ba) : "--");
    c4[1] = lat_str(E.st_book.pct(0.5)) + " /" + lat_str(E.st_book.pct(0.99));
    c1[2] = "OFI z " + sgn(E.ofiz_last, 1);
    c2[2] = E.calok ? "sigma " + f1(std::sqrt(E.sig2), 2) : "calibrating...";
    c3[2] = E.calok ? "k " + f1(E.K, 2) + " A " + f1(E.A, 1) : "";
    c4[2] = lat_str(E.st_signal.pct(0.5)) + " /" + lat_str(E.st_signal.pct(0.99));
    c1[3] = sg.p.name;
    c2[3] = "bid " + quote_b;
    c3[3] = "ask " + quote_a;
    c4[3] = lat_str(E.st_strat.pct(0.5)) + " /" + lat_str(E.st_strat.pct(0.99));
    c1[4] = "latency " + f1(sg.p.lat_ns / 1e6, 1) + " ms";
    c2[4] = "in flight " + std::to_string(sg.qt - sg.qh);
    c3[4] = "rejects " + std::to_string(sg.acc.reject);
    c4[4] = "simulated";
    c1[5] = "bid ahead " + (bq >= 0 ? std::to_string(bq) : std::string("--"));
    c2[5] = "ask ahead " + (aq >= 0 ? std::to_string(aq) : std::string("--"));
    c3[5] = "queue model";
    c4[5] = "simulated";
    c1[6] = fmt((double)sg.acc.nfill) + " fills";
    c2[6] = "inventory " + sgn((double)sg.acc.q);
    c3[6] = "net " + money(net_usd(sel_));
    c4[6] = "";
    std::vector<std::string> out;
    const size_t CW = 18;
    std::string l1;
    for (int i = 0; i < 7; ++i) {
        std::string name = std::string(st.B) + st.YEL + "[" + names[i] + "]" + st.R;
        size_t nl = std::string(names[i]).size() + 2;
        l1 += name;
        if (i < 6) l1 += st.D + repeat(glyph_.h, CW - nl - 1) + glyph_.arrow + st.R;
    }
    out.push_back(" " + l1);
    auto row = [&](const std::vector<std::string>& c, const char* color) {
        std::string l = " ";
        for (int i = 0; i < 7; ++i) l += fit(std::string(color) + c[(size_t)i] + st.R, CW, st);
        return l;
    };
    out.push_back(row(c1, st.B));
    out.push_back(row(c2, ""));
    out.push_back(row(c3, ""));
    out.push_back(row(c4, st.D));
    return out;
}

std::vector<std::string> Replay::ladder_lines() {
    const Style& st = style_;
    const Engine& E = *eng_;
    const Strat& sg = E.S[sel_];
    std::vector<std::string> out;
    const int L = std::max(3, cfg_.ladder);
    if (!(disp_bb_ >= 0 && disp_ba_ < NT)) {
        out.push_back("  (waiting for a valid book)");
        return out;
    }
    const i64 BB = disp_bb_, BA = disp_ba_;
    // sizes for the bars
    i64 maxsz = 1;
    for (int i = 0; i < L; ++i) {
        if (BA + i < NT) maxsz = std::max(maxsz, E.ask_lvl()[(size_t)(BA + i)]);
        if (BB - i >= 0) maxsz = std::max(maxsz, E.bid_lvl()[(size_t)(BB - i)]);
    }
    // our orders in flight (sent, not arrived yet), selected strategy
    auto pending_at = [&](int sd, i64 price, i64& lands_in_ns) {
        for (i64 k = sg.qh; k < sg.qt; ++k) {
            size_t j = (size_t)(k % QCAP);
            if (sg.pq_k[j] == 1 && sg.pq_side[j] == sd && sg.pq_px[j] == price) {
                lands_in_ns = sg.pq_t[j] - sim_clock_;
                return true;
            }
        }
        return false;
    };
    auto marker = [&](int sd, i64 price) {
        std::string m;
        const VOrder& o = sg.o[sd];
        const char* who = sd == 0 ? "BUY" : "SELL";
        if (o.act == 1 && o.px == price) {
            i64 ahead = std::max<i64>(o.ahead - o.cons, 0);
            m = std::string(st.B) + st.YEL + "<- " + who + " " + std::to_string(o.sz) + " (" + std::to_string(ahead) + " ahead)" + st.R;
        }
        i64 lands = 0;
        if (pending_at(sd, price, lands))
            m += std::string(st.MAG) + (m.empty() ? "<- sent " : " +sent ") + who + " " + f1((double)std::max<i64>(lands, 0) / 1e6, 1) + "ms" + st.R;
        return m;
    };
    auto row = [&](i64 price, i64 size, bool is_ask) {
        const char* pcol = is_ask ? st.RED : st.GRN;
        double frac = (double)size / (double)maxsz;
        std::string sz = size > 0 ? fmt((double)size) : "";
        return " " + std::string(pcol) + st.B + fit(px(price), 9, st) + st.R + " " + fit(sz, 6, st) + " " + pcol +
               fit(size > 0 ? bar(frac, 8) : "", 8, st) + st.R + " " + marker(is_ask ? 1 : 0, price);
    };
    double qb = (double)E.bid_lvl()[(size_t)BB], qa = (double)E.ask_lvl()[(size_t)BA];
    double imb = (qb - qa) / std::max(qb + qa, 1.0);
    out.push_back(std::string(st.D) + " spread " + std::to_string(BA - BB) + " tick   mid " + f1((double)(BA + BB) / 2.0 * cfg_.tick, decimals_ + 1) +
                  "   imbalance " + sgn(imb, 2) + st.R);
    for (int i = L - 1; i >= 0; --i) out.push_back(row(BA + i, E.ask_lvl()[(size_t)(BA + i)], true));
    // empty price rows inside the spread: our quotes can sit there (at most 5 lines)
    const i64 gap = BA - BB - 1;
    if (gap > 0) {
        std::string sep = std::string(st.D) + " " + repeat(glyph_.h, 3) + " inside the spread " + repeat(glyph_.h, 3) + st.R;
        out.push_back(sep);
        if (gap <= 4) {
            for (i64 p = BA - 1; p > BB; --p) out.push_back(row(p, 0, false));
        } else {
            out.push_back(row(BA - 1, 0, true));
            out.push_back(row(BA - 2, 0, true));
            out.push_back(std::string(st.D) + "   ... " + std::to_string(gap - 4) + " empty ticks ..." + st.R);
            out.push_back(row(BB + 2, 0, false));
            out.push_back(row(BB + 1, 0, false));
        }
    } else {
        out.push_back(std::string(st.D) + " " + repeat(glyph_.h, 12) + " touch " + repeat(glyph_.h, 12) + st.R);
    }
    for (int i = 0; i < L; ++i) out.push_back(row(BB - i, BB - i >= 0 ? E.bid_lvl()[(size_t)(BB - i)] : 0, false));
    return out;
}

std::vector<std::string> Replay::tape_lines(size_t n) {
    const Style& st = style_;
    std::vector<std::string> out;
    for (size_t k = 0; k < std::min(n, tape_.count); ++k) {
        const TapeRow& r = tape_.back(k);
        std::string t = fmt_time(r.ts, false, 3);
        std::string what, col;
        if (r.action == 84) {
            what = r.side == 65 ? "!SELL" : "!BUY ";
            col = std::string(st.B) + (r.side == 65 ? st.RED : st.GRN);
        } else {
            what = std::string(r.action == 65 ? "+" : (r.action == 67 ? "-" : "~")) + (r.side == 66 ? "bid " : "ask ");
            col = st.D;
        }
        std::string line = " " + std::string(st.D) + t.substr(0, 12) + st.R + " " + col + fit(what, 5, st) + st.R + " " +
                           fit(std::to_string(r.sz), 3, st) + "@ " + (r.px != UNDEF_PRICE ? px(floordiv(r.px, eng_->tick_fx())) : std::string("--"));
        out.push_back(line);
    }
    return out;
}

std::vector<std::string> Replay::orders_lines(size_t n) {
    const Style& st = style_;
    const Engine& E = *eng_;
    std::vector<std::string> out;
    size_t total = std::min(E.evpos, E.evlog.size());
    for (size_t k = 0; k < total && out.size() < n; ++k) {
        const OrdEv& e = E.evlog[(E.evpos - 1 - k) % E.evlog.size()];
        if (e.strat != sel_) continue;
        std::string t = fmt_time(e.ts, false, 4);
        const char* side = e.side == 0 ? "BUY " : "SELL";
        std::string txt, col;
        switch (e.type) {
            case EV_SEND_PLACE:
                txt = std::string("> SEND ") + side + " " + px(e.px);
                col = st.CYN;
                break;
            case EV_SEND_CANCEL:
                txt = std::string("> CXL  ") + side;
                col = st.CYN;
                break;
            case EV_SEND_FLATTEN:
                txt = std::string("> MKT  ") + side + " x" + std::to_string(e.sz) + " flat";
                col = st.CYN;
                break;
            case EV_QUEUED:
                txt = std::string("+ ACK  ") + side + " " + px(e.px) + " q" + std::to_string(e.aux);
                col = st.D;
                break;
            case EV_REJECT:
                txt = std::string("x REJ  ") + side + " " + px(e.px);
                col = st.RED;
                break;
            case EV_CANCELLED:
                txt = std::string("+ CXL ok ") + side;
                col = st.D;
                break;
            case EV_FILL:
                txt = std::string("* FILL ") + side + " " + px(e.px) + " x" + std::to_string(e.sz);
                col = std::string(st.B) + st.YEL;
                break;
            default:
                txt = std::string("* MKT  ") + side + " " + px(e.px) + " x" + std::to_string(e.sz);
                col = std::string(st.B) + st.YEL;
                break;
        }
        out.push_back(" " + std::string(st.D) + t.substr(0, 13) + st.R + " " + col + txt + st.R);
    }
    return out;
}

std::vector<std::string> Replay::strategies_lines() {
    const Style& st = style_;
    const Engine& E = *eng_;
    std::vector<std::string> out;
    out.push_back(std::string(st.D) + " strategy     inv    fills       gross$      fees$        net$ bid      ask" + st.R);
    for (size_t i = 0; i < E.S.size(); ++i) {
        const Strat& s = E.S[i];
        double net = net_usd(i), gross = gross_usd(i), fees = cfg_.fee * (double)s.acc.vol;
        std::string line = (i == sel_ ? std::string(st.REV) : std::string("")) + (i == sel_ ? ">" : " ") +
                           fit(s.p.name, 11, st) + " " + fit(sgn((double)s.acc.q), 3, st) + " " + fit(fmt((double)s.acc.nfill), 8, st) + " " +
                           fit(money(gross), 11, st) + " " + fit(money(-fees), 10, st) + " " +
                           std::string(net < 0 ? st.RED : st.GRN) + fit(money(net), 11, st) + st.R + (i == sel_ ? st.REV : "") + " " +
                           fit(s.ds[0] >= 0 ? px(s.ds[0]) : "--", 8, st) + " " + fit(s.ds[1] >= 0 ? px(s.ds[1]) : "--", 8, st) + st.R;
        out.push_back(line);
    }
    // sparklines of the selected strategy
    const Ring<double>& nh = net_hist_[sel_];
    double lo = 1e18, hi = -1e18;
    for (size_t k = 0; k < nh.count; ++k) {
        lo = std::min(lo, nh.back(k));
        hi = std::max(hi, nh.back(k));
    }
    out.push_back("");
    out.push_back(" net P&L  " + std::string(st.B) + spark(nh, 48, lo, hi) + st.R + "  " + (nh.count ? money(nh.back(0)) : ""));
    double qm = E.S[sel_].p.qmax;
    out.push_back(" inventory " + std::string(st.B) + spark(inv_hist_[sel_], 48, -qm, qm) + st.R + "  (limit +-" + f1(qm, 0) + ")");
    return out;
}

std::vector<std::string> Replay::signals_lines() {
    const Style& st = style_;
    const Engine& E = *eng_;
    std::vector<std::string> out;
    if (E.calok) {
        out.push_back(" sigma " + f1(std::sqrt(E.sig2), 2) + " tk/rt(s)");
        out.push_back(" A " + f1(E.A, 2) + "/s  k " + f1(E.K, 2));
    } else {
        out.push_back(" calibrating...");
        out.push_back(" (about 2.5 min)");
    }
    out.push_back(" OFI z " + sgn(E.ofiz_last, 1));
    double z = std::max(-4.0, std::min(4.0, E.ofiz_last));
    std::string gauge;
    for (int i = -6; i <= 6; ++i) {
        double pos = i / 1.5;
        bool on = i != 0 && ((z >= 0 && i > 0 && pos <= z + 1e-9) || (z < 0 && i < 0 && pos >= z - 1e-9));
        gauge += i == 0 ? "|" : (on ? glyph_.full : std::string("."));
    }
    const Strat& sg = E.S[sel_];
    out.push_back(" [" + std::string(std::fabs(E.ofiz_last) > sg.p.ofi_z && sg.p.ofi_z > 0 ? st.RED : st.GRN) + gauge + st.R + "]");
    if (sg.p.ofi_z > 0) out.push_back(" pulls at +-" + f1(sg.p.ofi_z, 1));
    else out.push_back(" ignores OFI");
    i64 sod = floormod(floordiv(sim_clock_, NS_PER_SEC), 86400);
    bool inside = cfg_.all_day || ((double)sod >= cfg_.hours_lo * 3600 && (double)sod < cfg_.hours_hi * 3600);
    out.push_back(std::string(" session ") + (inside ? std::string(st.GRN) + "OPEN" : std::string(st.D) + "closed") + st.R);
    return out;
}

std::vector<std::string> Replay::latency_lines() {
    const Style& st = style_;
    const Stat& T = eng_->st_total;
    std::vector<std::string> out;
    if (T.n == 0) {
        out.push_back(" measuring...");
        return out;
    }
    // log2 buckets b: [2^b, 2^(b+1)) ns.  Rows: <128, 128-256, ..., 32us+ merged at both ends
    struct Row { std::string label; u64 cnt; };
    std::vector<Row> rows;
    u64 low = 0;
    for (int b = 0; b <= 6; ++b) low += T.hist[b];
    rows.push_back({"<128ns", low});
    const char* lab[] = {"128-256ns", "256-512ns", "0.5-1us", "1-2us", "2-4us", "4-8us", "8-16us", "16-32us"};
    for (int b = 7; b <= 14; ++b) rows.push_back({lab[b - 7], T.hist[b]});
    u64 high = 0;
    for (int b = 15; b < 20; ++b) high += T.hist[b];
    rows.push_back({">32us", high});
    u64 mx = 1;
    for (auto& r : rows) mx = std::max(mx, r.cnt);
    for (auto& r : rows)
        out.push_back(" " + fit(r.label, 9, st) + st.GRN + bar((double)r.cnt / (double)mx, 10) + st.R + " " + f1(100.0 * (double)r.cnt / (double)T.n, 0) + "%");
    out.push_back(std::string(st.B) + " p50 " + lat_str(T.pct(0.5)) + "  p99 " + lat_str(T.pct(0.99)) + st.R);
    return out;
}

std::vector<std::string> Replay::render(int term_cols) {
    term_cols_ = term_cols;
    const Style& st = style_;
    const Glyphs& g = glyph_;
    const size_t W = 132;
    const int L = std::max(3, cfg_.ladder);
    std::vector<std::string> out;

    // title bar
    {
        double speed = speeds_[speed_i_];
        std::string sp = speed > 0 ? "x" + fmt_g(speed) : "MAX";
        std::string state = finished_ ? "END OF DATA" : (paused_ ? "PAUSED" : (idle_skip_ ? "idle: skipping ahead" : "RUNNING " + sp));
        std::string title = " MM-SIM replay   instrument " + std::to_string(S_.target.id) + "   " + fmt_time(sim_clock_, true, 3) + " UTC";
        std::string right = state + "  ";
        std::string l = std::string(st.REV) + st.B + fit(title, W - right.size(), st) + right + st.R;
        out.push_back(l);
    }
    // pipeline
    auto pl = make_box("PIPELINE: one market message travels left to right (replay of recorded data)", pipeline_lines(), W, 7, st, g);
    out.insert(out.end(), pl.begin(), pl.end());
    // middle row
    size_t mh = (size_t)(2 * L + 8 + 2);
    auto ladder = make_box("ORDER BOOK + " + eng_->S[sel_].p.name + " ORDERS", ladder_lines(), 50, mh, st, g);
    auto tape = make_box("TAPE !trade +add -cxl ~mod", tape_lines(mh - 2), 38, mh, st, g);
    auto ords = make_box("OUR ORDERS (" + eng_->S[sel_].p.name + ")", orders_lines(mh - 2), 44, mh, st, g);
    auto mid = side_by_side({ladder, tape, ords});
    out.insert(out.end(), mid.begin(), mid.end());
    // bottom row
    auto strat = make_box("STRATEGIES (same data, each simulated alone)", strategies_lines(), 80, 12, st, g);
    auto sig = make_box("SIGNALS", signals_lines(), 24, 12, st, g);
    auto lat = make_box("OUR CODE: TIME/MSG", latency_lines(), 28, 12, st, g);
    auto bot = side_by_side({strat, sig, lat});
    out.insert(out.end(), bot.begin(), bot.end());
    out.push_back(std::string(st.B) + " SPACE pause   +/- speed   0 max   1 real time   S next strategy   F +1 min   G +10 min   Q quit" + st.R);
    out.push_back(std::string(st.D) + " Real desks sit next to the exchange (CME Aurora) and read UDP multicast feeds; here the same loop runs on recorded data. "
                  "Latencies shown are this program's own compute time." + st.R);
    return out;
}


// ------------------------------------------------------------------------------------------------
// --from "HH:MM" | "HH:MM:SS" | "YYYY-MM-DD HH:MM[:SS]"  (UTC)
// ------------------------------------------------------------------------------------------------
bool parse_from(const std::string& in, i64 first_ts, i64& out) {
    int y = 0, mo = 0, d = 0, h = 0, mi = 0, se = 0;
    std::string t = in;
    for (auto& c : t)
        if (c == 'T') c = ' ';
    if (std::sscanf(t.c_str(), "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &se) >= 5) {
        out = (days_from_civil(y, mo, d) * 86400 + h * 3600 + mi * 60 + se) * NS_PER_SEC;
        return true;
    }
    h = mi = se = 0;
    if (std::sscanf(t.c_str(), "%d:%d:%d", &h, &mi, &se) >= 2) {
        i64 day0 = floordiv(first_ts, 86400 * NS_PER_SEC) * 86400 * NS_PER_SEC;
        out = day0 + (h * 3600 + mi * 60 + se) * NS_PER_SEC;
        if (out < first_ts) out += 86400 * NS_PER_SEC;
        return true;
    }
    return false;
}

}  // namespace

int run_dashboard(const Settings& cfg) {
    Session S;
    if (!open_session(S, cfg)) {
        std::fprintf(stderr, "%s\n", S.err.c_str());
        return 1;
    }
    auto strategies = strategy_list(cfg, false);
    Replay R(S, cfg, strategies);
    const bool plain = cfg.plain || cfg.frames > 0;
    Term term;
    term.init(!plain);
    g_term = &term;
    std::signal(SIGINT, on_signal);

    if (!cfg.from.empty()) {
        i64 target = 0;
        if (!parse_from(cfg.from, R.sim_clock(), target)) {
            term.restore();
            std::fprintf(stderr, "cannot read --from '%s' (use HH:MM or YYYY-MM-DD HH:MM, UTC)\n", cfg.from.c_str());
            return 2;
        }
        std::fprintf(stderr, "Skipping to %s UTC ...\n", fmt_time(target, true, 0).c_str());
        R.skip_to(target);
    }

    if (plain) {                                   // text frames for logs and tests
        int n = cfg.frames > 0 ? cfg.frames : 1;
        for (int i = 0; i < n && !R.finished(); ++i) {
            R.skip_to(R.sim_clock() + (i64)(cfg.frame_every_s * 1e9));
            std::printf("=== frame %d/%d ===\n", i + 1, n);
            for (auto& l : R.render(132)) std::printf("%s\n", l.c_str());
            std::printf("\n");
        }
        term.restore();
        return 0;
    }

    std::printf("\x1b[2J\x1b[?25l");
    double last = now_sec();
    bool quit = false;
    int frame_no = 0;
    while (!quit && !g_stop) {
        double t0 = now_sec();
        double dt = std::min(t0 - last, 0.25);
        last = t0;
        for (int k; (k = term.key()) >= 0;)
            if (!R.on_key(k)) quit = true;
        if (quit) break;
        R.frame_step(dt);
        if ((frame_no++ % 20) == 0) term.refresh_size();
        std::vector<std::string> lines = R.render(term.cols);
        std::string frame = "\x1b[H";
        if (term.cols < 132 || term.rows < (int)lines.size()) {
            char b[200];
            std::snprintf(b, sizeof b, "Window is %dx%d; this screen needs 132 columns x %d lines. Enlarge the window "
                          "(or use --ladder 4 for fewer rows).", term.cols, term.rows, (int)lines.size());
            frame += std::string(b) + "\x1b[K\n";
        }
        for (auto& l : lines) frame += l + "\x1b[K\n";
        frame += "\x1b[J";
        std::fwrite(frame.data(), 1, frame.size(), stdout);
        std::fflush(stdout);
        double spent = now_sec() - t0;
        if (spent < 0.05) std::this_thread::sleep_for(std::chrono::duration<double>(0.05 - spent));
    }
    std::printf("\x1b[0m\x1b[?25h\n");
    term.restore();
    const Engine& E = R.engine();
    std::printf("Stopped at %s UTC. Per-message time of our code: median %s, p99 %s (sampled).\n",
                fmt_time(R.sim_clock(), true, 0).c_str(), lat_str(E.st_total.pct(0.5)).c_str(), lat_str(E.st_total.pct(0.99)).c_str());
    return 0;
}

}  // namespace mm
