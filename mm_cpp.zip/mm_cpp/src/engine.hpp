// engine.hpp - event-driven market-making simulator on market-by-order (MBO) data.
//
// This is a C++ port of mm_engine.py (Numba). Same rules, same order of operations:
//   * the real order book is rebuilt from every record (A add, C cancel, M modify, R clear; T/F/N leave it alone),
//     and every real order keeps its queue priority (a modify to a new price or a bigger size loses priority);
//   * each strategy places VIRTUAL limit orders on top of the real book:
//       - a new order joins the BACK of the queue at its price: everything already resting there is ahead of it;
//       - orders ahead leave the queue when they are cancelled, filled or lose priority;
//       - a trade at our price fills us only with the volume left after the queue ahead is used up;
//       - a trade at a worse price than ours fills us first (price priority);
//       - every order action reaches the exchange LATENCY later; the old order can still be filled meanwhile;
//       - orders are post-only: one that would cross the book when it arrives is rejected;
//   * strategies: JOIN, AS (Avellaneda-Stoikov 2008), GLFT (Gueant-Lehalle-Fernandez-Tapia 2013), each with an
//     inventory limit and an optional OFI defense (pull the side about to be run over);
//   * sigma, A and k are re-estimated on a rolling window from past data only.
// Units inside the engine: prices in TICKS, time in ns, money in ticks x contracts.
//
// The hot path (on_msg) makes no allocation: every array is sized when the engine is built.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>

#include "common.hpp"
#include "order_map.hpp"

namespace mm {

constexpr int NT = 1 << 20;             // price grid in ticks (NQ 0.25 -> up to ~262,000 points; stocks 0.01 -> $10,485)
constexpr i64 SIZE_CAP = 0x1FFFFF;      // largest size stored per order
constexpr int NB = 6;                   // calibration buckets: trades reaching 0.5, 1.5, ..., 5.5 ticks from the mid
constexpr int QCAP = 256;               // pending order actions per strategy

enum Kind : int { JOIN = 0, AS = 1, GLFT = 2 };
enum FillKind : u8 { MAKER = 0, TAKER = 1 };

struct Params {
    std::string name;
    int kind = JOIN;
    double gamma = 0.05;        // risk aversion per tick; negative = scale-free: |gamma| ticks of shift per unit of inventory
    double horizon_s = 10.0;
    double qmax = 5;            // inventory limit (units)
    double ofi_z = 0.0;         // 0 = OFI defense off
    i64 size = 1;
    double lat_ns = 1e6;        // decision -> exchange delay
    double req = 1;             // only move a live quote if the new price differs by at least this many ticks
    double maxd = 10;           // never quote further than this from the touch
    double dec_ns = 0.0;        // this strategy's own re-quote interval; 0 = use the global one
};

// strategy(): same arguments as the Python helper
inline Params strategy(const std::string& name, Kind kind, double gamma = 0.05, double horizon_s = 10.0, double qmax = 5,
                       double ofi_z = 0.0, i64 size = 1, double latency_ms = 1.0, double requote_ticks = 1,
                       double max_depth_ticks = 10, double skew_ticks = -1.0 /* <0 = unused */, double decision_ms = 0.0) {
    Params p;
    p.name = name;
    p.kind = kind;
    p.gamma = skew_ticks >= 0.0 ? -skew_ticks : gamma;
    p.horizon_s = horizon_s;
    p.qmax = qmax;
    p.ofi_z = ofi_z;
    p.size = size;
    p.lat_ns = latency_ms * 1e6;
    p.req = requote_ticks;
    p.maxd = max_depth_ticks;
    p.dec_ns = decision_ms * 1e6;
    return p;
}

struct Config {
    double dec_ns = 100e6;           // how often a strategy may change its quotes (global default)
    double cal_every = 60;           // seconds between calibrations
    double cal_win = 600;            // calibration window (seconds)
    double ofi_fast = 1000e6;        // ns
    double ofi_slow = 600e9;         // ns
    double th_lo = 13.5 * 3600;      // quote only inside these UTC hours (seconds of the day)
    double th_hi = 20.0 * 3600;
    double flatten = 1.0;            // flatten with a market order outside the hours
};

inline Config make_config(double decision_ms = 100, double calib_every_s = 60, double calib_window_s = 600,
                          double ofi_fast_ms = 1000, double ofi_slow_s = 600, bool all_day = false,
                          double hours_lo = 13.5, double hours_hi = 20.0, bool flatten_outside = true) {
    Config c;
    c.dec_ns = decision_ms * 1e6;
    c.cal_every = calib_every_s;
    c.cal_win = calib_window_s;
    c.ofi_fast = ofi_fast_ms * 1e6;
    c.ofi_slow = ofi_slow_s * 1e9;
    double lo = all_day ? 0.0 : hours_lo, hi = all_day ? 24.0 : hours_hi;
    c.th_lo = lo * 3600;
    c.th_hi = hi * 3600;
    c.flatten = flatten_outside ? 1.0 : 0.0;
    return c;
}

struct Fill {
    i64 ts;
    i32 px;
    i32 mid2;    // 2 x mid (bid + ask, in ticks) when the fill happened
    i32 sz;
    i8 side;     // +1 we bought, -1 we sold
    u8 kind;     // MAKER or TAKER (market order at the close)
};

struct VOrder {
    i64 act = 0, px = 0, sz = 0, ahead = 0, seq = 0, cons = 0;
};

struct Acc {
    i64 q = 0, cash = 0, nfill = 0, vol = 0, takervol = 0, maxq = 0, reject = 0, placed = 0;
};

// What the dashboard shows as the life of an order
enum EvType : u8 { EV_SEND_PLACE, EV_SEND_CANCEL, EV_SEND_FLATTEN, EV_QUEUED, EV_REJECT, EV_CANCELLED, EV_FILL, EV_FLATTEN_FILL };
struct OrdEv {
    i64 ts;
    i32 px;
    i32 sz;
    i32 aux;        // QUEUED: orders ahead of us | SEND_PLACE: arrival delay in us | FILL: queue ahead was consumed
    u8 strat;
    u8 type;
    u8 side;        // 0 bid, 1 ask
};

struct Stat {       // per-stage timing in ns (sampled)
    u64 n = 0;
    double sum = 0;
    i64 max = 0;
    u32 hist[20] = {0};
    void add(i64 ns) {
        ++n;
        sum += (double)ns;
        if (ns > max) max = ns;
        int b = 0;
        i64 v = ns < 1 ? 1 : ns;
        while (v > 1 && b < 19) {
            v >>= 1;
            ++b;
        }
        ++hist[b];
    }
    double pct(double p) const {      // approximate percentile from the log2 histogram (upper edge of the bucket)
        if (!n) return 0;
        double target = p * (double)n, acc = 0;
        for (int b = 0; b < 20; ++b) {
            acc += hist[b];
            if (acc >= target) return (double)((i64)1 << (b + 1));
        }
        return (double)max;
    }
};

struct Strat {
    Params p;
    VOrder o[2];
    i64 ds[2] = {-1, -1};
    i64 npend[2] = {0, 0};
    i64 pq_t[QCAP], pq_k[QCAP], pq_side[QCAP], pq_px[QCAP], pq_sz[QCAP];
    i64 qh = 0, qt = 0;
    Acc acc;
    i64 lastdec = -1000000000000000000LL;
    i64 flatting = 0;
    std::vector<Fill> fills;
    std::vector<i32> pos;     // inventory per second (INT32_MIN = nothing recorded)
    std::vector<i64> cash;    // cash per second in ticks x units (INT64_MIN = nothing recorded)
};

class Engine {
public:
    // sec_series: keep per-second inventory / cash arrays (needed by the report; off for the live dashboard)
    Engine(const std::vector<Params>& params, const Config& cfg, i64 t0_ns, i64 nsec, i64 tick_fx, i64 target_inst,
           bool sec_series = true)
        : cfg_(cfg), t0(t0_ns), nsec_(nsec), tick_fx_(tick_fx), target_(target_inst), orders_(1 << 18) {
        bid_lvl_.assign(NT, 0);
        ask_lvl_.assign(NT, 0);
        bid_blk_.assign(NT >> 10, 0);
        ask_blk_.assign(NT >> 10, 0);
        S.resize(params.size());
        for (size_t i = 0; i < params.size(); ++i) {
            S[i].p = params[i];
            if (sec_series) {
                S[i].pos.assign((size_t)nsec, INT32_MIN);
                S[i].cash.assign((size_t)nsec, INT64_MIN);
            }
        }
        midl_.assign((size_t)nsec, -1);
        valid_.assign((size_t)nsec, 0);
        trc_.assign((size_t)nsec * NB, 0);
    }

    // ------------------------------------------------------------------ state (public: the report and dashboard read it)
    Config cfg_;
    i64 t0;
    std::vector<Strat> S;

    // market state
    i64 bb = -1, ba = NT;                 // best bid / best ask in ticks (-1 / NT = none)
    i64 pbb = 0, pqb = 0, pba = 0, pqa = 0, pval = 0;
    i64 seq = 0, lastcal = -1000000000LL, calok = 0, good = 0, bad = 0;
    double ofi = 0, ofim2 = 0, ofits = 0, sig2 = 0, A = 0, K = 0, ofiw = 0, ofiz_last = 0;
    std::vector<double> cal_sig, cal_A, cal_k;          // one entry per calibration
    i64 n_msgs = 0, n_target = 0;

    // optional tracing for the dashboard
    bool trace = false;
    std::vector<OrdEv> evlog;
    size_t evpos = 0;
    bool prof = false;
    Stat st_pending, st_book, st_signal, st_strat, st_total;

    const std::vector<i64>& bid_lvl() const { return bid_lvl_; }
    const std::vector<i64>& ask_lvl() const { return ask_lvl_; }
    const std::vector<i32>& midl() const { return midl_; }
    const std::vector<u8>& valid() const { return valid_; }
    const std::vector<u32>& trc() const { return trc_; }
    i64 nsec() const { return nsec_; }
    i64 tick_fx() const { return tick_fx_; }
    i64 target() const { return target_; }
    size_t live_orders() const { return orders_.size(); }

    void enable_trace(size_t cap = 8192) {
        trace = true;
        evlog.assign(cap, OrdEv{});
        evpos = 0;
    }

    // ------------------------------------------------------------------ the hot path
    void on_msg(const Msg& m) {
        if ((i64)m.inst != target_) return;
        ++n_target;
        bool timing = prof && ((n_target & 7) == 0);
        i64 t_a = timing ? now_ns() : 0, t_b = 0, t_c = 0, t_d = 0, t_e = 0;
        const i64 t_now = m.ts;
        const i64 sec = floordiv(t_now - t0, NS_PER_SEC);
        const bool rec = sec >= 0 && sec < nsec_;
        const int a = m.action, s_ = m.side;

        // ---- 1) our order actions that reach the exchange before this event ----
        apply_pending(t_now);
        if (timing) t_b = now_ns();

        // ---- 2) the real market event ----
        if (a == 82) {                                                 // R: clear the book (our virtual orders go too)
            orders_.clear();
            std::fill(bid_lvl_.begin(), bid_lvl_.end(), 0);
            std::fill(ask_lvl_.begin(), ask_lvl_.end(), 0);
            std::fill(bid_blk_.begin(), bid_blk_.end(), 0);
            std::fill(ask_blk_.begin(), ask_blk_.end(), 0);
            bb = -1;
            ba = NT;
            pval = 0;
            for (auto& st : S)
                for (int sd = 0; sd < 2; ++sd) {
                    st.o[sd].act = 0;
                    if (st.npend[sd] == 0) st.ds[sd] = -1;
                }
            return;
        }
        if (a == 84) {                                                 // T: an aggressive trade
            if (m.px != UNDEF_PRICE && (s_ == 65 || s_ == 66)) on_trade(m, sec, rec, t_now);
        } else if (a == 65 || a == 67 || a == 77) {                    // A / C / M change the real book
            on_book_change(m);
        }
        if (timing) t_c = now_ns();

        // ---- 3) end of an exchange event: read the book, update signals, let strategies act ----
        if ((m.flags & 128) != 0 && (m.flags & 32) == 0) end_of_event(t_now, sec, rec, timing, t_c, t_d, t_e);
        if (timing) {
            i64 t_f = now_ns();
            st_pending.add(t_b - t_a);
            st_book.add(t_c - t_b);
            if (t_d) {
                st_signal.add(t_d - t_c);
                st_strat.add(t_e - t_d);
            }
            st_total.add(t_f - t_a);
        }
    }

private:
    // ---------------------------------------------------------------- helpers
    void lvl_add(std::vector<i64>& lvl, std::vector<i64>& blk, i64 t, i64 q) {
        i64 before = lvl[(size_t)t];
        i64 after = before + q;
        if (after < 0) after = 0;
        lvl[(size_t)t] = after;
        if (before <= 0 && 0 < after)
            blk[(size_t)(t >> 10)] += 1;
        else if (after <= 0 && 0 < before)
            blk[(size_t)(t >> 10)] -= 1;
    }

    i64 rescan_bid(i64 b) {
        while (b >= 0) {
            if (bid_blk_[(size_t)(b >> 10)] == 0) {
                b = ((b >> 10) << 10) - 1;
                continue;
            }
            if (bid_lvl_[(size_t)b] > 0) return b;
            --b;
        }
        return -1;
    }

    i64 rescan_ask(i64 a) {
        while (a < NT) {
            if (ask_blk_[(size_t)(a >> 10)] == 0) {
                a = ((a >> 10) + 1) << 10;
                continue;
            }
            if (ask_lvl_[(size_t)a] > 0) return a;
            ++a;
        }
        return NT;
    }

    // A real order with priority pk at `price` on side sd lost `amount`: if it was ahead of our order, we move up.
    void queue_out(i64 pk, int sd, i64 price, i64 amount) {
        for (auto& st : S) {
            VOrder& o = st.o[sd];
            if (o.act == 1 && o.px == price && pk < o.seq) {
                i64 ah = o.ahead - amount;
                o.ahead = ah > 0 ? ah : 0;
            }
        }
    }

    void log_ev(i64 ts, size_t s, EvType type, int sd, i64 px, i64 sz, i64 aux) {
        OrdEv& e = evlog[evpos % evlog.size()];
        e.ts = ts;
        e.px = (i32)px;
        e.sz = (i32)sz;
        e.aux = (i32)aux;
        e.strat = (u8)s;
        e.type = type;
        e.side = (u8)sd;
        ++evpos;
    }

    void record_fill(size_t s, int sgn, i64 price, i64 qty, u8 kind, i64 ts) {
        Strat& st = S[s];
        st.acc.q += sgn * qty;
        st.acc.cash -= sgn * qty * price;
        st.acc.nfill += 1;
        st.acc.vol += qty;
        if (kind == TAKER) st.acc.takervol += qty;
        i64 aq = st.acc.q < 0 ? -st.acc.q : st.acc.q;
        if (aq > st.acc.maxq) st.acc.maxq = aq;
        st.fills.push_back(Fill{ts, (i32)price, (i32)(bb + ba), (i32)qty, (i8)sgn, kind});
        if (trace) log_ev(ts, s, kind == TAKER ? EV_FLATTEN_FILL : EV_FILL, sgn > 0 ? 0 : 1, price, qty, 0);
    }

    void send(size_t s, i64 kind, i64 sd, i64 p, i64 z, i64 ts) {
        Strat& st = S[s];
        sd &= 1;
        if (st.qt - st.qh >= QCAP) return;
        size_t j = (size_t)(st.qt % QCAP);
        st.pq_t[j] = ts + (i64)st.p.lat_ns;
        st.pq_k[j] = kind;
        st.pq_side[j] = sd;
        st.pq_px[j] = p;
        st.pq_sz[j] = z;
        st.qt += 1;
        if (kind == 1) st.npend[sd] += 1;
        if (trace) log_ev(ts, s, kind == 1 ? EV_SEND_PLACE : (kind == 2 ? EV_SEND_CANCEL : EV_SEND_FLATTEN), (int)sd, p, z,
                          (i64)(st.p.lat_ns / 1000.0));
    }

    // ---------------------------------------------------------------- 1) our actions arrive at the exchange
    void apply_pending(i64 t_now) {
        for (size_t s = 0; s < S.size(); ++s) {
            Strat& st = S[s];
            while (st.qh < st.qt) {
                size_t j = (size_t)(st.qh % QCAP);
                if (st.pq_t[j] > t_now) break;
                i64 kind = st.pq_k[j], sd = st.pq_side[j] & 1, p = st.pq_px[j], z = st.pq_sz[j];
                i64 arr = st.pq_t[j];
                st.qh += 1;
                if (kind == 1) {                                       // place (replaces any live order on that side)
                    st.npend[sd] -= 1;
                    if ((sd == 0 && p >= ba) || (sd == 1 && p <= bb) || p < 0 || p >= NT) {
                        st.o[sd].act = 0;                              // post-only: would cross -> rejected
                        st.acc.reject += 1;
                        if (st.npend[sd] == 0) st.ds[sd] = -1;
                        if (trace) log_ev(arr, s, EV_REJECT, (int)sd, p, z, 0);
                    } else {
                        VOrder& o = st.o[sd];
                        o.act = 1;
                        o.px = p;
                        o.sz = z;
                        o.ahead = sd == 0 ? bid_lvl_[(size_t)p] : ask_lvl_[(size_t)p];
                        o.seq = seq;
                        o.cons = 0;
                        seq += 1;
                        st.acc.placed += 1;
                        if (trace) log_ev(arr, s, EV_QUEUED, (int)sd, p, z, o.ahead);
                    }
                } else if (kind == 2) {                                // cancel
                    st.o[sd].act = 0;
                    if (trace) log_ev(arr, s, EV_CANCELLED, (int)sd, 0, 0, 0);
                } else {                                               // market order to flatten (taker)
                    if (sd == 0 && ba < NT)
                        record_fill(s, 1, ba, z, TAKER, t_now);
                    else if (sd == 1 && bb >= 0)
                        record_fill(s, -1, bb, z, TAKER, t_now);
                    st.flatting = 0;
                }
            }
        }
    }

    // ---------------------------------------------------------------- 2a) an aggressive trade
    void on_trade(const Msg& m, i64 sec, bool rec, i64 t_now) {
        const int s_ = m.side;
        const i64 pt = floordiv(m.px, tick_fx_);
        const i64 x = m.sz;
        if (rec && bb >= 0 && ba < NT) {                               // calibration: how far from the mid did it reach?
            i64 dh = 2 * pt - (bb + ba);
            if (dh < 0) dh = -dh;
            i64 b = floordiv(dh - 1, 2);
            if (b >= 0 && b < NB) trc_[(size_t)sec * NB + (size_t)b] += 1;
        }
        const int sd = s_ == 65 ? 0 : 1;                               // seller hits bids (side 0); buyer lifts asks (side 1)
        for (size_t s = 0; s < S.size(); ++s) {
            Strat& st = S[s];
            VOrder& o = st.o[sd];
            if (o.act != 1) continue;
            const i64 p = o.px;
            i64 fill = 0;
            if ((sd == 0 && pt < p) || (sd == 1 && pt > p)) {
                fill = x;                                              // it traded through our price: we were first
            } else if (pt == p) {
                i64 avail = o.ahead - o.cons;
                if (avail < 0) avail = 0;
                fill = x - avail;                                      // only what is left after the queue ahead of us
                o.cons += x;
            }
            if (fill > 0) {
                i64 left = o.sz;
                if (fill > left) fill = left;
                record_fill(s, sd == 0 ? 1 : -1, p, fill, MAKER, t_now);
                o.sz = left - fill;
                if (left - fill == 0) {
                    o.act = 0;
                    if (st.npend[sd] == 0) st.ds[sd] = -1;
                }
            }
        }
    }

    // ---------------------------------------------------------------- 2b) A / C / M change the real book
    void on_book_change(const Msg& m) {
        const int a = m.action, s_ = m.side;
        const u64 k = m.oid;
        bool newv = a != 67 && m.px != UNDEF_PRICE && m.sz > 0 && (s_ == 66 || s_ == 65);
        i64 tnew = newv ? floordiv(m.px, tick_fx_) : -1;
        if (newv && (tnew < 0 || tnew >= NT)) newv = false;
        const i64 qnew = (i64)m.sz < SIZE_CAP ? (i64)m.sz : SIZE_CAP;
        const i64 bnew = s_ == 66 ? 1 : 0;
        bool add_new = newv;
        OrderRec* e = orders_.find(k);
        if (e) {
            const i64 v = e->v;
            const i64 ot = v >> 22, osz = (v >> 1) & SIZE_CAP, ob = v & 1;
            const i64 pk = e->prio;
            const int osd = ob == 1 ? 0 : 1;
            if (a == 77 && newv && tnew == ot && qnew <= osz && bnew == ob) {
                i64 d = osz - qnew;                                    // modify down in place: keeps its priority
                if (d > 0) {
                    if (ob == 1)
                        lvl_add(bid_lvl_, bid_blk_, ot, -d);
                    else
                        lvl_add(ask_lvl_, ask_blk_, ot, -d);
                    queue_out(pk, osd, ot, d);
                }
                e->v = (ot << 22) | (qnew << 1) | ob;
                add_new = false;
            } else {
                i64 rem = a == 67 ? ((i64)m.sz < osz ? (i64)m.sz : osz) : osz;
                if (ob == 1) {
                    lvl_add(bid_lvl_, bid_blk_, ot, -rem);
                    if (ot == bb && bid_lvl_[(size_t)ot] <= 0) bb = rescan_bid(ot);
                } else {
                    lvl_add(ask_lvl_, ask_blk_, ot, -rem);
                    if (ot == ba && ask_lvl_[(size_t)ot] <= 0) ba = rescan_ask(ot);
                }
                queue_out(pk, osd, ot, rem);
                if (a == 67 && osz - rem > 0)
                    e->v = (ot << 22) | ((osz - rem) << 1) | ob;
                else
                    orders_.erase(k);
            }
        }
        if (add_new) {                                                 // a new order, or a modified one that lost priority
            orders_.put(k, (tnew << 22) | (qnew << 1) | bnew, seq);
            seq += 1;
            if (bnew == 1) {
                lvl_add(bid_lvl_, bid_blk_, tnew, qnew);
                if (tnew > bb) bb = tnew;
            } else {
                lvl_add(ask_lvl_, ask_blk_, tnew, qnew);
                if (tnew < ba) ba = tnew;
            }
        }
    }

    // ---------------------------------------------------------------- calibration (sigma, A, k) from the last window only
    void calibrate(i64 sec) {
        i64 W = (i64)cfg_.cal_win;
        i64 lo = sec - W;
        if (lo < 0) lo = 0;
        lastcal = sec;
        double acc = 0.0, prev = 0.0;
        i64 nsec_w = 0;
        bool started = false;
        for (i64 j = lo; j < sec; ++j) {
            i32 mm = midl_[(size_t)j];
            if (mm >= 0) {
                double m = (double)mm;
                if (started) {
                    double d = (m - prev) / 2.0;
                    acc += d * d;
                }
                prev = m;
                started = true;
            }
            if (started) ++nsec_w;
        }
        if (nsec_w < W / 4) return;
        double lam[NB];
        double tot = 0.0;
        for (int b = NB - 1; b >= 0; --b) {
            double c = 0.0;
            for (i64 j = lo; j < sec; ++j) c += (double)trc_[(size_t)j * NB + (size_t)b];
            tot += c;
            lam[b] = tot / (double)nsec_w;
        }
        double sx = 0, sy = 0, sxx = 0, sxy = 0;
        int m_ = 0;
        for (int b = 0; b < NB; ++b) {
            if (lam[b] > 0) {
                double x = 0.5 + b;
                double yv = std::log(lam[b]);
                sx += x;
                sy += yv;
                sxx += x * x;
                sxy += x * yv;
                m_ += 1;
            }
        }
        if (m_ < 2 || acc <= 0) return;
        double slope = ((double)m_ * sxy - sx * sy) / ((double)m_ * sxx - sx * sx);
        double k = -slope;
        if (k < 0.05) k = 0.05;
        if (k > 20.0) k = 20.0;
        double Av = std::exp((sy - slope * sx) / (double)m_);
        sig2 = acc / (double)nsec_w;
        A = Av;
        K = k;
        calok = 1;
        cal_sig.push_back(std::sqrt(acc / (double)nsec_w));
        cal_A.push_back(Av);
        cal_k.push_back(k);
    }

    static i64 to_i64(double x) {          // Numba's np.int64(nan / inf) gives INT64_MIN; avoid C++ undefined behaviour
        if (!(x > -9.2e18 && x < 9.2e18)) return INT64_MIN;
        return (i64)x;
    }

    // ---------------------------------------------------------------- 3) end of an exchange event
    void end_of_event(i64 t_now, i64 sec, bool rec, bool timing, i64& t_c, i64& t_d, i64& t_e) {
        (void)t_c;
        bool ok = bb >= 0 && ba < NT && bb < ba;
        if (ok) ok = bid_lvl_[(size_t)bb] > 0 && ask_lvl_[(size_t)ba] > 0;
        for (auto& st : S) {
            st.o[0].cons = 0;
            st.o[1].cons = 0;
        }
        if (!ok) {
            pval = 0;
            bad += 1;
            return;
        }
        good += 1;
        const i64 qb = bid_lvl_[(size_t)bb], qa = ask_lvl_[(size_t)ba];
        double e = 0.0;
        if (pval == 1) {                                               // OFI increment (Cont, Kukanov & Stoikov 2014)
            if (bb >= pbb) e += (double)qb;
            if (bb <= pbb) e -= (double)pqb;
            if (ba <= pba) e -= (double)qa;
            if (ba >= pba) e += (double)pqa;
        }
        pbb = bb;
        pqb = qb;
        pba = ba;
        pqa = qa;
        pval = 1;
        double dt = (double)t_now - ofits;
        if (ofits == 0 || dt > 5.0 * cfg_.ofi_slow) {                  // first event, or after a long gap: start the averages empty
            ofi = 0.0;
            ofim2 = 0.0;
            ofiw = 0.0;
            dt = 0;
        }
        if (dt < 0) dt = 0;
        double af = std::exp(-dt / cfg_.ofi_fast);
        double asl = std::exp(-dt / cfg_.ofi_slow);
        ofi = ofi * af + e;
        ofim2 = ofim2 * asl + (1.0 - asl) * ofi * ofi;
        ofiw = ofiw * asl + (1.0 - asl);                               // weight so far: corrects the start-up bias of the average
        ofits = (double)t_now;
        double ofiz = 0.0;                                             // no z-score until the slow average has ~5% of its window
        if (ofiw > 0.05 && ofim2 > 0) ofiz = ofi / std::sqrt(ofim2 / ofiw);
        ofiz_last = ofiz;
        // a real order now rests at or through our virtual price: it would have traded with us
        for (size_t s = 0; s < S.size(); ++s) {
            Strat& st = S[s];
            if (st.o[0].act == 1 && ba <= st.o[0].px) {
                i64 p = st.o[0].px;
                i64 f = st.o[0].sz < qa ? st.o[0].sz : qa;
                record_fill(s, 1, p, f, MAKER, t_now);
                st.o[0].sz -= f;
                if (st.o[0].sz <= 0) {
                    st.o[0].act = 0;
                    if (st.npend[0] == 0) st.ds[0] = -1;
                }
            }
            if (st.o[1].act == 1 && bb >= st.o[1].px) {
                i64 p = st.o[1].px;
                i64 f = st.o[1].sz < qb ? st.o[1].sz : qb;
                record_fill(s, -1, p, f, MAKER, t_now);
                st.o[1].sz -= f;
                if (st.o[1].sz <= 0) {
                    st.o[1].act = 0;
                    if (st.npend[1] == 0) st.ds[1] = -1;
                }
            }
        }
        if (!rec) return;
        midl_[(size_t)sec] = (i32)(bb + ba);
        valid_[(size_t)sec] = 1;
        if ((double)(sec - lastcal) >= cfg_.cal_every) calibrate(sec);
        if (timing) t_d = now_ns();
        const i64 sod = floormod(floordiv(t_now, NS_PER_SEC), 86400);
        const double lo_ = cfg_.th_lo, hi_ = cfg_.th_hi;
        const bool inside = lo_ < hi_ ? ((double)sod >= lo_ && (double)sod < hi_) : ((double)sod >= lo_ || (double)sod < hi_);
        const double mid = (double)(bb + ba) / 2.0;
        for (size_t s = 0; s < S.size(); ++s) {
            Strat& st = S[s];
            const Params& P = st.p;
            const double dec_ns = P.dec_ns > 0 ? P.dec_ns : cfg_.dec_ns;   // this strategy's own re-quote interval, else the global one
            if ((double)(t_now - st.lastdec) >= dec_ns) {
                st.lastdec = t_now;
                const double q = (double)st.acc.q;
                const i64 size = P.size;
                i64 wb = -1, wa = -1;
                if (!inside) {
                    if (cfg_.flatten > 0 && st.acc.q != 0 && st.flatting == 0) {
                        send(s, 3, st.acc.q > 0 ? 1 : 0, 0, st.acc.q < 0 ? -st.acc.q : st.acc.q, t_now);
                        st.flatting = 1;
                    }
                } else if (st.flatting == 0) {
                    const int kind = P.kind;
                    if (kind == JOIN) {
                        wb = bb;
                        wa = ba;
                    } else if (calok == 1) {
                        double sg2 = sig2, Aa = A, kk = K, g = P.gamma;
                        if (g < 0) g = -g / (std::max(sg2, 1e-3) * P.horizon_s);   // scale-free: |g| = ticks of quote shift per unit of inventory
                        if (kind == AS) {
                            double H = P.horizon_s;
                            double r = mid - q * g * sg2 * H;
                            double half = 0.5 * (g * sg2 * H + 2.0 / g * std::log(1.0 + g / kk));
                            wb = to_i64(std::floor(r - half));
                            wa = to_i64(std::ceil(r + half));
                        } else {
                            double base = std::log(1.0 + g / kk) / g;
                            double C = std::sqrt(sg2 * g / (2.0 * kk * Aa) * std::pow(1.0 + g / kk, 1.0 + kk / g));
                            wb = to_i64(std::floor(mid - (base + (2.0 * q + 1.0) / 2.0 * C)));
                            wa = to_i64(std::ceil(mid + (base - (2.0 * q - 1.0) / 2.0 * C)));
                        }
                    }
                    if (wb >= 0) {
                        if (wb > ba - 1) wb = ba - 1;                  // post-only: never cross the spread
                        if ((double)wb < (double)bb - P.maxd) wb = -1;
                    }
                    if (wa >= 0) {
                        if (wa < bb + 1) wa = bb + 1;
                        if ((double)wa > (double)ba + P.maxd) wa = -1;
                    }
                    if (q + (double)size > P.qmax) wb = -1;           // inventory limit
                    if (q - (double)size < -P.qmax) wa = -1;
                    const double oz = P.ofi_z;
                    if (oz > 0) {                                      // OFI defense: pull the side about to be run over
                        if (ofiz > oz) wa = -1;
                        if (ofiz < -oz) wb = -1;
                    }
                }
                for (int sd = 0; sd < 2; ++sd) {
                    i64 w = sd == 0 ? wb : wa;
                    i64 cur = st.ds[sd];
                    if (w == cur) continue;
                    if (w == -1) {
                        send(s, 2, sd, 0, 0, t_now);
                        st.ds[sd] = -1;
                    } else if (cur == -1 || std::fabs((double)(w - cur)) >= P.req) {
                        send(s, 1, sd, w, size, t_now);
                        st.ds[sd] = w;
                    }
                }
            }
            if (!st.pos.empty()) {
                st.pos[(size_t)sec] = (i32)st.acc.q;
                st.cash[(size_t)sec] = st.acc.cash;
            }
        }
        if (timing) t_e = now_ns();
    }

    // ---------------------------------------------------------------- data
    i64 nsec_, tick_fx_, target_;
    OrderMap orders_;
    std::vector<i64> bid_lvl_, ask_lvl_, bid_blk_, ask_blk_;
    std::vector<i32> midl_;       // 2 x mid per second (bid + ask in ticks), -1 = no data
    std::vector<u8> valid_;       // a valid book was read in this second
    std::vector<u32> trc_;        // trade-reach counts per second per bucket
};

}  // namespace mm
