// order_map.hpp - flat open-addressing hash map from order id to (packed order, priority).
// No allocation per order, linear probing, backward-shift deletion (no tombstones).
#pragma once
#include <cstring>
#include <vector>

#include "common.hpp"

namespace mm {

struct OrderRec {
    u64 key;     // order id (EMPTY marks a free slot)
    i64 v;       // packed: (price_tick << 22) | (size << 1) | is_bid
    i64 prio;    // queue priority: a global increasing sequence number
};

class OrderMap {
public:
    static constexpr u64 EMPTY = ~0ULL;

    explicit OrderMap(size_t cap_pow2 = 1 << 20) { reset_capacity(cap_pow2); }

    OrderRec* find(u64 k) {
        size_t i = slot(k);
        for (;;) {
            OrderRec& r = t_[i];
            if (r.key == k) return &r;
            if (r.key == EMPTY) return nullptr;
            i = (i + 1) & mask_;
        }
    }

    // insert or overwrite
    void put(u64 k, i64 v, i64 prio) {
        if ((n_ + 1) * 2 > t_.size()) grow();
        size_t i = slot(k);
        for (;;) {
            OrderRec& r = t_[i];
            if (r.key == k) {
                r.v = v;
                r.prio = prio;
                return;
            }
            if (r.key == EMPTY) {
                r.key = k;
                r.v = v;
                r.prio = prio;
                ++n_;
                return;
            }
            i = (i + 1) & mask_;
        }
    }

    void erase(u64 k) {
        size_t i = slot(k);
        for (;;) {
            if (t_[i].key == k) break;
            if (t_[i].key == EMPTY) return;
            i = (i + 1) & mask_;
        }
        // backward-shift deletion
        size_t j = i;
        for (;;) {
            j = (j + 1) & mask_;
            if (t_[j].key == EMPTY) break;
            size_t h = slot(t_[j].key);
            // can t_[j] move to i? yes if its home slot h is not in the cyclic range (i, j]
            bool in_range = (i <= j) ? (h > i && h <= j) : (h > i || h <= j);
            if (!in_range) {
                t_[i] = t_[j];
                i = j;
            }
        }
        t_[i].key = EMPTY;
        --n_;
    }

    void clear() {
        for (auto& r : t_) r.key = EMPTY;
        n_ = 0;
    }

    size_t size() const { return n_; }

private:
    size_t slot(u64 k) const { return (size_t)((k * 0x9E3779B97F4A7C15ULL) >> shift_); }

    void reset_capacity(size_t cap) {
        t_.assign(cap, OrderRec{EMPTY, 0, 0});
        mask_ = cap - 1;
        int lg = 0;
        while (((size_t)1 << lg) < cap) ++lg;
        shift_ = 64 - lg;
        n_ = 0;
    }

    void grow() {
        std::vector<OrderRec> old;
        old.swap(t_);
        reset_capacity(old.size() * 2);
        for (auto& r : old)
            if (r.key != EMPTY) put(r.key, r.v, r.prio);
    }

    std::vector<OrderRec> t_;
    size_t mask_ = 0, n_ = 0;
    int shift_ = 0;
};

}  // namespace mm
