// mm_sim - market-making simulator on Databento MBO data (C++).
//   mm_sim [backtest] <file-or-folder> [options]    replay everything as fast as possible and print the report
//   mm_sim replay <file-or-folder> [options]        watch it live in the terminal, like a trading screen
// See README.md for all options.
#include <cstdio>
#include <string>

#include "backtest.hpp"
#include "dashboard.hpp"

using namespace mm;

static void usage() {
    std::printf(
        "mm_sim - market-making simulator on Databento MBO data\n\n"
        "  mm_sim [backtest] <file|folder> [options]   run everything and print the report\n"
        "  mm_sim replay <file|folder> [options]       live terminal view of the market and our orders\n\n"
        "Common options (defaults in brackets; the same can go in mm_settings.txt as 'name = value'):\n"
        "  --tick 0.25  --tick-value 5  --fee 2  --hours 13.5,20  --allday  --size 1  --qmax 5\n"
        "  --latency-ms 1  --decision-ms 100  --skew 0.5  --horizon-s 10  --ofi-z 2\n"
        "  --no-sweeps   --max N (quick trial)   --out DIR   --dump-fills file.csv\n"
        "replay options:\n"
        "  --show A-S (strategy to show)  --from 14:00 | 2025-05-13 13:25  --speed 1 (0 = max)  --ladder 9\n"
        "  --plain --frames N --frame-every 1.0 (print N text frames and exit; for logs and tests)\n");
}

int main(int argc, char** argv) {
    Settings s;
    std::string mode = "backtest";
    std::string settings_file;
    std::vector<std::string> pos;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "-h" || a == "--help") {
            usage();
            return 0;
        }
        if (a == "--config" && i + 1 < argc) {
            settings_file = argv[++i];
            continue;
        }
        if (a.rfind("--", 0) == 0) {
            std::string key = a, val;
            size_t eq = a.find('=');
            if (eq != std::string::npos) {
                key = a.substr(0, eq);
                val = a.substr(eq + 1);
            } else if (!is_flag(a) && i + 1 < argc) {
                val = argv[++i];
            }
            pos.push_back("\x01" + key + "\x02" + val);        // applied after the settings file
        } else {
            pos.push_back(a);
        }
    }
    load_settings_file(s, "mm_settings.txt", false);
    if (!settings_file.empty()) load_settings_file(s, settings_file, true);
    bool have_path = false;
    for (auto& p : pos) {
        if (!p.empty() && p[0] == '\x01') {
            size_t sep = p.find('\x02');
            std::string key = p.substr(1, sep - 1), val = p.substr(sep + 1);
            if (!set_option(s, key, val)) {
                std::fprintf(stderr, "unknown option %s (try --help)\n", key.c_str());
                return 2;
            }
        } else if (p == "backtest" || p == "replay") {
            mode = p;
        } else {
            s.file_path = p;
            have_path = true;
        }
    }
    (void)have_path;
    if (mode == "replay") return run_dashboard(s);

    Session S;
    if (!open_session(S, s)) {
        std::fprintf(stderr, "%s\n", S.err.c_str());
        return 1;
    }
    auto strategies = strategy_list(s, true);
    RunResult R = run_backtest(S, s, strategies);
    Engine& E = *R.engine;
    if (E.good + E.bad == 0) {
        std::fprintf(stderr, "The file has no end-of-event markers (flag 128), so the book was never read. "
                             "Is this a Databento MBO file for one instrument, with the flags column included?\n");
        return 1;
    }
    Analysis A = analyse(E, s, true);
    bool any_day = false;
    for (auto& r : A.summary) any_day |= r.days > 0;
    if (!any_day) {
        std::fprintf(stderr, "No day has a minute of usable market data inside the trading hours (%g to %g UTC). "
                             "Check them, or use --allday to quote around the clock.\n", s.hours_lo, s.hours_hi);
        return 1;
    }
    bool saved = write_csvs(s, A, E);
    if (!s.dump_fills.empty()) saved = dump_fills_csv(s.dump_fills, E) && saved;
    print_report(E, s, A, R.done, R.secs);
    if (saved) std::printf("\nSaved in %s: mm_summary.csv, mm_daily.csv, mm_equity.csv\n", s.out_dir.c_str());
    else std::printf("\nThe CSV files could NOT be saved (see the message above).\n");
    return saved ? 0 : 1;
}
