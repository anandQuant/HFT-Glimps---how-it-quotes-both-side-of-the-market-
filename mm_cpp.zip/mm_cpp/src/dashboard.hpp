#pragma once
#include "settings.hpp"
namespace mm { int run_dashboard(const Settings& s); }
