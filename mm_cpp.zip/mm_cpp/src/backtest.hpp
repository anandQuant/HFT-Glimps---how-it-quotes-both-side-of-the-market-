// backtest.hpp - replay a whole MBO file through the engine as fast as possible and print the report.
#pragma once
#include <memory>
#include <thread>

#include "feed.hpp"
#include "report.hpp"
#include "settings.hpp"

namespace mm {

// Opens the file, reads the first records, and builds everything the engine needs (time axis, instrument).
struct Session {
    DbnReader reader;
    std::vector<Msg> first;          // the first records (already read: used to pick the instrument and the time axis)
    size_t first_n = 0;
    i64 t0 = 0, nsec = 0;
    TargetPick target;
    bool ok = false;
    std::string err;
};

inline bool open_session(Session& S, const Settings& cfg) {
    if (!S.reader.open(cfg.file_path, S.err)) return false;
    const DbnInfo& info = S.reader.info();
    if (info.schema != 0) {
        S.err = "This needs MBO data (market by order); the file's schema code is " + std::to_string(info.schema) + " (0 = mbo)";
        return false;
    }
    size_t want = (size_t)std::max<i64>(cfg.chunk, 1000);
    S.first.resize(want);
    S.first_n = S.reader.read(S.first.data(), want);
    if (S.first_n == 0) {
        S.err = "The file has no records";
        return false;
    }
    // time axis: t0 = the earlier of the header start and the first event, floored to a whole second
    i64 first_ts = INT64_MAX;
    size_t np = std::min<size_t>(S.first_n, (size_t)cfg.probe);
    for (size_t i = 0; i < np; ++i) first_ts = std::min(first_ts, S.first[i].ts);
    i64 start = (info.start_ns > (u64)INT64_MAX) ? first_ts : (i64)info.start_ns;
    S.t0 = floordiv(std::min(start, first_ts), NS_PER_SEC) * NS_PER_SEC;
    i64 end = (info.end_ns == 0 || info.end_ns > (u64)INT64_MAX) ? S.t0 + 31LL * 86400 * NS_PER_SEC : (i64)info.end_ns;
    if (end <= S.t0) end = S.t0 + 86400LL * NS_PER_SEC;
    S.nsec = floordiv(end - S.t0, NS_PER_SEC) + 2;
    S.target = pick_target(S.first.data(), S.first_n);
    S.ok = true;
    return true;
}

struct RunResult {
    std::unique_ptr<Engine> engine;
    i64 done = 0;
    double secs = 0;
};

inline RunResult run_backtest(Session& S, const Settings& cfg, const std::vector<Params>& strategies) {
    RunResult out;
    i64 tick_fx = (i64)std::llround(cfg.tick * 1e9);
    out.engine = std::make_unique<Engine>(strategies, to_config(cfg), S.t0, S.nsec, tick_fx, (i64)S.target.id, true);
    Engine& E = *out.engine;
    const DbnInfo& info = S.reader.info();
    if (!cfg.quiet) {
        std::printf("File: %s | %s -> %s UTC (DBN v%d, %s)\n", info.dataset.c_str(), fmt_time((i64)info.start_ns, true, 0).c_str(),
                    fmt_time((i64)info.end_ns, true, 0).c_str(), info.version, info.compressed ? "zstd" : "plain");
        std::printf("Instrument id used: %u (%.0f%% of the first records)\n", S.target.id, 100.0 * S.target.share);
        if (S.target.share < 0.9) std::printf("  note: the file holds other instruments too; they are ignored.\n");
    }
    BatchQueue q(6);
    std::thread reader;
    const size_t BATCH = 1 << 18;
    reader = std::thread([&] {
        for (;;) {
            auto b = std::make_unique<Batch>();
            b->m.resize(BATCH);
            b->n = S.reader.read(b->m.data(), BATCH);
            if (b->n == 0) break;
            q.push(std::move(b));
        }
        q.finish();
    });
    double t_start = now_sec(), t_print = t_start;
    i64 done = 0, next_print = 10'000'000;
    auto feed = [&](const Msg* m, size_t n) {
        if (cfg.max_records > 0 && done + (i64)n > cfg.max_records) n = (size_t)std::max<i64>(cfg.max_records - done, 0);   // --max is exact
        if (n == 0) return;
        for (size_t i = 0; i < n; ++i) E.on_msg(m[i]);
        done += (i64)n;
        if (!cfg.quiet && done >= next_print) {
            double el = now_sec() - t_start;
            std::printf("  %s records | up to %s UTC | %.0f s (%.2f M/s)\n", fmt((double)done).c_str(),
                        fmt_time(m[n - 1].ts, true, 0).substr(0, 16).c_str(), el, (double)done / el / 1e6);
            std::fflush(stdout);
            next_print += 10'000'000;
            t_print = now_sec();
        }
    };
    feed(S.first.data(), S.first_n);
    bool stopped = cfg.max_records > 0 && done >= cfg.max_records;
    while (!stopped) {
        auto b = q.pop();
        if (!b) break;
        feed(b->m.data(), b->n);
        if (cfg.max_records > 0 && done >= cfg.max_records) {
            if (!cfg.quiet) std::printf("Stopped at max = %s records\n", fmt((double)cfg.max_records).c_str());
            stopped = true;
        }
    }
    q.cancel();
    reader.join();
    (void)t_print;
    out.done = done;
    out.secs = now_sec() - t_start;
    return out;
}

}  // namespace mm
