// report.hpp - turns the engine's fills and per-second records into money, markouts and the text report.
// Mirrors analyse() and report() of mm_backtest.py.
#pragma once
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <string>
#include <vector>

#include "engine.hpp"
#include "settings.hpp"

namespace mm {

constexpr double NaN = std::numeric_limits<double>::quiet_NaN();

struct Summary {
    std::string name;
    double net = 0, gross = 0, fees = 0;
    i64 fills = 0;
    double units = 0, taker_units = 0, all_units = 0;
    i64 placed = 0, rejects = 0;
    double spread_capture = NaN, max_inv = 0, avg_inv = NaN;
    int win_days = 0, days = 0;
    double worst_day = NaN, best_day = NaN;
    std::vector<double> mo;          // markout per Settings::markout_s
    double fill_rate = NaN, net_per_fill = NaN;
};

struct Analysis {
    std::vector<Summary> summary;
    std::vector<std::string> day_labels;
    std::vector<std::vector<double>> perday;     // [strategy][day]
    std::vector<double> mid;                     // ticks, per second (filled forward)
    std::vector<std::vector<double>> net;        // [strategy][second] net $ (only filled when keep_curves)
    std::vector<std::vector<double>> pos;        // [strategy][second]
    std::vector<u8> inside;
    bool acct_ok = true;
    int index_of(const std::string& n) const {
        for (size_t i = 0; i < summary.size(); ++i)
            if (summary[i].name == n) return (int)i;
        return -1;
    }
};

inline Analysis analyse(const Engine& E, const Settings& cfg, bool keep_curves = false) {
    Analysis R;
    const size_t NS = E.S.size();
    const i64 nsec = E.nsec();
    const i64 t0 = E.t0;
    const i64 t0s = floordiv(t0, NS_PER_SEC);

    // mid per second: forward fill, then back fill, then 0
    R.mid.assign((size_t)nsec, NaN);
    for (i64 i = 0; i < nsec; ++i)
        if (E.midl()[(size_t)i] >= 0) R.mid[(size_t)i] = E.midl()[(size_t)i] / 2.0;
    {
        double last = NaN;
        for (auto& v : R.mid) {
            if (!std::isnan(v)) last = v;
            else v = last;
        }
        double first = NaN;
        for (i64 i = nsec - 1; i >= 0; --i) {
            if (!std::isnan(R.mid[(size_t)i])) first = R.mid[(size_t)i];
            else R.mid[(size_t)i] = first;
        }
        for (auto& v : R.mid)
            if (std::isnan(v)) v = 0.0;
    }

    // trading day (CME: the day starts at 22:00 UTC the evening before) and "inside" seconds
    std::vector<i64> day((size_t)nsec);
    for (i64 i = 0; i < nsec; ++i) day[(size_t)i] = floordiv(t0s + i + 7200, 86400);
    R.inside.assign((size_t)nsec, 0);
    for (i64 i = 0; i < nsec; ++i) {
        bool v = E.valid()[(size_t)i] != 0;
        if (!cfg.all_day) {
            i64 sod = floormod(t0s + i, 86400);
            v = v && (double)sod >= cfg.hours_lo * 3600 && (double)sod < cfg.hours_hi * 3600;
        }
        R.inside[(size_t)i] = v;
    }
    // day groups in order
    std::vector<i64> day_ids;
    std::vector<i64> day_last;                 // index of the last second of each day
    std::vector<i64> day_inside;
    for (i64 i = 0; i < nsec; ++i) {
        if (day_ids.empty() || day_ids.back() != day[(size_t)i]) {
            day_ids.push_back(day[(size_t)i]);
            day_last.push_back(i);
            day_inside.push_back(0);
        }
        day_last.back() = i;
        day_inside.back() += R.inside[(size_t)i];
    }
    std::vector<int> active_days;
    for (size_t d = 0; d < day_ids.size(); ++d)
        if (day_inside[d] > 60) active_days.push_back((int)d);
    for (int d : active_days) R.day_labels.push_back(fmt_day(day_ids[(size_t)d]));

    R.perday.assign(NS, {});
    R.summary.resize(NS);
    if (keep_curves) {
        R.net.assign(NS, std::vector<double>((size_t)nsec, 0.0));
        R.pos.assign(NS, std::vector<double>((size_t)nsec, 0.0));
    }
    for (size_t s = 0; s < NS; ++s) {
        const Strat& st = E.S[s];
        // positions and cash, filled forward (leading gaps = 0)
        std::vector<double> pos((size_t)nsec), cash((size_t)nsec);
        double lp = 0, lc = 0;
        for (i64 i = 0; i < nsec; ++i) {
            if (!st.pos.empty() && st.pos[(size_t)i] != INT32_MIN) lp = st.pos[(size_t)i];
            if (!st.cash.empty() && st.cash[(size_t)i] != INT64_MIN) lc = (double)st.cash[(size_t)i];
            pos[(size_t)i] = lp;
            cash[(size_t)i] = lc;
        }
        // fees by second
        std::vector<double> fee_by_sec((size_t)nsec, 0.0);
        for (const Fill& f : st.fills) {
            i64 sec = floordiv(f.ts - t0, NS_PER_SEC);
            sec = std::min<i64>(std::max<i64>(sec, 0), nsec - 1);
            fee_by_sec[(size_t)sec] += (double)f.sz;
        }
        std::vector<double> net((size_t)nsec);
        double fee_cum = 0, gross_last = 0, fee_last = 0;
        for (i64 i = 0; i < nsec; ++i) {
            fee_cum += fee_by_sec[(size_t)i] * cfg.fee;
            double g = (cash[(size_t)i] + pos[(size_t)i] * R.mid[(size_t)i]) * cfg.tick_value;
            net[(size_t)i] = g - fee_cum;
            gross_last = g;
            fee_last = fee_cum;
        }
        // per-day profit: difference of the last net value of consecutive days
        std::vector<double> perday_all(day_ids.size());
        for (size_t d = 0; d < day_ids.size(); ++d) {
            double cur = net[(size_t)day_last[d]];
            perday_all[d] = d == 0 ? cur : cur - net[(size_t)day_last[d - 1]];
        }
        for (int d : active_days) R.perday[s].push_back(perday_all[(size_t)d]);

        Summary& r = R.summary[s];
        r.name = st.p.name;
        r.net = nsec ? net[(size_t)nsec - 1] : 0;
        r.gross = gross_last;
        r.fees = fee_last;
        double wsum = 0, taker = 0, all_units = 0;
        i64 nmaker = 0;
        double sc = 0;
        std::vector<double> mo(cfg.markout_s.size(), 0.0);
        for (const Fill& f : st.fills) {
            all_units += f.sz;
            if (f.kind != MAKER) {
                taker += f.sz;
                continue;
            }
            ++nmaker;
            wsum += f.sz;
            i64 sec = floordiv(f.ts - t0, NS_PER_SEC);
            sec = std::min<i64>(std::max<i64>(sec, 0), nsec - 1);
            sc += f.sz * (f.side * (f.mid2 / 2.0 - (double)f.px));
            for (size_t h = 0; h < cfg.markout_s.size(); ++h) {
                i64 j = std::min<i64>(std::max<i64>(sec + cfg.markout_s[h], 0), nsec - 1);
                mo[h] += f.sz * (f.side * (R.mid[(size_t)j] - (double)f.px));
            }
        }
        r.fills = nmaker;
        r.units = wsum;
        r.taker_units = taker;
        r.all_units = all_units;
        r.placed = st.acc.placed;
        r.rejects = st.acc.reject;
        r.spread_capture = wsum > 0 ? sc / wsum : NaN;
        r.mo.resize(mo.size());
        for (size_t h = 0; h < mo.size(); ++h) r.mo[h] = wsum > 0 ? mo[h] / wsum : NaN;
        r.max_inv = (double)st.acc.maxq;
        double inv_sum = 0;
        i64 inv_n = 0;
        for (i64 i = 0; i < nsec; ++i)
            if (R.inside[(size_t)i]) {
                inv_sum += std::fabs(pos[(size_t)i]);
                ++inv_n;
            }
        r.avg_inv = inv_n ? inv_sum / (double)inv_n : NaN;
        r.days = (int)R.perday[s].size();
        r.win_days = 0;
        for (double v : R.perday[s])
            if (v > 0) ++r.win_days;
        if (!R.perday[s].empty()) {
            r.worst_day = *std::min_element(R.perday[s].begin(), R.perday[s].end());
            r.best_day = *std::max_element(R.perday[s].begin(), R.perday[s].end());
        }
        r.fill_rate = r.placed ? r.units / (double)r.placed : NaN;
        r.net_per_fill = r.fills ? r.net / (double)r.fills : NaN;
        // accounting check: final cash and inventory must equal what the fill list says
        double c = 0, q = 0;
        for (const Fill& f : st.fills) {
            c -= (double)f.side * f.px * f.sz;
            q += (double)f.side * f.sz;
        }
        if (std::fabs(c - (double)st.acc.cash) > 1e-3 || std::fabs(q - (double)st.acc.q) > 1e-6) R.acct_ok = false;
        if (keep_curves) {
            R.net[s] = net;
            R.pos[s] = pos;
        }
    }
    return R;
}

// ---------------------------------------------------------------------------------------------
// text report (short lines so copy-paste does not break them)
// ---------------------------------------------------------------------------------------------
inline std::string fmt(double x, int nd = 0, bool sign = false) {
    if (std::isnan(x)) return "n/a";
    char b[64];
    std::snprintf(b, sizeof b, "%.*f", nd, std::fabs(x));
    std::string s = b, ip = s, fp;
    size_t dot = s.find('.');
    if (dot != std::string::npos) {
        ip = s.substr(0, dot);
        fp = s.substr(dot);
    }
    std::string out;
    for (size_t i = 0; i < ip.size(); ++i) {
        out += ip[i];
        size_t left = ip.size() - 1 - i;
        if (left > 0 && left % 3 == 0) out += ',';
    }
    out += fp;
    bool neg = x < 0 && std::atof(b) != 0.0;
    if (neg) out = "-" + out;
    else if (sign) out = "+" + out;
    return out;
}

inline std::string padl(const std::string& s, size_t w) { return s.size() >= w ? s : std::string(w - s.size(), ' ') + s; }
inline std::string padr(const std::string& s, size_t w) { return s.size() >= w ? s : s + std::string(w - s.size(), ' '); }

inline void print_report(const Engine& E, const Settings& c, const Analysis& R, i64 done, double secs) {
    std::vector<int> idx;
    for (size_t i = 0; i < R.summary.size(); ++i)
        if (is_main_name(R.summary[i].name)) idx.push_back((int)i);
    auto at = [&](const std::string& n) -> const Summary& { return R.summary[(size_t)R.index_of(n)]; };
    int ndays = idx.empty() ? 0 : R.summary[(size_t)idx[0]].days;
    auto median = [](std::vector<double> v) {
        if (v.empty()) return NaN;
        std::sort(v.begin(), v.end());
        size_t n = v.size();
        return n % 2 ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
    };
    char b[256];
    std::vector<std::string> L;
    L.push_back("=========== PASTE FROM HERE ===========");
    std::snprintf(b, sizeof b, "Records %s in %.1fs | days %d | accounting check: %s", fmt((double)done).c_str(), secs, ndays,
                  R.acct_ok ? "OK" : "FAILED");
    L.push_back(b);
    std::snprintf(b, sizeof b, "Tick %g = $%g | fee $%g/fill | latency %g ms | limit %g", c.tick, c.tick_value, c.fee,
                  c.latency_ms, c.qmax);
    L.push_back(b);
    if (c.all_day) std::snprintf(b, sizeof b, "Hours UTC all day | skew %g ticks | OFI z %g", c.skew, c.ofi_z);
    else std::snprintf(b, sizeof b, "Hours UTC (%g, %g) | skew %g ticks | OFI z %g", c.hours_lo, c.hours_hi, c.skew, c.ofi_z);
    L.push_back(b);
    std::snprintf(b, sizeof b, "Book reads: good %s, crossed/empty %s (%.1f%%)", fmt((double)E.good).c_str(),
                  fmt((double)E.bad).c_str(), 100.0 * (double)E.bad / (double)std::max<i64>(E.good + E.bad, 1));
    L.push_back(b);
    std::snprintf(b, sizeof b, "Calibration (median): sigma %.2f ticks/sqrt(s), A %.2f/s, k %.2f/tick", median(E.cal_sig),
                  median(E.cal_A), median(E.cal_k));
    L.push_back(b);
    L.push_back("");
    L.push_back("MONEY ($)            net       gross      fees   fills  win-days  worst-day");
    for (int i : idx) {
        const Summary& r = R.summary[(size_t)i];
        std::string wd = padl(std::to_string(r.win_days), 6) + "/" + padr(std::to_string(r.days), 3);
        L.push_back(padr(r.name, 14) + padl(fmt(r.net, 0, true), 10) + padl(fmt(r.gross, 0, true), 12) + padl(fmt(r.fees), 10) +
                    padl(fmt((double)r.fills), 8) + wd + padl(fmt(r.worst_day, 0, true), 10));
    }
    L.push_back("");
    std::snprintf(b, sizeof b, "A fee of $%g is %.2f tick per fill: the numbers below must beat it.", c.fee, c.fee / c.tick_value);
    L.push_back(b);
    L.push_back("QUALITY (ticks per unit)  at-fill   +1s    +5s   +30s  avg|inv| max|inv|  fill%");
    for (int i : idx) {
        const Summary& r = R.summary[(size_t)i];
        auto mo = [&](size_t k) { return k < r.mo.size() ? r.mo[k] : NaN; };
        char fr[32];
        std::snprintf(fr, sizeof fr, "%.1f%%", 100.0 * r.fill_rate);
        L.push_back(padr(r.name, 14) + padl(fmt(r.spread_capture, 2, true), 10) + padl(fmt(mo(0), 2, true), 7) +
                    padl(fmt(mo(1), 2, true), 7) + padl(fmt(mo(2), 2, true), 7) + padl(fmt(r.avg_inv, 1), 9) +
                    padl(fmt(r.max_inv, 0), 8) + padl(fr, 8));
    }
    L.push_back("");
    L.push_back("PROFIT PER DAY ($, after fees)");
    const auto& labels = R.day_labels;
    for (size_t a = 0; a < labels.size(); a += 8) {
        std::string head = padr("", 14);
        for (size_t j = a; j < std::min(labels.size(), a + 8); ++j) head += padl(labels[j], 8);
        L.push_back(head);
        for (int i : idx) {
            std::string row = padr(R.summary[(size_t)i].name, 14);
            for (size_t j = a; j < std::min(labels.size(), a + 8); ++j) {
                char v[32];
                std::snprintf(v, sizeof v, "%+.0f", R.perday[(size_t)i][j]);
                row += padl(v, 8);
            }
            L.push_back(row);
        }
    }
    if (!c.decision_sweep.empty()) {
        L.push_back("");
        L.push_back("RE-QUOTE SPEED (how often the strategy may change its quotes)");
        L.push_back("                    net $    fills  at-fill   +1s    +5s   avg|inv|");
        std::vector<std::pair<std::string, std::string>> rows;
        std::vector<double> dsw = c.decision_sweep;
        std::sort(dsw.rbegin(), dsw.rend());
        for (const char* n : {"Join", "A-S"}) {
            rows.push_back({std::string(n) + " " + fmt_g(c.decision_ms) + " ms (base)", n});
            for (double d : dsw) rows.push_back({std::string(n) + " " + fmt_g(d) + " ms", std::string(n) + " dec " + fmt_g(d) + "ms"});
        }
        for (auto& pr : rows) {
            int k = R.index_of(pr.second);
            if (k < 0) continue;
            const Summary& r = R.summary[(size_t)k];
            auto mo = [&](size_t j) { return j < r.mo.size() ? r.mo[j] : NaN; };
            L.push_back(padr(pr.first, 20) + padl(fmt(r.net, 0, true), 12) + padl(fmt((double)r.fills), 9) +
                        padl(fmt(r.spread_capture, 2, true), 8) + padl(fmt(mo(0), 2, true), 7) + padl(fmt(mo(1), 2, true), 7) +
                        padl(fmt(r.avg_inv, 1), 9));
        }
    }
    L.push_back("");
    L.push_back("WHAT IF THE FEE WERE LOWER? (net $ = gross - units x fee; big firms pay far less than retail)");
    {
        std::string head = padr("", 14);
        for (double f : {0.0, 0.25, 0.5, 1.0}) head += padl("fee $" + fmt_g(f), 13);
        L.push_back(head);
        for (int i : idx) {
            const Summary& r = R.summary[(size_t)i];
            std::string row = padr(r.name, 14);
            for (double f : {0.0, 0.25, 0.5, 1.0}) row += padl(fmt(r.gross - r.all_units * f, 0, true), 13);
            L.push_back(row);
        }
    }
    if (!c.latency_sweep.empty()) {
        L.push_back("");
        L.push_back("LATENCY CHECK (A-S only)   net $   fills  +5s ticks   (the edge should shrink as latency grows)");
        std::vector<std::pair<std::string, std::string>> rows = {{fmt_g(c.latency_ms) + " ms (base)", "A-S"}};
        for (double x : c.latency_sweep) rows.push_back({fmt_g(x) + " ms", "A-S lat " + fmt_g(x) + "ms"});
        for (auto& pr : rows) {
            int k = R.index_of(pr.second);
            if (k < 0) continue;
            const Summary& r = R.summary[(size_t)k];
            double m5 = r.mo.size() > 1 ? r.mo[1] : NaN;
            L.push_back(padr(pr.first, 22) + padl(fmt(r.net, 0, true), 12) + padl(fmt((double)r.fills), 9) + padl(fmt(m5, 2, true), 11));
        }
    }
    L.push_back("");
    {
        std::string a = "Units flattened with a market order at the close: ", d = "Rejected orders (post-only): ";
        bool first = true;
        for (int i : idx) {
            const Summary& r = R.summary[(size_t)i];
            a += std::string(first ? "" : ", ") + r.name + " " + fmt(r.taker_units, 0);
            d += std::string(first ? "" : ", ") + r.name + " " + std::to_string(r.rejects);
            first = false;
        }
        L.push_back(a);
        L.push_back(d);
    }
    L.push_back("=========== PASTE UNTIL HERE ===========");
    (void)at;
    for (auto& l : L) std::printf("%s\n", l.c_str());
}

// ---------------------------------------------------------------------------------------------
// CSV files
// ---------------------------------------------------------------------------------------------
// opens a file for writing, creating its folder first; prints the reason and returns false if that fails
inline bool open_out(std::ofstream& f, const std::string& path) {
    std::error_code ec;
    std::filesystem::path p(path);
    if (p.has_parent_path()) std::filesystem::create_directories(p.parent_path(), ec);
    f.open(path, std::ios::out | std::ios::trunc);
    if (!f) {
        std::fprintf(stderr, "cannot write %s (is the folder writable, and the file not open in another program?)\n", path.c_str());
        return false;
    }
    return true;
}

inline bool write_csvs(const Settings& c, const Analysis& R, const Engine& E) {
    std::string dir = c.out_dir.empty() ? "." : c.out_dir;
    bool ok = true;
    {
        std::ofstream f;
        if (!open_out(f, dir + "/mm_summary.csv")) return false;
        f << std::setprecision(12);
        f << "strategy,net,gross,fees,fills,units,taker_units,placed,rejects,spread_capture";
        for (int h : c.markout_s) f << ",mo" << h;
        f << ",max_inv,avg_inv,win_days,days,worst_day,best_day,fill_rate,net_per_fill\n";
        for (auto& r : R.summary) {
            f << '"' << r.name << '"' << ',' << r.net << ',' << r.gross << ',' << r.fees << ',' << r.fills << ',' << r.units << ','
              << r.taker_units << ',' << r.placed << ',' << r.rejects << ',' << r.spread_capture;
            for (double m : r.mo) f << ',' << m;
            f << ',' << r.max_inv << ',' << r.avg_inv << ',' << r.win_days << ',' << r.days << ',' << r.worst_day << ',' << r.best_day
              << ',' << r.fill_rate << ',' << r.net_per_fill << '\n';
        }
    }
    {
        std::ofstream f;
        if (!open_out(f, dir + "/mm_daily.csv")) return false;
        f << std::setprecision(12);
        f << "day";
        for (auto& r : R.summary)
            if (is_main_name(r.name)) f << ',' << '"' << r.name << '"';
        f << '\n';
        for (size_t d = 0; d < R.day_labels.size(); ++d) {
            f << R.day_labels[d];
            for (size_t s = 0; s < R.summary.size(); ++s)
                if (is_main_name(R.summary[s].name)) f << ',' << R.perday[s][d];
            f << '\n';
        }
    }
    if (!R.net.empty()) {                               // equity curve and inventory, one row per minute
        std::ofstream f;
        if (!open_out(f, dir + "/mm_equity.csv")) return false;
        f << std::setprecision(12);
        f << "utc_time";
        for (auto& r : R.summary)
            if (is_main_name(r.name)) f << ",\"" << r.name << " net\",\"" << r.name << " inv\"";
        f << ",mid_ticks\n";
        for (i64 i = 0; i < E.nsec(); i += 60) {
            f << fmt_time(E.t0 + i * NS_PER_SEC, true, 0);
            for (size_t s = 0; s < R.summary.size(); ++s)
                if (is_main_name(R.summary[s].name)) f << ',' << R.net[s][(size_t)i] << ',' << R.pos[s][(size_t)i];
            f << ',' << R.mid[(size_t)i] << '\n';
        }
    }
    return ok;
}

inline bool dump_fills_csv(const std::string& path, const Engine& E) {
    std::ofstream f;
    if (!open_out(f, path)) return false;
    f << "strategy,ts,side,px,sz,kind,mid2\n";
    for (const Strat& st : E.S)
        for (const Fill& x : st.fills)
            f << '"' << st.p.name << '"' << ',' << x.ts << ',' << (int)x.side << ',' << x.px << ',' << x.sz << ',' << (int)x.kind
              << ',' << x.mid2 << '\n';
    return true;
}

}  // namespace mm
