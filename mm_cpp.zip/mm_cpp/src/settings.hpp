// settings.hpp - every setting in one place, with the same defaults as the Python version (mm_backtest.py).
// They can be changed on the command line (--tick 0.01) or in a settings file (mm_settings.txt, lines "tick = 0.01").
#pragma once
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "engine.hpp"

namespace mm {

struct Settings {
    std::string file_path = "D:\\tick data\\NQ.c.0_mbo_20250510_20250522";   // MBO file (DBN, compressed or not) or its folder
    double tick = 0.25;             // price step. NQ and MNQ: 0.25. A stock: 0.01
    double tick_value = 5.0;        // dollars per tick for ONE unit. NQ: 5.00, MNQ: 0.50, a stock share: 0.01
    double fee = 2.0;               // dollars per unit per fill (exchange + clearing + broker). Retail NQ is about 2.0
    bool all_day = false;           // quote around the clock instead of inside the hours below
    double hours_lo = 13.5, hours_hi = 20.0;   // UTC hours (09:30-16:00 US Eastern in summer)
    i64 size = 1;                   // units per quote
    double qmax = 5;                // inventory limit (units, long or short)
    double latency_ms = 1.0;        // delay between our decision and the exchange seeing it
    double decision_ms = 100;       // how often a strategy may change its quotes
    double skew = 0.5;              // A-S and GLFT: each unit of inventory moves the quotes by about this many ticks
    double horizon_s = 10.0;        // A-S: how far ahead the risk is measured (seconds)
    double ofi_z = 2.0;             // the "+ OFI" strategies pull a quote when the order-flow z-score passes this
    std::vector<int> markout_s = {1, 5, 30};
    std::vector<double> latency_sweep = {5, 20, 50};   // extra A-S runs with slower connections
    std::vector<double> decision_sweep = {10, 1};      // extra Join and A-S runs that re-quote faster
    i64 max_records = 0;            // for a quick trial, e.g. 5000000 (0 = all)
    i64 chunk = 2000000;            // records used to pick the instrument (and the batch size for reading)
    i64 probe = 200000;             // records scanned for the first timestamp
    std::string out_dir = ".";
    std::string dump_fills;         // write every fill of every strategy to this CSV (for checks)
    bool quiet = false;

    // dashboard
    std::string show = "A-S";       // strategy shown by the dashboard
    std::string from;               // start the replay at this UTC time: "HH:MM" or "YYYY-MM-DD HH:MM"
    double speed = 1.0;             // replay speed: 1 = real time, 10 = ten times faster, 0 = as fast as possible
    int frames = 0;                 // plain mode: print this many frames and exit (no keyboard, no cursor control)
    double frame_every_s = 1.0;     // plain mode: market seconds between frames
    bool plain = false;             // no colours or cursor control (logs, tests)
    bool no_color = false;
    bool ascii = false;             // plain ASCII instead of box-drawing characters (old Windows consoles)
    int ladder = 9;                 // book levels shown on each side
};

inline Config to_config(const Settings& s) {
    return make_config(s.decision_ms, 60, 600, 1000, 600, s.all_day, s.hours_lo, s.hours_hi, true);
}

inline std::string fmt_g(double x) {
    char b[32];
    std::snprintf(b, sizeof b, "%g", x);
    return b;
}

// the strategy list: 6 main ones, then re-quote speed sweeps and latency sweeps (same order as the Python runner)
inline std::vector<Params> strategy_list(const Settings& s, bool sweeps = true) {
    std::vector<Params> out;
    auto mk = [&](const std::string& name, Kind kind, double ofi, double lat_ms, double dec_ms) {
        double skew = kind == JOIN ? -1.0 : s.skew;
        return strategy(name, kind, 0.05, s.horizon_s, s.qmax, ofi, s.size, lat_ms, 1, 10, skew, dec_ms);
    };
    const std::pair<const char*, Kind> kinds[3] = {{"Join", JOIN}, {"A-S", AS}, {"GLFT", GLFT}};
    for (auto& k : kinds) {
        out.push_back(mk(k.first, k.second, 0.0, s.latency_ms, 0.0));
        out.push_back(mk(std::string(k.first) + " + OFI", k.second, s.ofi_z, s.latency_ms, 0.0));
    }
    if (sweeps) {
        for (double dec : s.decision_sweep) {
            out.push_back(mk("Join dec " + fmt_g(dec) + "ms", JOIN, 0.0, s.latency_ms, dec));
            out.push_back(mk("A-S dec " + fmt_g(dec) + "ms", AS, 0.0, s.latency_ms, dec));
        }
        for (double lat : s.latency_sweep) out.push_back(mk("A-S lat " + fmt_g(lat) + "ms", AS, 0.0, lat, 0.0));
    }
    return out;
}

inline bool is_main_name(const std::string& n) {
    return n.find(" lat ") == std::string::npos && n.find(" dec ") == std::string::npos;
}

// ---------------------------------------------------------------------------------------------
// command line / settings file
// ---------------------------------------------------------------------------------------------
inline std::vector<double> parse_list(const std::string& v) {
    std::vector<double> out;
    std::stringstream ss(v);
    std::string item;
    while (std::getline(ss, item, ',')) {
        if (item.empty()) continue;
        out.push_back(std::atof(item.c_str()));
    }
    return out;
}

// key may come as "--tick" or "tick"; returns false for an unknown key
inline bool set_option(Settings& s, std::string key, const std::string& val) {
    while (!key.empty() && key[0] == '-') key.erase(0, 1);
    for (auto& c : key)
        if (c == '_') c = '-';
    auto d = [&] { return std::atof(val.c_str()); };
    if (key == "file" || key == "path") s.file_path = val;
    else if (key == "tick") s.tick = d();
    else if (key == "tick-value") s.tick_value = d();
    else if (key == "fee") s.fee = d();
    else if (key == "allday" || key == "all-day") s.all_day = (val.empty() || val == "1" || val == "true");
    else if (key == "hours") {
        auto h = parse_list(val);
        if (h.size() == 2) {
            s.hours_lo = h[0];
            s.hours_hi = h[1];
        }
    } else if (key == "size") s.size = (i64)d();
    else if (key == "qmax") s.qmax = d();
    else if (key == "latency-ms") s.latency_ms = d();
    else if (key == "decision-ms") s.decision_ms = d();
    else if (key == "skew") s.skew = d();
    else if (key == "horizon-s") s.horizon_s = d();
    else if (key == "ofi-z") s.ofi_z = d();
    else if (key == "markout-s") {
        s.markout_s.clear();
        for (double x : parse_list(val)) s.markout_s.push_back((int)x);
    } else if (key == "latency-sweep") s.latency_sweep = parse_list(val);
    else if (key == "decision-sweep") s.decision_sweep = parse_list(val);
    else if (key == "no-sweeps") {
        if (val.empty() || val == "1" || val == "true") {
            s.latency_sweep.clear();
            s.decision_sweep.clear();
        }
    } else if (key == "max" || key == "max-records") s.max_records = (i64)d();
    else if (key == "chunk") s.chunk = (i64)d();
    else if (key == "probe") s.probe = (i64)d();
    else if (key == "out") s.out_dir = val;
    else if (key == "dump-fills") s.dump_fills = val;
    else if (key == "quiet") s.quiet = (val.empty() || val == "1" || val == "true");
    else if (key == "show") s.show = val;
    else if (key == "from") s.from = val;
    else if (key == "speed") s.speed = d();
    else if (key == "frames") s.frames = (int)d();
    else if (key == "frame-every") s.frame_every_s = d();
    else if (key == "plain") s.plain = (val.empty() || val == "1" || val == "true");
    else if (key == "no-color") s.no_color = (val.empty() || val == "1" || val == "true");
    else if (key == "ascii") s.ascii = (val.empty() || val == "1" || val == "true");
    else if (key == "ladder") s.ladder = (int)d();
    else return false;
    return true;
}

inline bool is_flag(const std::string& key) {
    std::string k = key;
    while (!k.empty() && k[0] == '-') k.erase(0, 1);
    return k == "allday" || k == "all-day" || k == "no-sweeps" || k == "quiet" || k == "plain" || k == "no-color" || k == "ascii";
}

// first: read mm_settings.txt if it exists (lines "key = value", "#" starts a comment)
inline void load_settings_file(Settings& s, const std::string& path, bool must_exist) {
    std::ifstream f(path);
    if (!f) {
        if (must_exist) {
            std::fprintf(stderr, "cannot read settings file %s\n", path.c_str());
            std::exit(2);
        }
        return;
    }
    std::string line;
    while (std::getline(f, line)) {
        size_t h = line.find('#');
        if (h != std::string::npos) line.erase(h);
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        auto trim = [](std::string x) {
            size_t a = x.find_first_not_of(" \t\r\n\"'"), b = x.find_last_not_of(" \t\r\n\"'");
            return a == std::string::npos ? std::string() : x.substr(a, b - a + 1);
        };
        std::string key = trim(line.substr(0, eq)), val = trim(line.substr(eq + 1));
        if (!set_option(s, key, val)) std::fprintf(stderr, "settings file: unknown key '%s' ignored\n", key.c_str());
    }
}

}  // namespace mm
