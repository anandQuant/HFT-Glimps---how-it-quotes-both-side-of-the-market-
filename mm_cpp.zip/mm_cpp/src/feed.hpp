// feed.hpp - "feed handler": reads the file on its own thread and hands batches of decoded messages to the engine thread.
// Real trading systems split the work the same way: one thread/core decodes the market-data feed, another runs the book
// and strategy, and they pass messages through a queue.
#pragma once
#include <algorithm>
#include <condition_variable>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

#include "dbn.hpp"
#include "engine.hpp"

namespace mm {

struct Batch {
    std::vector<Msg> m;
    size_t n = 0;
};

class BatchQueue {
public:
    explicit BatchQueue(size_t depth = 6) : depth_(depth) {}
    // producer: blocks while the queue is full
    void push(std::unique_ptr<Batch> b) {
        std::unique_lock<std::mutex> lk(mu_);
        not_full_.wait(lk, [&] { return q_.size() < depth_ || stop_; });
        if (stop_) return;
        q_.push_back(std::move(b));
        not_empty_.notify_one();
    }
    void finish() {
        std::lock_guard<std::mutex> lk(mu_);
        done_ = true;
        not_empty_.notify_all();
    }
    void cancel() {
        std::lock_guard<std::mutex> lk(mu_);
        stop_ = true;
        not_full_.notify_all();
        not_empty_.notify_all();
    }
    // consumer: nullptr when the producer is finished
    std::unique_ptr<Batch> pop() {
        std::unique_lock<std::mutex> lk(mu_);
        not_empty_.wait(lk, [&] { return !q_.empty() || done_ || stop_; });
        if (q_.empty()) return nullptr;
        auto b = std::move(q_.front());
        q_.pop_front();
        not_full_.notify_one();
        return b;
    }

private:
    size_t depth_;
    std::mutex mu_;
    std::condition_variable not_full_, not_empty_;
    std::deque<std::unique_ptr<Batch>> q_;
    bool done_ = false, stop_ = false;
};

// The instrument to simulate: the one with the most TRADES in the first records (else the most records).
// Same rule as the Python pick_target(): ties go to the smallest id.
struct TargetPick {
    u32 id = 0;
    double share = 0;
    std::vector<std::pair<u32, double>> shares;
};
inline TargetPick pick_target(const Msg* m, size_t n) {
    std::map<u32, i64> all, trades;
    for (size_t i = 0; i < n; ++i) {
        all[m[i].inst]++;
        if (m[i].action == 84) trades[m[i].inst]++;
    }
    TargetPick t;
    const std::map<u32, i64>& src = trades.empty() ? all : trades;
    i64 best = -1;
    for (auto& kv : src)
        if (kv.second > best) {
            best = kv.second;
            t.id = kv.first;
        }
    for (auto& kv : all) t.shares.push_back({kv.first, (double)kv.second / (double)std::max<size_t>(n, 1)});
    for (auto& kv : t.shares)
        if (kv.first == t.id) t.share = kv.second;
    return t;
}

}  // namespace mm
