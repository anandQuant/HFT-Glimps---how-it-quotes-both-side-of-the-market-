// common.hpp - small shared types and helpers (no dependencies)
#pragma once
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>

namespace mm {

using i8 = int8_t;
using i32 = int32_t;
using i64 = int64_t;
using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;

constexpr i64 NS_PER_SEC = 1000000000LL;
constexpr i64 UNDEF_PRICE = INT64_MAX;       // Databento "no price"

// One market-by-order record, reduced to what the engine needs (the DBN record is 56 bytes; this is 40).
struct Msg {
    i64 ts;          // ts_event, ns since the epoch (UTC)
    u64 oid;         // order id
    i64 px;          // price, fixed point 1e-9
    u32 sz;          // size
    u32 inst;        // instrument id
    u8 flags;        // 128 = last record of an exchange event, 32 = snapshot
    u8 action;       // 'A' add, 'C' cancel, 'M' modify, 'T' trade, 'F' fill, 'R' clear, 'N' none
    u8 side;         // 'B' bid, 'A' ask, 'N' none
    u8 pad;
};

// Python-style floor division and modulo (C++ truncates toward zero).
inline i64 floordiv(i64 a, i64 b) {
    i64 q = a / b;
    if ((a % b != 0) && ((a < 0) != (b < 0))) --q;
    return q;
}
inline i64 floormod(i64 a, i64 b) {
    i64 r = a % b;
    if (r != 0 && ((r < 0) != (b < 0))) r += b;
    return r;
}

inline double now_sec() {
    using clk = std::chrono::steady_clock;
    return std::chrono::duration<double>(clk::now().time_since_epoch()).count();
}
inline i64 now_ns() {
    using clk = std::chrono::steady_clock;
    return std::chrono::duration_cast<std::chrono::nanoseconds>(clk::now().time_since_epoch()).count();
}

// "2025-05-12 14:03:22.481" from ns since the epoch (UTC). Works without timezone libraries.
inline std::string fmt_time(i64 ns, bool with_date = true, int frac_digits = 3) {
    i64 s = floordiv(ns, NS_PER_SEC);
    i64 frac = ns - s * NS_PER_SEC;
    i64 days = floordiv(s, 86400);
    i64 sod = s - days * 86400;
    // civil-from-days (Howard Hinnant)
    i64 z = days + 719468;
    i64 era = (z >= 0 ? z : z - 146096) / 146097;
    i64 doe = z - era * 146097;
    i64 yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    i64 y = yoe + era * 400;
    i64 doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    i64 mp = (5 * doy + 2) / 153;
    i64 d = doy - (153 * mp + 2) / 5 + 1;
    i64 mo = mp < 10 ? mp + 3 : mp - 9;
    if (mo <= 2) ++y;
    char buf[128];
    i64 div = 1;
    for (int i = 0; i < 9 - frac_digits; ++i) div *= 10;
    if (with_date)
        std::snprintf(buf, sizeof buf, "%04lld-%02lld-%02lld %02lld:%02lld:%02lld.%0*lld", (long long)y, (long long)mo,
                      (long long)d, (long long)(sod / 3600), (long long)(sod / 60 % 60), (long long)(sod % 60), frac_digits,
                      (long long)(frac / div));
    else
        std::snprintf(buf, sizeof buf, "%02lld:%02lld:%02lld.%0*lld", (long long)(sod / 3600), (long long)(sod / 60 % 60),
                      (long long)(sod % 60), frac_digits, (long long)(frac / div));
    return buf;
}

// "MM-DD" of a UTC day number (days since the epoch)
inline std::string fmt_day(i64 days) {
    i64 z = days + 719468;
    i64 era = (z >= 0 ? z : z - 146096) / 146097;
    i64 doe = z - era * 146097;
    i64 yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    i64 doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    i64 mp = (5 * doy + 2) / 153;
    i64 d = doy - (153 * mp + 2) / 5 + 1;
    i64 mo = mp < 10 ? mp + 3 : mp - 9;
    char buf[64];
    std::snprintf(buf, sizeof buf, "%02lld-%02lld", (long long)mo, (long long)d);
    return buf;
}

// days since the epoch for a civil date
inline i64 days_from_civil(i64 y, i64 m, i64 d) {
    y -= m <= 2;
    i64 era = (y >= 0 ? y : y - 399) / 400;
    i64 yoe = y - era * 400;
    i64 doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    i64 doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

}  // namespace mm
