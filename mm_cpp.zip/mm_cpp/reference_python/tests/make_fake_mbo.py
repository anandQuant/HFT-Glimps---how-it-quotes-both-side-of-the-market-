"""
Synthetic multi-day MBO file (Databento DBN) with a consistent order book - for TESTS only, not a realistic market.
KAPPA > 0: book imbalance at the touch makes the next aggressor more likely to hit the thin side.
Usage:  python tests/make_fake_mbo.py out.mbo KAPPA EVENTS_PER_DAY [N_DAYS]
"""
import sys, numpy as np, pandas as pd, databento_dbn as dbn
from types import SimpleNamespace as NS

out, KAPPA, N_PER_DAY = sys.argv[1], float(sys.argv[2]), int(sys.argv[3])
N_DAYS = int(sys.argv[4]) if len(sys.argv) > 4 else 4
rng = np.random.default_rng(11)
S, TICK = 10**9, 0.25
days = pd.date_range("2025-05-12", periods=N_DAYS, freq="D", tz="UTC")
meta = dbn.Metadata(dataset="GLBX.MDP3", start=days[0].value, stype_in=dbn.SType.CONTINUOUS, stype_out=dbn.SType.INSTRUMENT_ID,
                    schema=dbn.Schema.MBO, symbols=["NQ.c.0"], end=(days[-1] + pd.Timedelta(days=1)).value,
                    mappings=[NS(raw_symbol="NQ.c.0", intervals=[NS(start_date=days[0].date(), end_date=(days[-1] + pd.Timedelta(days=1)).date(), symbol="42005804")])])
ACT = {"A": dbn.Action.ADD, "C": dbn.Action.CANCEL, "M": dbn.Action.MODIFY, "T": dbn.Action.TRADE, "F": dbn.Action.FILL, "R": dbn.Action.CLEAR}
SD = {"B": dbn.Side.BID, "A": dbn.Side.ASK, "N": dbn.Side.NONE}
buf = bytearray(meta.encode())
INST = 42005804
book = {"B": {}, "A": {}}       # side -> {tick: [[oid, size], ...]}
orders = {}                     # oid -> (side, tick)
oid_next = [1000]
recs = []

def emit(t, oid, tick, size, act, side, flags=128):
    px = dbn.UNDEF_PRICE if tick is None else int(tick * TICK * S)
    buf.extend(bytes(dbn.MBOMsg(1, INST, int(t), int(oid), px, int(size), ACT[act], SD[side], int(t) + 4000, flags=flags)))

def lvl_size(side, tick):
    return sum(o[1] for o in book[side].get(tick, []))

def best(side):
    lv = [k for k, v in book[side].items() if v]
    return (max(lv) if side == "B" else min(lv)) if lv else None

def add(t, side, tick, size, flags=128, oid=None):
    oid = oid or oid_next[0]; oid_next[0] += 1
    book[side].setdefault(tick, []).append([oid, size]); orders[oid] = (side, tick)
    emit(t, oid, tick, size, "A", side, flags)

def remove(t, oid, size):
    side, tick = orders[oid]
    q = book[side][tick]
    for o in q:
        if o[0] == oid:
            o[1] -= size
            if o[1] <= 0:
                q.remove(o); del orders[oid]
            break
    if not q:
        del book[side][tick]
    emit(t, oid, tick, size, "C", side)

# initial book around 20450
mid0 = int(20450 / TICK)
t = days[0].value - 2 * 3600 * S          # Sunday-evening style start, before the first UTC day
for k in range(10):
    for _ in range(3):
        add(t, "B", mid0 - 1 - k, int(rng.integers(1, 4))); add(t, "A", mid0 + k, int(rng.integers(1, 4)))
for d in days:
    # UTC-day start: clear + snapshot (re-adds every resting order, flagged F_SNAPSHOT)
    t = d.value + 1000
    emit(t, 0, None, 0, "R", "N", flags=8)
    snap = [(side, tick, o[0], o[1]) for side in "BA" for tick, q in book[side].items() for o in q]
    for i, (side, tick, oid, size) in enumerate(snap):
        emit(t, oid, tick, size, "A", side, flags=32 | (128 if i == len(snap) - 1 else 0))
    # events through the day (busier in the US session), no events 21:00-22:00
    secs = np.sort(rng.choice(np.r_[np.arange(0, 21 * 3600), np.arange(22 * 3600, 86400)], N_PER_DAY,
                              p=None) + rng.random(N_PER_DAY))
    for s in secs:
        t = d.value + int(s * S) + 5000
        bb, ba = best("B"), best("A")
        if bb is None or ba is None:
            add(t, "B" if bb is None else "A", (ba - 1) if bb is None else (bb + 1), 2); continue
        u = rng.random()
        if u < 0.38:                                        # add near the touch
            side = "B" if rng.random() < 0.5 else "A"
            k = min(int(rng.geometric(0.45)) - 1, 9)
            tick = bb - k if side == "B" else ba + k
            if tick <= bb and side == "A": tick = bb + 1
            if tick >= ba and side == "B": tick = ba - 1
            add(t, side, tick, int(rng.integers(1, 4)))
        elif u < 0.66:                                      # cancel near the touch
            side = "B" if rng.random() < 0.5 else "A"
            k = min(int(rng.geometric(0.45)) - 1, 9)
            tick = bb - k if side == "B" else ba + k
            q = book[side].get(tick, [])
            if q:
                o = q[int(rng.integers(0, len(q)))]
                remove(t, o[0], o[1])
        elif u < 0.70:                                      # modify: reduce size (keeps priority)
            side = "B" if rng.random() < 0.5 else "A"
            tick = bb if side == "B" else ba
            q = book[side].get(tick, [])
            if q and q[-1][1] > 1:
                o = q[-1]; o[1] -= 1
                emit(t, o[0], tick, o[1], "M", side)
        else:                                               # trade: aggressor hits the thin side more often when KAPPA > 0
            qb, qa = lvl_size("B", bb), lvl_size("A", ba)
            imb = (qb - qa) / max(1, qb + qa)
            side = "B" if rng.random() < 0.5 + KAPPA * imb else "A"   # bids heavier -> buyers more likely
            opp, tick = ("A", ba) if side == "B" else ("B", bb)
            qty = int(rng.integers(1, 7))
            emit(t, 0, tick, qty, "T", side, flags=0)
            q = book[opp].get(tick, [])
            left = qty
            while left > 0 and q:
                o = q[0]; f = min(left, o[1]); left -= f
                emit(t, o[0], tick, f, "F", opp, flags=0)
                remove(t, o[0], f)
                q = book[opp].get(tick, [])
open(out, "wb").write(bytes(buf))
print(out, "records:", len(buf) // 56, "orders resting at end:", len(orders))
