The Python/Numba version that the C++ program was ported from (mm_engine.py = the simulator, mm_backtest.py = the runner).
It is here so tools/parity.py can check the C++ results against it. pip install -r requirements.txt
