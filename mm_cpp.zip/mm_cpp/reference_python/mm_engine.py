"""
mm_engine.py - event-driven market-making simulator on Databento MBO (market-by-order) data, compiled with Numba.

How it works
  * The real order book is rebuilt from every MBO record (A add, C cancel, M modify, R clear; T/F/N leave it alone),
    and every real order keeps its queue priority (a modify to a new price or a bigger size loses priority).
  * Each strategy places VIRTUAL limit orders on top of the real book:
      - a new order joins the BACK of the queue at its price: everything already resting there is ahead of it;
      - orders ahead leave the queue when they are cancelled, filled or lose priority;
      - a trade at our price fills us only with the volume left over after the queue ahead is used up;
      - a trade at a worse price than ours fills us first (price priority);
      - every order action reaches the exchange LATENCY later; the old order can still be filled meanwhile;
      - orders are post-only: one that would cross the book when it arrives is rejected.
  * Strategies: JOIN (quote at the best bid and ask), AS (Avellaneda-Stoikov 2008), GLFT (Gueant-Lehalle-
    Fernandez-Tapia 2013), each with an inventory limit and an optional OFI defense (pull the side about to be run over).
  * sigma (volatility), A and k (how fast trades reach prices away from the mid) are re-estimated on a rolling
    window from past data only.
  * All strategies run in ONE pass over the data and do not affect each other (each is simulated as if alone,
    with a small size that does not move the market).
Units inside the engine: prices in TICKS, time in nanoseconds (ts) or seconds, money in ticks x contracts.
"""
import numpy as np
from numba import njit, types
from numba.typed import Dict

NT = 1 << 20            # price grid in ticks (NQ 0.25 -> up to ~262,000 points; stocks 0.01 -> up to $10,485)
SIZE_CAP = 0x1FFFFF     # largest size stored per order
NB = 6                  # calibration buckets: trades reaching 0.5, 1.5, ..., 5.5 ticks from the mid
QCAP = 256              # pending order actions per strategy

JOIN, AS, GLFT = 0, 1, 2
# strategy parameter columns
P_KIND, P_GAMMA, P_HORIZON, P_QMAX, P_OFIZ, P_SIZE, P_LAT, P_REQ, P_MAXD, P_DEC = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
N_PARAM = 10
# virtual order state columns (per strategy, per side: 0 = bid, 1 = ask)
O_ACT, O_PX, O_SZ, O_AHEAD, O_SEQ, O_CONS = 0, 1, 2, 3, 4, 5
# account columns
A_Q, A_CASH, A_NFILL, A_VOL, A_TAKERVOL, A_MAXQ, A_REJECT, A_PLACED = 0, 1, 2, 3, 4, 5, 6, 7
N_ACC = 8
# market integer state
M_BB, M_BA, M_PBB, M_PQB, M_PBA, M_PQA, M_PVAL, M_SEQ, M_LASTCAL, M_CALOK, M_GOOD, M_BAD = range(12)
# market float state
F_OFI, F_OFIM2, F_OFITS, F_SIG2, F_A, F_K, F_OFIW = range(7)
# config columns
C_DEC_NS, C_CAL_EVERY, C_CAL_WIN, C_OFI_FAST, C_OFI_SLOW, C_TH_LO, C_TH_HI, C_FLATTEN = range(8)


@njit(cache=True)
def _lvl_add(lvl, blk, t, q):
    before = lvl[t]
    after = before + q
    if after < 0:
        after = 0
    lvl[t] = after
    if before <= 0 < after:
        blk[t >> 10] += 1
    elif after <= 0 < before:
        blk[t >> 10] -= 1


@njit(cache=True)
def _rescan_bid(lvl, blk, b):
    while b >= 0:
        if blk[b >> 10] == 0:
            b = ((b >> 10) << 10) - 1
            continue
        if lvl[b] > 0:
            return b
        b -= 1
    return -1


@njit(cache=True)
def _rescan_ask(lvl, blk, a):
    n = lvl.shape[0]
    while a < n:
        if blk[a >> 10] == 0:
            a = ((a >> 10) + 1) << 10
            continue
        if lvl[a] > 0:
            return a
        a += 1
    return n


@njit(cache=True)
def _queue_out(O, pk, sd, price, amount):
    """A real order with priority pk at `price` on side sd lost `amount`: if it was ahead of our order, we move up."""
    for s in range(O.shape[0]):
        if O[s, sd, O_ACT] == 1 and O[s, sd, O_PX] == price and pk < O[s, sd, O_SEQ]:
            a = O[s, sd, O_AHEAD] - amount
            O[s, sd, O_AHEAD] = a if a > 0 else 0


@njit(cache=True)
def _record_fill(s, sgn, price, qty, kind, ts, MI, ACC, FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n):
    ACC[s, A_Q] += sgn * qty
    ACC[s, A_CASH] -= sgn * qty * price
    ACC[s, A_NFILL] += 1
    ACC[s, A_VOL] += qty
    if kind == 1:
        ACC[s, A_TAKERVOL] += qty
    aq = abs(ACC[s, A_Q])
    if aq > ACC[s, A_MAXQ]:
        ACC[s, A_MAXQ] = aq
    n = FL_n[s]
    if n < FL_ts.shape[1]:
        FL_ts[s, n] = ts
        FL_side[s, n] = sgn
        FL_px[s, n] = price
        FL_mid[s, n] = MI[M_BB] + MI[M_BA]
        FL_sz[s, n] = qty
        FL_kind[s, n] = kind
    FL_n[s] = n + 1


@njit(cache=True)
def _send(s, kind, sd, p, z, ts, P, PQ_t, PQ_k, PQ_side, PQ_px, PQ_sz, PQH, NPEND):
    if PQH[s, 1] - PQH[s, 0] >= QCAP:
        return
    j = PQH[s, 1] % QCAP
    PQ_t[s, j] = ts + np.int64(P[s, P_LAT])
    PQ_k[s, j] = kind
    PQ_side[s, j] = sd
    PQ_px[s, j] = p
    PQ_sz[s, j] = z
    PQH[s, 1] += 1
    if kind == 1:
        NPEND[s, sd] += 1


@njit(cache=True)
def _calibrate(sec, MI, MF, MIDL, TRC, cfg, CAL_SIG, CAL_A, CAL_K):
    """sigma^2 (ticks^2 per second) and the fill-rate curve lambda(delta) = A exp(-k delta), from the last window only."""
    W = int(cfg[C_CAL_WIN])
    lo = sec - W
    if lo < 0:
        lo = 0
    MI[M_LASTCAL] = sec
    acc, nsec, prev, started = 0.0, 0, 0.0, False
    for j in range(lo, sec):
        m = MIDL[j]
        if m >= 0:
            if started:
                d = (m - prev) / 2.0
                acc += d * d
            prev = m
            started = True
        if started:
            nsec += 1
    if nsec < W // 4:
        return
    lam = np.zeros(NB)
    tot = 0.0
    for b in range(NB - 1, -1, -1):
        c = 0.0
        for j in range(lo, sec):
            c += TRC[j, b]
        tot += c
        lam[b] = tot / nsec
    sx, sy, sxx, sxy, m_ = 0.0, 0.0, 0.0, 0.0, 0
    for b in range(NB):
        if lam[b] > 0:
            x = 0.5 + b
            yv = np.log(lam[b])
            sx += x
            sy += yv
            sxx += x * x
            sxy += x * yv
            m_ += 1
    if m_ < 2 or acc <= 0:
        return
    slope = (m_ * sxy - sx * sy) / (m_ * sxx - sx * sx)
    k = -slope
    if k < 0.05:
        k = 0.05
    if k > 20.0:
        k = 20.0
    A = np.exp((sy - slope * sx) / m_)
    MF[F_SIG2], MF[F_A], MF[F_K] = acc / nsec, A, k
    MI[M_CALOK] = 1
    CAL_SIG[sec], CAL_A[sec], CAL_K[sec] = np.sqrt(acc / nsec), A, k


@njit(cache=True)
def run_chunk(ts, act, side, px, sz, oid, flg, inst, target, t0, tick_fx,
              orders, prio, bid_lvl, ask_lvl, bid_blk, ask_blk, MI, MF,
              P, O, DS, NPEND, PQ_t, PQ_k, PQ_side, PQ_px, PQ_sz, PQH, ACC, LASTDEC, FLATTING,
              FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n,
              POS, CASH, QB, QA, MIDL, BBP, BAP, BBS, BAS, TRC, CAL_SIG, CAL_A, CAL_K, OFIZ, cfg):
    nsec = MIDL.shape[0]
    n = bid_lvl.shape[0]
    NS = P.shape[0]
    undef = np.int64(9223372036854775807)
    for i in range(ts.shape[0]):
        if inst[i] != target:
            continue
        t_now = ts[i]
        sec = (t_now - t0) // 1000000000
        rec = sec >= 0 and sec < nsec
        a, s_ = act[i], side[i]

        # ---- 1) our order actions that reach the exchange before this event ----
        for s in range(NS):
            while PQH[s, 0] < PQH[s, 1]:
                j = PQH[s, 0] % QCAP
                if PQ_t[s, j] > t_now:
                    break
                kind, sd, p, z = PQ_k[s, j], PQ_side[s, j], PQ_px[s, j], PQ_sz[s, j]
                PQH[s, 0] += 1
                if kind == 1:                                    # place (replaces any live order on that side)
                    NPEND[s, sd] -= 1
                    bb, ba = MI[M_BB], MI[M_BA]
                    if (sd == 0 and p >= ba) or (sd == 1 and p <= bb) or p < 0 or p >= n:
                        O[s, sd, O_ACT] = 0                      # post-only: would cross -> rejected
                        ACC[s, A_REJECT] += 1
                        if NPEND[s, sd] == 0:
                            DS[s, sd] = -1
                    else:
                        O[s, sd, O_ACT] = 1
                        O[s, sd, O_PX] = p
                        O[s, sd, O_SZ] = z
                        O[s, sd, O_AHEAD] = bid_lvl[p] if sd == 0 else ask_lvl[p]
                        O[s, sd, O_SEQ] = MI[M_SEQ]
                        O[s, sd, O_CONS] = 0
                        MI[M_SEQ] += 1
                        ACC[s, A_PLACED] += 1
                elif kind == 2:                                  # cancel
                    O[s, sd, O_ACT] = 0
                else:                                            # market order to flatten (taker)
                    if sd == 0 and MI[M_BA] < n:
                        _record_fill(s, 1, MI[M_BA], z, 1, t_now, MI, ACC, FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n)
                    elif sd == 1 and MI[M_BB] >= 0:
                        _record_fill(s, -1, MI[M_BB], z, 1, t_now, MI, ACC, FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n)
                    FLATTING[s] = 0

        # ---- 2) the real market event ----
        if a == 82:                                              # R: clear the book (our virtual orders go too)
            orders.clear()
            prio.clear()
            bid_lvl[:] = 0
            ask_lvl[:] = 0
            bid_blk[:] = 0
            ask_blk[:] = 0
            MI[M_BB], MI[M_BA], MI[M_PVAL] = -1, n, 0
            for s in range(NS):
                for sd in range(2):
                    O[s, sd, O_ACT] = 0
                    if NPEND[s, sd] == 0:
                        DS[s, sd] = -1
            continue
        if a == 84:                                              # T: an aggressive trade
            if px[i] != undef and (s_ == 65 or s_ == 66):
                pt = px[i] // tick_fx
                x = sz[i]
                bb, ba = MI[M_BB], MI[M_BA]
                if rec and bb >= 0 and ba < n:                   # calibration: how far from the mid did it reach?
                    dh = 2 * pt - (bb + ba)
                    if dh < 0:
                        dh = -dh
                    b = (dh - 1) // 2
                    if b >= 0 and b < NB:
                        TRC[sec, b] += 1
                sd = 0 if s_ == 65 else 1                        # seller hits bids (side 0); buyer lifts asks (side 1)
                for s in range(NS):
                    if O[s, sd, O_ACT] == 1:
                        p = O[s, sd, O_PX]
                        fill = 0
                        if (sd == 0 and pt < p) or (sd == 1 and pt > p):
                            fill = x                             # it traded through our price: we were first
                        elif pt == p:
                            avail = O[s, sd, O_AHEAD] - O[s, sd, O_CONS]
                            if avail < 0:
                                avail = 0
                            fill = x - avail                     # only what is left after the queue ahead of us
                            O[s, sd, O_CONS] += x
                        if fill > 0:
                            left = O[s, sd, O_SZ]
                            if fill > left:
                                fill = left
                            _record_fill(s, 1 if sd == 0 else -1, p, fill, 0, t_now, MI, ACC,
                                         FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n)
                            O[s, sd, O_SZ] = left - fill
                            if left - fill == 0:
                                O[s, sd, O_ACT] = 0
                                if NPEND[s, sd] == 0:
                                    DS[s, sd] = -1
        elif a == 65 or a == 67 or a == 77:                      # A / C / M change the real book
            k = oid[i]
            newv = a != 67 and px[i] != undef and sz[i] > 0 and (s_ == 66 or s_ == 65)
            tnew = px[i] // tick_fx if newv else -1
            if newv and (tnew < 0 or tnew >= n):
                newv = False
            qnew = sz[i] if sz[i] < SIZE_CAP else SIZE_CAP
            bnew = 1 if s_ == 66 else 0
            add_new = newv
            if k in orders:
                v = orders[k]
                ot, osz, ob = v >> 22, (v >> 1) & SIZE_CAP, v & 1
                pk = prio[k]
                osd = 0 if ob == 1 else 1
                if a == 77 and newv and tnew == ot and qnew <= osz and bnew == ob:
                    d = osz - qnew                               # modify down in place: keeps its priority
                    if d > 0:
                        if ob == 1:
                            _lvl_add(bid_lvl, bid_blk, ot, -d)
                        else:
                            _lvl_add(ask_lvl, ask_blk, ot, -d)
                        _queue_out(O, pk, osd, ot, d)
                    orders[k] = (ot << 22) | (qnew << 1) | ob
                    add_new = False
                else:
                    rem = (sz[i] if sz[i] < osz else osz) if a == 67 else osz
                    if ob == 1:
                        _lvl_add(bid_lvl, bid_blk, ot, -rem)
                        if ot == MI[M_BB] and bid_lvl[ot] <= 0:
                            MI[M_BB] = _rescan_bid(bid_lvl, bid_blk, ot)
                    else:
                        _lvl_add(ask_lvl, ask_blk, ot, -rem)
                        if ot == MI[M_BA] and ask_lvl[ot] <= 0:
                            MI[M_BA] = _rescan_ask(ask_lvl, ask_blk, ot)
                    _queue_out(O, pk, osd, ot, rem)
                    if a == 67 and osz - rem > 0:
                        orders[k] = (ot << 22) | ((osz - rem) << 1) | ob
                    else:
                        del orders[k]
                        del prio[k]
            if add_new:                                          # a new order, or a modified one that lost priority
                orders[k] = (tnew << 22) | (qnew << 1) | bnew
                prio[k] = MI[M_SEQ]
                MI[M_SEQ] += 1
                if bnew == 1:
                    _lvl_add(bid_lvl, bid_blk, tnew, qnew)
                    if tnew > MI[M_BB]:
                        MI[M_BB] = tnew
                else:
                    _lvl_add(ask_lvl, ask_blk, tnew, qnew)
                    if tnew < MI[M_BA]:
                        MI[M_BA] = tnew

        # ---- 3) end of an exchange event: read the book, update signals, let strategies act ----
        if (flg[i] & 128) != 0 and (flg[i] & 32) == 0:
            bb, ba = MI[M_BB], MI[M_BA]
            ok = bb >= 0 and ba < n and bb < ba
            if ok:
                ok = bid_lvl[bb] > 0 and ask_lvl[ba] > 0
            for s in range(NS):
                O[s, 0, O_CONS] = 0
                O[s, 1, O_CONS] = 0
            if not ok:
                MI[M_PVAL] = 0
                MI[M_BAD] += 1
                continue
            MI[M_GOOD] += 1
            qb, qa = bid_lvl[bb], ask_lvl[ba]
            e = 0.0
            if MI[M_PVAL] == 1:                                  # OFI increment (Cont, Kukanov & Stoikov 2014)
                if bb >= MI[M_PBB]:
                    e += qb
                if bb <= MI[M_PBB]:
                    e -= MI[M_PQB]
                if ba <= MI[M_PBA]:
                    e -= qa
                if ba >= MI[M_PBA]:
                    e += MI[M_PQA]
            MI[M_PBB], MI[M_PQB], MI[M_PBA], MI[M_PQA], MI[M_PVAL] = bb, qb, ba, qa, 1
            dt = t_now - MF[F_OFITS]
            if MF[F_OFITS] == 0 or dt > 5.0 * cfg[C_OFI_SLOW]:   # first event, or after a long gap: start the averages empty
                MF[F_OFI], MF[F_OFIM2], MF[F_OFIW] = 0.0, 0.0, 0.0
                dt = 0
            if dt < 0:
                dt = 0
            af = np.exp(-dt / cfg[C_OFI_FAST])
            asl = np.exp(-dt / cfg[C_OFI_SLOW])
            MF[F_OFI] = MF[F_OFI] * af + e
            MF[F_OFIM2] = MF[F_OFIM2] * asl + (1.0 - asl) * MF[F_OFI] * MF[F_OFI]
            MF[F_OFIW] = MF[F_OFIW] * asl + (1.0 - asl)          # weight so far: corrects the start-up bias of the average
            MF[F_OFITS] = t_now
            ofiz = 0.0                                           # no z-score until the slow average has ~5% of its window
            if MF[F_OFIW] > 0.05 and MF[F_OFIM2] > 0:
                ofiz = MF[F_OFI] / np.sqrt(MF[F_OFIM2] / MF[F_OFIW])
            # a real order now rests at or through our virtual price: it would have traded with us
            for s in range(NS):
                if O[s, 0, O_ACT] == 1 and ba <= O[s, 0, O_PX]:
                    p = O[s, 0, O_PX]
                    f = O[s, 0, O_SZ] if O[s, 0, O_SZ] < qa else qa
                    _record_fill(s, 1, p, f, 0, t_now, MI, ACC, FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n)
                    O[s, 0, O_SZ] -= f
                    if O[s, 0, O_SZ] <= 0:
                        O[s, 0, O_ACT] = 0
                        if NPEND[s, 0] == 0:
                            DS[s, 0] = -1
                if O[s, 1, O_ACT] == 1 and bb >= O[s, 1, O_PX]:
                    p = O[s, 1, O_PX]
                    f = O[s, 1, O_SZ] if O[s, 1, O_SZ] < qb else qb
                    _record_fill(s, -1, p, f, 0, t_now, MI, ACC, FL_ts, FL_side, FL_px, FL_mid, FL_sz, FL_kind, FL_n)
                    O[s, 1, O_SZ] -= f
                    if O[s, 1, O_SZ] <= 0:
                        O[s, 1, O_ACT] = 0
                        if NPEND[s, 1] == 0:
                            DS[s, 1] = -1
            if not rec:
                continue
            MIDL[sec] = bb + ba
            BBP[sec], BAP[sec], BBS[sec], BAS[sec] = bb, ba, qb, qa
            OFIZ[sec] = ofiz
            if sec - MI[M_LASTCAL] >= cfg[C_CAL_EVERY]:
                _calibrate(sec, MI, MF, MIDL, TRC, cfg, CAL_SIG, CAL_A, CAL_K)
            sod = (t_now // 1000000000) % 86400
            lo_, hi_ = cfg[C_TH_LO], cfg[C_TH_HI]
            inside = (sod >= lo_ and sod < hi_) if lo_ < hi_ else (sod >= lo_ or sod < hi_)
            mid = (bb + ba) / 2.0
            for s in range(NS):
                dec_ns = P[s, P_DEC] if P[s, P_DEC] > 0 else cfg[C_DEC_NS]     # this strategy's own re-quote interval, else the global one
                if t_now - LASTDEC[s] >= dec_ns:
                    LASTDEC[s] = t_now
                    q = ACC[s, A_Q]
                    size = np.int64(P[s, P_SIZE])
                    wb, wa = np.int64(-1), np.int64(-1)
                    if not inside:
                        if cfg[C_FLATTEN] > 0 and q != 0 and FLATTING[s] == 0:
                            _send(s, 3, 1 if q > 0 else 0, 0, np.int64(abs(q)), t_now, P,
                                  PQ_t, PQ_k, PQ_side, PQ_px, PQ_sz, PQH, NPEND)
                            FLATTING[s] = 1
                    elif FLATTING[s] == 0:
                        kind = int(P[s, P_KIND])
                        if kind == JOIN:
                            wb, wa = bb, ba
                        elif MI[M_CALOK] == 1:
                            sig2, A, kk, g = MF[F_SIG2], MF[F_A], MF[F_K], P[s, P_GAMMA]
                            if g < 0:                            # scale-free setting: |g| = ticks of quote shift per unit of inventory
                                g = -g / (max(sig2, 1e-3) * P[s, P_HORIZON])
                            if kind == AS:
                                H = P[s, P_HORIZON]
                                r = mid - q * g * sig2 * H
                                half = 0.5 * (g * sig2 * H + 2.0 / g * np.log(1.0 + g / kk))
                                wb, wa = np.int64(np.floor(r - half)), np.int64(np.ceil(r + half))
                            else:
                                base = np.log(1.0 + g / kk) / g
                                C = np.sqrt(sig2 * g / (2.0 * kk * A) * (1.0 + g / kk) ** (1.0 + kk / g))
                                wb = np.int64(np.floor(mid - (base + (2.0 * q + 1.0) / 2.0 * C)))
                                wa = np.int64(np.ceil(mid + (base - (2.0 * q - 1.0) / 2.0 * C)))
                        if wb >= 0:
                            if wb > ba - 1:
                                wb = ba - 1                      # post-only: never cross the spread
                            if wb < bb - P[s, P_MAXD]:
                                wb = -1
                        if wa >= 0:
                            if wa < bb + 1:
                                wa = bb + 1
                            if wa > ba + P[s, P_MAXD]:
                                wa = -1
                        if q + size > P[s, P_QMAX]:
                            wb = -1                              # inventory limit
                        if q - size < -P[s, P_QMAX]:
                            wa = -1
                        oz = P[s, P_OFIZ]
                        if oz > 0:                               # OFI defense: pull the side about to be run over
                            if ofiz > oz:
                                wa = -1
                            if ofiz < -oz:
                                wb = -1
                    for sd in range(2):
                        w = wb if sd == 0 else wa
                        cur = DS[s, sd]
                        if w == cur:
                            continue
                        if w == -1:
                            _send(s, 2, sd, 0, 0, t_now, P, PQ_t, PQ_k, PQ_side, PQ_px, PQ_sz, PQH, NPEND)
                            DS[s, sd] = -1
                        elif cur == -1 or abs(w - cur) >= P[s, P_REQ]:
                            _send(s, 1, sd, w, size, t_now, P, PQ_t, PQ_k, PQ_side, PQ_px, PQ_sz, PQH, NPEND)
                            DS[s, sd] = w
                POS[s, sec] = ACC[s, A_Q]
                CASH[s, sec] = ACC[s, A_CASH]
                QB[s, sec] = O[s, 0, O_PX] if O[s, 0, O_ACT] == 1 else -1
                QA[s, sec] = O[s, 1, O_PX] if O[s, 1, O_ACT] == 1 else -1


# -------------------------------------------------------------------------------------------------
# Python side: set up the state, stream the file through the engine, return plain numpy arrays
# -------------------------------------------------------------------------------------------------
def strategy(kind, gamma=0.05, horizon_s=10.0, qmax=5, ofi_z=0.0, size=1, latency_ms=1.0, requote_ticks=1, max_depth_ticks=10,
             skew_ticks=None, decision_ms=None):
    """One strategy's settings. kind: 'join', 'as' or 'glft'.
    gamma (risk aversion, per tick) is the paper's number. skew_ticks is an easier way to set it: each unit of inventory
    shifts the quotes by about that many ticks (gamma = skew_ticks / (sigma^2 * horizon_s), re-computed from the
    calibrated sigma, so the same setting works for NQ at 0.25 and for a stock at 0.01). ofi_z = 0 turns the OFI defense off.
    decision_ms: how often this strategy may change its quotes (None = the global value from make_config)."""
    k = {"join": JOIN, "as": AS, "glft": GLFT}[kind]
    if skew_ticks is not None:
        gamma = -float(skew_ticks)
    p = np.zeros(N_PARAM)
    p[P_KIND], p[P_GAMMA], p[P_HORIZON], p[P_QMAX], p[P_OFIZ] = k, gamma, horizon_s, qmax, ofi_z
    p[P_SIZE], p[P_LAT], p[P_REQ], p[P_MAXD] = size, latency_ms * 1e6, requote_ticks, max_depth_ticks
    p[P_DEC] = 0.0 if decision_ms is None else decision_ms * 1e6
    return p


def make_state(n_strat, nsec, max_fills=300_000):
    z = np.zeros
    st = dict(
        orders=Dict.empty(key_type=types.uint64, value_type=types.int64),
        prio=Dict.empty(key_type=types.uint64, value_type=types.int64),
        bid_lvl=z(NT, np.int64), ask_lvl=z(NT, np.int64), bid_blk=z(NT >> 10, np.int64), ask_blk=z(NT >> 10, np.int64),
        MI=np.array([-1, NT, 0, 0, 0, 0, 0, 0, -10**9, 0, 0, 0], np.int64), MF=z(7),
        O=z((n_strat, 2, 6), np.int64), DS=np.full((n_strat, 2), -1, np.int64), NPEND=z((n_strat, 2), np.int64),
        PQ_t=z((n_strat, QCAP), np.int64), PQ_k=z((n_strat, QCAP), np.int64), PQ_side=z((n_strat, QCAP), np.int64),
        PQ_px=z((n_strat, QCAP), np.int64), PQ_sz=z((n_strat, QCAP), np.int64), PQH=z((n_strat, 2), np.int64),
        ACC=z((n_strat, N_ACC)), LASTDEC=np.full(n_strat, -10**18, np.int64), FLATTING=z(n_strat, np.int64),
        FL_ts=z((n_strat, max_fills), np.int64), FL_side=z((n_strat, max_fills), np.int8),
        FL_px=z((n_strat, max_fills), np.int64), FL_mid=z((n_strat, max_fills), np.int64),
        FL_sz=z((n_strat, max_fills), np.int64), FL_kind=z((n_strat, max_fills), np.int8), FL_n=z(n_strat, np.int64),
        POS=np.full((n_strat, nsec), np.nan, np.float32), CASH=np.full((n_strat, nsec), np.nan),
        QB=np.full((n_strat, nsec), np.nan, np.float32), QA=np.full((n_strat, nsec), np.nan, np.float32),
        MIDL=np.full(nsec, -1.0), BBP=np.full(nsec, np.nan), BAP=np.full(nsec, np.nan),
        BBS=np.full(nsec, np.nan), BAS=np.full(nsec, np.nan), TRC=z((nsec, NB), np.float32),
        CAL_SIG=np.full(nsec, np.nan), CAL_A=np.full(nsec, np.nan), CAL_K=np.full(nsec, np.nan),
        OFIZ=np.full(nsec, np.nan, np.float32))
    st["MF"][2] = 0.0
    return st


def make_config(decision_ms=100, calib_every_s=60, calib_window_s=600, ofi_fast_ms=1000, ofi_slow_s=600,
                trade_hours_utc=(13.5, 20.0), flatten_outside=True):
    c = np.zeros(8)
    c[C_DEC_NS], c[C_CAL_EVERY], c[C_CAL_WIN] = decision_ms * 1e6, calib_every_s, calib_window_s
    c[C_OFI_FAST], c[C_OFI_SLOW] = ofi_fast_ms * 1e6, ofi_slow_s * 1e9
    lo, hi = (0.0, 24.0) if trade_hours_utc is None else trade_hours_utc
    c[C_TH_LO], c[C_TH_HI], c[C_FLATTEN] = lo * 3600, hi * 3600, 1.0 if flatten_outside else 0.0
    return c


def step(st, P, cfg, arr, target, t0, tick_fx):
    """Runs one chunk of DBN records (a numpy structured array from DBNStore.to_ndarray) through the engine."""
    c = np.ascontiguousarray
    run_chunk(c(arr["ts_event"]).astype(np.int64), c(arr["action"]).view(np.uint8), c(arr["side"]).view(np.uint8),
              c(arr["price"]).astype(np.int64), c(arr["size"]).astype(np.int64), c(arr["order_id"]).astype(np.uint64),
              c(arr["flags"]).astype(np.int64), c(arr["instrument_id"]).astype(np.int64), target, t0, tick_fx,
              st["orders"], st["prio"], st["bid_lvl"], st["ask_lvl"], st["bid_blk"], st["ask_blk"], st["MI"], st["MF"],
              P, st["O"], st["DS"], st["NPEND"], st["PQ_t"], st["PQ_k"], st["PQ_side"], st["PQ_px"], st["PQ_sz"],
              st["PQH"], st["ACC"], st["LASTDEC"], st["FLATTING"], st["FL_ts"], st["FL_side"], st["FL_px"],
              st["FL_mid"], st["FL_sz"], st["FL_kind"], st["FL_n"], st["POS"], st["CASH"], st["QB"], st["QA"],
              st["MIDL"], st["BBP"], st["BAP"], st["BBS"], st["BAS"], st["TRC"], st["CAL_SIG"], st["CAL_A"],
              st["CAL_K"], st["OFIZ"], cfg)


def time_axis(store, probe=200_000):
    """(t0_ns, nsec): the second-grid origin and length for a DBNStore. t0 is the earlier of the header start and the
    first event (some files carry events from just before their header start), floored to a whole second."""
    md = store.metadata
    first = int(next(iter(store.to_ndarray(count=probe)))["ts_event"].min())
    t0 = (min(int(md.start), first) // 10**9) * 10**9
    return t0, int((int(md.end) - t0) // 10**9) + 2


def pick_target(arr):
    """Instrument id to simulate: the one with the most TRADES in this chunk (else the most records). Returns
    (id, share of records per id, ids)."""
    ids, cnt = np.unique(arr["instrument_id"], return_counts=True)
    tr = arr["instrument_id"][np.ascontiguousarray(arr["action"]).view(np.uint8) == 84]
    if len(tr):
        tid, tc = np.unique(tr, return_counts=True)
        best = int(tid[tc.argmax()])
    else:
        best = int(ids[cnt.argmax()])
    return best, (cnt / cnt.sum()).round(3).tolist(), ids.tolist()


def data_path(path):
    """The file itself, or the largest data file inside a folder."""
    import os
    if os.path.isdir(path):
        files = [os.path.join(path, f) for f in os.listdir(path)
                 if os.path.isfile(os.path.join(path, f)) and not f.lower().endswith((".json", ".txt", ".md"))]
        path = max(files, key=os.path.getsize)
        print("Using the largest file in the folder:", path)
    return path
