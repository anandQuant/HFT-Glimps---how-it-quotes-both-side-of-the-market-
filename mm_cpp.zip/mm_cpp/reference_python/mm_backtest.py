"""
mm_backtest.py - replay real order-book data and test market-making strategies on it.

   Jupyter:   %run mm_backtest.py
   Terminal:  python mm_backtest.py [file.mbo] [--allday] [--max 3000000]

It runs 6 strategies side by side on the SAME data (each one is simulated as if it were alone):
   Join        quote at the best bid and best ask (the simple baseline)
   A-S         Avellaneda-Stoikov: quotes move with your inventory and the volatility
   GLFT        Gueant-Lehalle-Fernandez-Tapia: same idea with a hard inventory limit
   "+ OFI"     the same strategy, but it pulls the quote that is about to be run over (order-flow imbalance)

Needs MBO data (market-by-order) from Databento. For a stock: set TICK = 0.01, TICK_VALUE = 0.01 (dollars per share),
FEE_PER_FILL per share, and use a file that holds ONE symbol.
"""
import os
import sys
import time
import numpy as np
import pandas as pd
import databento as db
import matplotlib

try:
    get_ipython()                                   # in Jupyter: show the charts
except NameError:
    matplotlib.use("Agg")                           # in a terminal: only save them
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mm_engine as E

# =====================================  SETTINGS  =====================================
FILE_PATH = r"D:\tick data\NQ.c.0_mbo_20250510_20250522"   # MBO file (DBN, compressed or not) or its folder
TICK = 0.25                 # price step. NQ and MNQ: 0.25. A stock: 0.01
TICK_VALUE = 5.0            # dollars per tick for ONE unit. NQ: 5.00, MNQ: 0.50, a stock share: 0.01
FEE_PER_FILL = 2.0          # dollars per unit per fill (exchange + clearing + broker). Retail NQ is about 2.0
TRADE_HOURS_UTC = (13.5, 20.0)   # quote only inside these hours, flat outside (09:30-16:00 US Eastern in summer)
SIZE = 1                    # units per quote
QMAX = 5                    # inventory limit (units, long or short)
LATENCY_MS = 1.0            # delay between our decision and the exchange seeing it
DECISION_MS = 100           # how often a strategy may change its quotes
SKEW_TICKS = 0.5            # A-S and GLFT: each unit of inventory moves the quotes by about this many ticks
HORIZON_S = 10.0            # A-S: how far ahead the risk is measured (seconds)
OFI_Z = 2.0                 # the "+ OFI" strategies pull a quote when the order-flow z-score passes this
MARKOUT_S = (1, 5, 30)      # seconds after a fill at which we check where the price went
LATENCY_SWEEP_MS = (5, 20, 50)   # extra A-S runs with slower connections: a reality check (() = off)
DECISION_SWEEP_MS = (10, 1)      # extra Join and A-S runs that re-quote faster than DECISION_MS (() = off)
MAX_RECORDS = None          # for a quick trial, e.g. 5_000_000
CHUNK = 2_000_000           # records per step (memory)
FILL_CAP = 500_000          # fills kept per strategy per step
# =======================================================================================

args = [a for a in sys.argv[1:] if not a.startswith("-")]
if "--allday" in sys.argv:
    TRADE_HOURS_UTC = None
if "--max" in sys.argv:
    MAX_RECORDS = int(sys.argv[sys.argv.index("--max") + 1])
    args = [a for a in args if a != str(MAX_RECORDS)]
if args:
    FILE_PATH = args[0]
OUT_DIR = os.getcwd()


def strategy_list():
    base = dict(size=SIZE, qmax=QMAX, latency_ms=LATENCY_MS, horizon_s=HORIZON_S)
    out = []
    for name, kind in (("Join", "join"), ("A-S", "as"), ("GLFT", "glft")):
        extra = {} if kind == "join" else dict(skew_ticks=SKEW_TICKS)
        out.append((name, E.strategy(kind, **base, **extra)))
        out.append((name + " + OFI", E.strategy(kind, ofi_z=OFI_Z, **base, **extra)))
    for dec in DECISION_SWEEP_MS:
        for name, kind in (("Join", "join"), ("A-S", "as")):
            extra = {} if kind == "join" else dict(skew_ticks=SKEW_TICKS)
            out.append((f"{name} dec {dec:g}ms", E.strategy(kind, decision_ms=dec, **base, **extra)))
    for lat in LATENCY_SWEEP_MS:
        out.append((f"A-S lat {lat:g}ms", E.strategy("as", **{**base, "latency_ms": lat}, skew_ticks=SKEW_TICKS)))
    return out


def main_names(names):
    return [n for n in names if " lat " not in n and " dec " not in n]


# ---------------------------------------------------------------------------------------------
# 1) RUN: stream the file through the engine
# ---------------------------------------------------------------------------------------------
def run_engine(path):
    store = db.DBNStore.from_file(path)
    md = store.metadata
    if str(md.schema).lower() != "mbo":
        raise SystemExit(f"This needs MBO data (market by order); the file schema is {md.schema}")
    t0, nsec = E.time_axis(store)
    print(f"File: {md.dataset} | {pd.Timestamp(md.start, tz='UTC')} -> {pd.Timestamp(md.end, tz='UTC')}")
    names, params = zip(*strategy_list())
    P = np.array(params)
    st = E.make_state(len(P), nsec, FILL_CAP)
    cfg = E.make_config(decision_ms=DECISION_MS, trade_hours_utc=TRADE_HOURS_UTC, flatten_outside=True)
    fields = ("ts", "side", "px", "mid2", "sz", "kind")
    src = dict(ts="FL_ts", side="FL_side", px="FL_px", mid2="FL_mid", sz="FL_sz", kind="FL_kind")
    fl = [{f: [] for f in fields} for _ in names]
    tick_fx = int(round(TICK * 1e9))
    target, done, t_start = None, 0, time.time()
    for k, arr in enumerate(store.to_ndarray(count=CHUNK)):
        if target is None:
            target, share, ids = E.pick_target(arr)
            print(f"Instrument id used: {target} ({dict(zip(ids, share))[target]:.0%} of the first records)")
            if dict(zip(ids, share))[target] < 0.9:
                print("  note: the file holds other instruments too; they are ignored.")
        E.step(st, P, cfg, arr, target, t0, tick_fx)
        n = st["FL_n"].copy()
        if n.max() > FILL_CAP:
            raise SystemExit("Too many fills in one step - lower CHUNK or raise FILL_CAP.")
        for s in range(len(names)):
            for f in fields:
                fl[s][f].append(st[src[f]][s, :int(n[s])].copy())
        st["FL_n"][:] = 0
        done += len(arr)
        last = pd.Timestamp(int(arr["ts_event"][-1]), tz="UTC")
        el = time.time() - t_start
        print(f"step {k + 1}: {done:,} records | up to {last:%Y-%m-%d %H:%M} UTC | {el:.0f} s ({done / el / 1e6:.2f} M/s)")
        if MAX_RECORDS and done >= MAX_RECORDS:
            print(f"Stopped at MAX_RECORDS = {MAX_RECORDS:,}")
            break
    fl = [{f: np.concatenate(v[f]) if v[f] else np.zeros(0) for f in fields} for v in fl]
    return st, fl, list(names), t0, nsec, done, time.time() - t_start


# ---------------------------------------------------------------------------------------------
# 2) ANALYSE: money, per-day money, markouts, inventory
# ---------------------------------------------------------------------------------------------
def analyse(st, fl, names, t0, nsec):
    NS = len(names)
    idx = pd.to_datetime(t0 + np.arange(nsec, dtype=np.int64) * 10**9, utc=True)
    valid = np.isfinite(st["BBP"])
    mid = pd.Series(np.where(st["MIDL"] >= 0, st["MIDL"] / 2.0, np.nan)).ffill().bfill().fillna(0).values   # ticks
    pos = pd.DataFrame(st["POS"].T).ffill().fillna(0).values
    cash = pd.DataFrame(st["CASH"].T).ffill().fillna(0).values
    gross = (cash + pos * mid[:, None]) * TICK_VALUE                       # dollars, marked at the mid
    fee_cum = np.zeros((nsec, NS))
    for s in range(NS):
        sec = np.clip((fl[s]["ts"] - t0) // 10**9, 0, nsec - 1).astype(np.int64)
        fee_cum[:, s] = np.cumsum(np.bincount(sec, weights=fl[s]["sz"].astype(float), minlength=nsec)) * FEE_PER_FILL
    net = gross - fee_cum

    day = (idx + pd.Timedelta(hours=2)).floor("D")                          # CME trading day
    last = pd.DataFrame(net, index=idx, columns=names).groupby(day).last()
    perday = last.diff()
    perday.iloc[0] = last.iloc[0]
    sod = ((t0 // 10**9) + np.arange(nsec)) % 86400
    if TRADE_HOURS_UTC is None:
        inside = valid
    else:
        inside = valid & (sod >= TRADE_HOURS_UTC[0] * 3600) & (sod < TRADE_HOURS_UTC[1] * 3600)
    active = pd.Series(inside, index=idx).groupby(day).sum() > 60
    perday = perday[active.reindex(perday.index).fillna(False).values]
    perday.index = perday.index.strftime("%m-%d")

    rows = []
    for s, n in enumerate(names):
        f = fl[s]
        maker = f["kind"] == 0
        sgn, px, sz = f["side"].astype(float), f["px"].astype(float), f["sz"].astype(float)
        sec = np.clip((f["ts"] - t0) // 10**9, 0, nsec - 1).astype(np.int64)
        w = sz[maker]
        wsum = w.sum()

        def wavg(v):
            return float((v[maker] * w).sum() / wsum) if wsum > 0 else np.nan

        r = dict(strategy=n,
                 net=net[-1, s], gross=gross[-1, s], fees=fee_cum[-1, s],
                 fills=int(maker.sum()), units=float(wsum), taker_units=float(sz[~maker].sum()),
                 all_units=float(sz.sum()),
                 placed=int(st["ACC"][s, E.A_PLACED]), rejects=int(st["ACC"][s, E.A_REJECT]),
                 spread_capture=wavg(sgn * (f["mid2"] / 2.0 - px)),
                 max_inv=float(st["ACC"][s, E.A_MAXQ]),
                 avg_inv=float(np.abs(pos[inside, s]).mean()) if inside.any() else np.nan,
                 win_days=int((perday[n] > 0).sum()), days=len(perday),
                 worst_day=float(perday[n].min()), best_day=float(perday[n].max()))
        for h in MARKOUT_S:
            r[f"mo{h}"] = wavg(sgn * (mid[np.clip(sec + h, 0, nsec - 1)] - px))
        r["fill_rate"] = r["units"] / r["placed"] if r["placed"] else np.nan
        r["net_per_fill"] = r["net"] / r["fills"] if r["fills"] else np.nan
        rows.append(r)
    summary = pd.DataFrame(rows).set_index("strategy")

    # accounting check: the final cash and inventory must equal what the fill list says
    ok = True
    for s in range(NS):
        f = fl[s]
        ok &= abs(-(f["side"].astype(float) * f["px"] * f["sz"]).sum() - st["ACC"][s, E.A_CASH]) < 1e-3
        ok &= abs((f["side"].astype(float) * f["sz"]).sum() - st["ACC"][s, E.A_Q]) < 1e-6
    return dict(idx=idx, valid=valid, mid=mid, pos=pos, gross=gross, net=net, perday=perday, summary=summary,
                inside=inside, day=day, acct_ok=bool(ok))


# ---------------------------------------------------------------------------------------------
# 3) CHARTS
# ---------------------------------------------------------------------------------------------
COLORS = {"Join": "#6b7280", "A-S": "#d97706", "GLFT": "#059669"}


def style(name):
    base = name.replace(" + OFI", "")
    return dict(color=COLORS[base], ls="--" if "OFI" in name else "-", lw=1.8)


def make_charts(st, fl, all_names, t0, nsec, R):
    names = main_names(all_names)
    summary, perday = R["summary"], R["perday"][main_names(all_names)]
    if len(perday) == 0:
        raise SystemExit(f"No day has a minute of usable market data inside TRADE_HOURS_UTC = {TRADE_HOURS_UTC}. "
                         "Hours are UTC: check them, or run with --allday to quote around the clock.")
    fig, ax = plt.subplots(2, 2, figsize=(14, 9))
    ax = ax.ravel()

    cum = perday.cumsum()
    for n in names:
        ax[0].plot(cum.index, cum[n], marker="o", ms=3.5, label=n, **style(n))
    ax[0].axhline(0, color="k", lw=0.6)
    ax[0].set_title("Total profit after fees, by day ($)")
    ax[0].tick_params(axis="x", rotation=45)
    h0, l0 = ax[0].get_legend_handles_labels()
    fig.legend(h0, l0, fontsize=9, ncol=6, loc="lower center", frameon=False)

    hs = [0] + list(MARKOUT_S)
    for n in names:
        ax[1].plot(hs, [summary.loc[n, "spread_capture"]] + [summary.loc[n, f"mo{h}"] for h in MARKOUT_S],
                   marker="o", ms=3.5, **style(n))
    ax[1].axhline(0, color="k", lw=0.6)
    ax[1].set_xscale("symlog", linthresh=1)
    ax[1].set_xlim(-0.6, 40)
    ax[1].set_xticks(hs)
    ax[1].set_xticklabels([str(h) for h in hs])
    ax[1].set_title("Where the price is after a fill (ticks per unit; above 0 = we won)")
    ax[1].set_xlabel("seconds after the fill")

    v = perday.T.values
    lim = max(np.abs(v).max(), 1)
    im = ax[2].imshow(v, cmap="RdYlGn", vmin=-lim, vmax=lim, aspect="auto")
    ax[2].set_xticks(range(perday.shape[0]))
    ax[2].set_xticklabels(perday.index, rotation=45, fontsize=8)
    ax[2].set_yticks(range(len(names)))
    ax[2].set_yticklabels(names, fontsize=8)
    for i in range(v.shape[0]):
        for j in range(v.shape[1]):
            ax[2].text(j, i, f"{v[i, j]:.0f}", ha="center", va="center", fontsize=7,
                       color="white" if abs(v[i, j]) > 0.65 * lim else "black")
    ax[2].set_title("Profit after fees per day ($)")

    # inventory over the last active day, for the three plain strategies
    d_last = perday.index[-1]
    mask = (R["day"].strftime("%m-%d") == d_last) & R["inside"]
    tt = R["idx"][mask]
    for n in ("Join", "A-S", "GLFT"):
        ax[3].step(tt, R["pos"][mask, all_names.index(n)], where="post", label=n, color=COLORS[n], lw=1.2)
    ax[3].axhline(0, color="k", lw=0.6)
    ax[3].set_title(f"Inventory during {d_last} (units; limit +-{QMAX})")
    ax[3].set_ylim(-QMAX - 1.5, QMAX + 2.5)
    ax[3].legend(fontsize=8, frameon=False, ncol=3, loc="upper center")
    ax[3].tick_params(axis="x", rotation=30)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    p1 = os.path.join(OUT_DIR, "mm_results.png")
    fig.savefig(p1, dpi=130)

    # zoom: the busiest 10 minutes of the A-S strategy on the last day
    s_as = all_names.index("A-S")
    f = fl[s_as]
    m = f["kind"] == 0
    fsec = ((f["ts"] - t0) // 10**9).astype(np.int64)
    in_day = np.zeros(len(fsec), bool)
    if len(fsec):
        in_day = np.isin(fsec, np.where(mask)[0])
    fig2 = None
    if in_day.any():
        cnt = np.bincount(fsec[in_day & m], minlength=nsec)
        roll = np.convolve(cnt, np.ones(600), mode="valid")
        cand = np.where(mask[:len(roll)])[0]
        a = int(cand[np.argmax(roll[cand])]) if len(cand) else int(np.argmax(roll))
        b = min(a + 600, nsec)
        xs = R["idx"][a:b]
        ref = np.nanmedian(st["BBP"][a:b])
        fig2, a2 = plt.subplots(figsize=(14, 6))
        a2.step(xs, st["BBP"][a:b] - ref, where="post", color="#2563eb", lw=1, label="market best bid")
        a2.step(xs, st["BAP"][a:b] - ref, where="post", color="#dc2626", lw=1, label="market best ask")
        qb, qa = st["QB"][s_as, a:b].astype(float), st["QA"][s_as, a:b].astype(float)
        qb[qb < 0], qa[qa < 0] = np.nan, np.nan
        a2.step(xs, qb - ref, where="post", color="#2563eb", lw=2.4, alpha=0.45, label="our A-S bid")
        a2.step(xs, qa - ref, where="post", color="#dc2626", lw=2.4, alpha=0.45, label="our A-S ask")
        sel = in_day & m & (fsec >= a) & (fsec < b)
        ft = pd.to_datetime(f["ts"][sel], utc=True)
        fp = f["px"][sel] - ref
        buy = f["side"][sel] > 0
        a2.scatter(ft[buy], fp[buy], marker="^", s=70, color="#1d4ed8", zorder=5, label="we bought")
        a2.scatter(ft[~buy], fp[~buy], marker="v", s=70, color="#b91c1c", zorder=5, label="we sold")
        a2.set_title(f"Ten busy minutes of the A-S strategy on {d_last}: our quotes (thick) vs the market (thin)")
        a2.set_ylabel("price in ticks from the start")
        a2.legend(fontsize=8, ncol=6, loc="upper center", bbox_to_anchor=(0.5, -0.08), frameon=False)
        fig2.tight_layout()
        fig2.savefig(os.path.join(OUT_DIR, "mm_zoom.png"), dpi=130)
    return fig, fig2


# ---------------------------------------------------------------------------------------------
# 4) REPORT (short lines so copy-paste does not break them)
# ---------------------------------------------------------------------------------------------
def fmt(x, nd=0, sign=False):
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"{x:+,.{nd}f}" if sign else f"{x:,.{nd}f}"


def report(st, all_names, R, done, secs, t0):
    names = main_names(all_names)
    S, perday = R["summary"], R["perday"][names]
    good, bad = int(st["MI"][E.M_GOOD]), int(st["MI"][E.M_BAD])
    cs, ca, ck = st["CAL_SIG"], st["CAL_A"], st["CAL_K"]
    L = ["=========== PASTE FROM HERE ===========",
         f"Records {done:,} in {secs:.1f}s | days {len(perday)} | accounting check: {'OK' if R['acct_ok'] else 'FAILED'}",
         f"Tick {TICK} = ${TICK_VALUE} | fee ${FEE_PER_FILL}/fill | latency {LATENCY_MS} ms | limit {QMAX}",
         f"Hours UTC {TRADE_HOURS_UTC} | skew {SKEW_TICKS} ticks | OFI z {OFI_Z}",
         f"Book reads: good {good:,}, crossed/empty {bad:,} ({bad / max(good + bad, 1):.1%})",
         f"Calibration (median): sigma {np.nanmedian(cs):.2f} ticks/sqrt(s), A {np.nanmedian(ca):.2f}/s, "
         f"k {np.nanmedian(ck):.2f}/tick",
         "",
         "MONEY ($)            net       gross      fees   fills  win-days  worst-day"]
    for n in names:
        r = S.loc[n]
        L.append(f"{n:<14s}{fmt(r.net, 0, True):>10s}{fmt(r.gross, 0, True):>12s}{fmt(r.fees):>10s}{int(r.fills):>8,d}"
                 f"{int(r.win_days):>6d}/{int(r.days):<3d}{fmt(r.worst_day, 0, True):>10s}")
    L += ["", f"A fee of ${FEE_PER_FILL} is {FEE_PER_FILL / TICK_VALUE:.2f} tick per fill: the numbers below must beat it.",
          "QUALITY (ticks per unit)  at-fill   +1s    +5s   +30s  avg|inv| max|inv|  fill%"]
    for n in names:
        r = S.loc[n]
        L.append(f"{n:<14s}{fmt(r.spread_capture, 2, True):>10s}{fmt(r.mo1, 2, True):>7s}{fmt(r.mo5, 2, True):>7s}"
                 f"{fmt(r.mo30, 2, True):>7s}{fmt(r.avg_inv, 1):>9s}{fmt(r.max_inv, 0):>8s}{r.fill_rate:>8.1%}")
    L += ["", "PROFIT PER DAY ($, after fees)"]
    cols = list(perday.index)
    for a in range(0, len(cols), 8):
        part = cols[a:a + 8]
        L.append(f"{'':<14s}" + "".join(f"{c:>8s}" for c in part))
        for n in names:
            L.append(f"{n:<14s}" + "".join(f"{perday.loc[c, n]:>+8.0f}" for c in part))
    if DECISION_SWEEP_MS:
        L += ["", "RE-QUOTE SPEED (how often the strategy may change its quotes)",
              "                    net $    fills  at-fill   +1s    +5s   avg|inv|"]
        rows = []
        for n in ("Join", "A-S"):
            rows.append((f"{n} {DECISION_MS:g} ms (base)", n))
            rows += [(f"{n} {d:g} ms", f"{n} dec {d:g}ms") for d in sorted(DECISION_SWEEP_MS, reverse=True)]
        for lab, n in rows:
            r = R["summary"].loc[n]
            L.append(f"{lab:<20s}{fmt(r.net, 0, True):>12s}{int(r.fills):>9,d}{fmt(r.spread_capture, 2, True):>8s}"
                     f"{fmt(r.mo1, 2, True):>7s}{fmt(r.mo5, 2, True):>7s}{fmt(r.avg_inv, 1):>9s}")
    L += ["", "WHAT IF THE FEE WERE LOWER? (net $ = gross - units x fee; big firms pay far less than retail)",
          f"{'':<14s}" + "".join(f"{'fee $' + format(f, 'g'):>13s}" for f in (0, 0.25, 0.5, 1.0))]
    for n in names:
        r = R["summary"].loc[n]
        L.append(f"{n:<14s}" + "".join(f"{fmt(r.gross - r.all_units * f, 0, True):>13s}" for f in (0, 0.25, 0.5, 1.0)))
    if LATENCY_SWEEP_MS:
        L += ["", "LATENCY CHECK (A-S only)   net $   fills  +5s ticks   (the edge should shrink as latency grows)"]
        for lab, n in [(f"{LATENCY_MS:g} ms (base)", "A-S")] + [(f"{x:g} ms", f"A-S lat {x:g}ms") for x in LATENCY_SWEEP_MS]:
            r = R["summary"].loc[n]
            L.append(f"{lab:<22s}{fmt(r.net, 0, True):>12s}{int(r.fills):>9,d}{fmt(r.mo5, 2, True):>11s}")
    L += ["", "Units flattened with a market order at the close: "
          + ", ".join(f"{n} {S.loc[n, 'taker_units']:,.0f}" for n in names),
          "Rejected orders (post-only): " + ", ".join(f"{n} {int(S.loc[n, 'rejects'])}" for n in names),
          "=========== PASTE UNTIL HERE ==========="]
    print("\n".join(L))


if __name__ == "__main__":
    path = E.data_path(FILE_PATH)
    st, fl, names, t0, nsec, done, secs = run_engine(path)
    if st["MI"][E.M_GOOD] + st["MI"][E.M_BAD] == 0:
        raise SystemExit("The file has no end-of-event markers (flag 128), so the book was never read. "
                         "Is this a Databento MBO file for one instrument, with the flags column included?")
    R = analyse(st, fl, names, t0, nsec)
    summary, perday = R["summary"], R["perday"]
    figs = make_charts(st, fl, names, t0, nsec, R)
    summary.to_csv(os.path.join(OUT_DIR, "mm_summary.csv"))
    perday.to_csv(os.path.join(OUT_DIR, "mm_daily.csv"))
    report(st, names, R, done, secs, t0)
    print(f"\nSaved in {OUT_DIR}: mm_results.png, mm_zoom.png, mm_summary.csv, mm_daily.csv")
    plt.show()
