// mm_tests - checks that the simulator does what it claims.
//   mm_tests                          hand-made event streams (queue rules, post-only, OFI sign, hash map, time formatting)
//   mm_tests --file x.mbo [--zst x.mbo.zst]   also: book vs a slow brute-force rebuild, accounting, no look-ahead, readers
#include <cstdio>
#include <cstring>
#include <map>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

#include "backtest.hpp"

using namespace mm;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond)                                                                              \
    do {                                                                                         \
        ++g_checks;                                                                              \
        if (!(cond)) {                                                                           \
            ++g_fail;                                                                            \
            std::printf("  FAILED  %s:%d  %s\n", __FILE__, __LINE__, #cond);                     \
        }                                                                                        \
    } while (0)
#define CHECK_MSG(cond, ...)                                                                     \
    do {                                                                                         \
        ++g_checks;                                                                              \
        if (!(cond)) {                                                                           \
            ++g_fail;                                                                            \
            std::printf("  FAILED  %s:%d  %s  ", __FILE__, __LINE__, #cond);                     \
            std::printf(__VA_ARGS__);                                                            \
            std::printf("\n");                                                                   \
        }                                                                                        \
    } while (0)

static const i64 TICK_FX = 250000000;                   // 0.25 in fixed point (1e-9)
static const i64 T0 = 1747058400LL * NS_PER_SEC;        // 2025-05-12 14:00:00 UTC

struct Row {
    double ms;
    char action, side;
    i64 price;
    u32 size;
    u64 oid;
    bool last;
};

static Msg mk(const Row& r) {
    Msg m{};
    m.ts = T0 + (i64)(r.ms * 1e6);
    m.action = (u8)r.action;
    m.side = (u8)r.side;
    m.px = r.price * TICK_FX;
    m.sz = r.size;
    m.oid = r.oid;
    m.flags = r.last ? 128 : 0;
    m.inst = 1;
    return m;
}

static void feed(Engine& e, const std::vector<Row>& rows, size_t a, size_t b) {
    for (size_t i = a; i < b; ++i) e.on_msg(mk(rows[i]));
}

static Config cfg_all(double decision_ms = 0, double ofi_fast_ms = 1000, double ofi_slow_s = 600) {
    return make_config(decision_ms, 60, 600, ofi_fast_ms, ofi_slow_s, true);
}

static Engine make_engine(const std::vector<Params>& P, const Config& c) { return Engine(P, c, T0, 100, TICK_FX, 1, true); }

static void test_step_by_step() {
    std::printf("queue rules, step by step\n");
    std::vector<Params> P = {strategy("join", JOIN, 0.05, 10, 5, 0, 1, 0.0), strategy("limit1", JOIN, 0.05, 10, 1, 0, 1, 0.0),
                             strategy("slow", JOIN, 0.05, 10, 5, 0, 1, 50.0)};
    std::vector<Row> rows = {
        {1, 'A', 'B', 100, 2, 1, true}, {2, 'A', 'A', 101, 5, 2, true}, {3, 'A', 'B', 100, 3, 3, true},
        {4, 'C', 'B', 100, 1, 1, true},
        {5, 'T', 'A', 100, 2, 0, false}, {5, 'C', 'B', 100, 1, 1, false}, {5, 'C', 'B', 100, 1, 3, true},
        {6, 'A', 'A', 101, 1, 4, true},
        {7, 'T', 'A', 100, 1, 0, false}, {7, 'C', 'B', 100, 1, 3, true},
        {8, 'T', 'B', 101, 6, 0, false}, {8, 'C', 'A', 101, 5, 2, false}, {8, 'C', 'A', 101, 1, 4, true},
    };
    Engine e = make_engine(P, cfg_all());
    feed(e, rows, 0, 4);
    CHECK(e.S[0].o[0].act == 1 && e.S[0].o[0].px == 100);
    CHECK_MSG(e.S[0].o[0].ahead == 1, "order 1 cancelled 1 of its 2 ahead of us (got %lld)", (long long)e.S[0].o[0].ahead);
    CHECK(e.S[0].o[1].ahead == 5);
    feed(e, rows, 4, 7);
    CHECK_MSG(e.S[0].acc.q == 1 && e.S[0].acc.cash == -100, "1 contract bought at 100 after the queue ahead was used up");
    CHECK(e.S[0].fills.size() == 1 && e.S[0].fills[0].px == 100);
    CHECK_MSG(e.S[2].acc.nfill == 0, "the 50 ms strategy's order had not reached the exchange yet");
    feed(e, rows, 7, 10);
    CHECK_MSG(e.S[0].acc.q == 1, "a 1-lot trade with 2 ahead of us must not fill us");
    CHECK(e.S[0].o[0].ahead == 1);
    CHECK_MSG(e.S[1].o[0].act == 0 && e.S[1].ds[0] == -1, "inventory limit 1: no new bid after buying 1");
    feed(e, rows, 10, rows.size());
    CHECK_MSG(e.S[0].acc.q == 0 && e.S[0].acc.cash == 1, "sold 1 at 101: +1 tick round trip");
    CHECK(e.S[1].acc.q == 0 && e.S[1].acc.cash == 1);
}

static void test_modify_priority() {
    std::printf("a modify keeps or loses queue priority\n");
    std::vector<Params> P = {strategy("join", JOIN, 0.05, 10, 5, 0, 1, 0.0)};
    std::vector<Row> rows = {
        {1, 'A', 'B', 100, 2, 1, true}, {2, 'A', 'A', 102, 5, 2, true},
        {3, 'A', 'B', 100, 4, 3, true},          // behind us
        {4, 'M', 'B', 100, 1, 1, true},          // modify DOWN in place: keeps priority, 1 left ahead
        {5, 'M', 'B', 100, 3, 1, true},          // modify UP: loses priority, goes behind us -> 0 ahead
        {6, 'T', 'A', 100, 1, 0, false}, {6, 'C', 'B', 100, 1, 3, true},
    };
    Engine e = make_engine(P, cfg_all());
    feed(e, rows, 0, 4);
    CHECK(e.S[0].o[0].ahead == 1);
    feed(e, rows, 4, 5);
    CHECK(e.S[0].o[0].ahead == 0);
    CHECK(e.bid_lvl()[100] == 7);
    feed(e, rows, 5, rows.size());
    CHECK_MSG(e.S[0].acc.q == 1, "first in the queue: the next 1-lot sell fills us");
}

static void test_trade_through_and_post_only() {
    std::printf("trade-through fills us first; post-only rejects a crossed order\n");
    {
        std::vector<Params> P = {strategy("slow", JOIN, 0.05, 10, 5, 0, 1, 2.5)};
        std::vector<Row> rows = {
            {1, 'A', 'B', 100, 1, 1, true}, {2, 'A', 'A', 101, 1, 2, true},   // we decide at 2 ms: bid 100 / ask 101
            {3, 'A', 'A', 100, 1, 3, true},          // ask drops to 100 before our bid arrives (at 4.5 ms)
            {5, 'A', 'B', 99, 1, 4, true},           // our bid arrives now: 100 >= best ask 100 -> rejected (post-only)
        };
        Engine e = make_engine(P, cfg_all());
        feed(e, rows, 0, rows.size());
        CHECK(e.S[0].acc.reject >= 1);
    }
    {
        std::vector<Params> P = {strategy("never", JOIN, 0.05, 10, 5, 0, 1, 1e6)};     // its own orders never arrive
        Engine e = make_engine(P, cfg_all());
        std::vector<Row> rows = {{1, 'A', 'B', 104, 1, 1, true}, {2, 'A', 'A', 106, 1, 2, true}};
        feed(e, rows, 0, rows.size());
        e.S[0].o[1] = VOrder{1, 105, 1, 0, 1000000000, 0};   // put a virtual ask at 105 by hand (better than the real 106)
        e.S[0].ds[1] = 105;
        std::vector<Row> r2 = {{3, 'T', 'B', 106, 1, 0, false}, {3, 'C', 'A', 106, 1, 2, true}};
        feed(e, r2, 0, r2.size());
        CHECK(e.S[0].acc.q == -1 && e.S[0].acc.cash == 105);
    }
}

static void ofi_scenario(bool bid_burst, std::pair<i64, i64>& quiet, std::pair<i64, i64>& after, Engine*& out_e) {
    std::vector<Row> rows = {{1, 'A', 'B', 100, 10, 1, true}, {2, 'A', 'A', 101, 10, 2, true}};
    double ms = 3.0;
    for (int i = 0; i < 300; ++i) {                      // noise: +1 then -1 contract at the touch
        rows.push_back({ms, 'A', 'B', 100, 1, (u64)(1000 + i), true});
        rows.push_back({ms + 1, 'C', 'B', 100, 1, (u64)(1000 + i), true});
        ms += 2;
    }
    std::vector<Params> P = {strategy("join", JOIN, 0.05, 10, 5, 2.0, 1, 0.0)};
    out_e = new Engine(make_engine(P, cfg_all(0, 20, 0.2)));
    feed(*out_e, rows, 0, rows.size());
    quiet = {out_e->S[0].ds[0], out_e->S[0].ds[1]};
    std::vector<Row> burst;
    for (int j = 0; j < 3; ++j) burst.push_back({ms + j, 'A', bid_burst ? 'B' : 'A', bid_burst ? 100 : 101, 30, (u64)(5000 + j), true});
    feed(*out_e, burst, 0, burst.size());
    after = {out_e->S[0].ds[0], out_e->S[0].ds[1]};
}

static void test_ofi_defense_sign() {
    std::printf("OFI defense pulls the side that is about to be run over\n");
    std::pair<i64, i64> quiet, after;
    Engine* e = nullptr;
    ofi_scenario(true, quiet, after, e);               // buy pressure: pull the ASK
    CHECK_MSG(quiet.first == 100 && quiet.second == 101, "noise alone must not pull quotes: %lld/%lld", (long long)quiet.first, (long long)quiet.second);
    CHECK_MSG(after.first == 100 && after.second == -1, "after a bid burst the ask must be pulled: %lld/%lld", (long long)after.first, (long long)after.second);
    CHECK(e->S[0].o[1].act == 0 && e->S[0].o[0].act == 1);
    delete e;
    ofi_scenario(false, quiet, after, e);              // sell pressure: pull the BID
    CHECK(quiet.first == 100 && quiet.second == 101);
    CHECK_MSG(after.first == -1 && after.second == 101, "after an ask burst the bid must be pulled: %lld/%lld", (long long)after.first, (long long)after.second);
    delete e;
}

static void test_order_map() {
    std::printf("order hash map vs std::unordered_map (random insert / erase / find)\n");
    OrderMap m(16);
    std::unordered_map<u64, std::pair<i64, i64>> ref;
    std::mt19937_64 rng(7);
    bool same = true;
    for (int i = 0; i < 400000 && same; ++i) {
        u64 k = rng() % 5000;                              // few keys: many collisions, many deletes
        int op = (int)(rng() % 3);
        if (op == 0) {
            i64 v = (i64)rng(), p = (i64)rng();
            m.put(k, v, p);
            ref[k] = {v, p};
        } else if (op == 1) {
            m.erase(k);
            ref.erase(k);
        } else {
            OrderRec* r = m.find(k);
            auto it = ref.find(k);
            if ((r != nullptr) != (it != ref.end())) same = false;
            else if (r && (r->v != it->second.first || r->prio != it->second.second)) same = false;
        }
        if (m.size() != ref.size()) same = false;
    }
    for (auto& kv : ref) {
        OrderRec* r = m.find(kv.first);
        if (!r || r->v != kv.second.first) same = false;
    }
    CHECK_MSG(same, "the hash map disagrees with the reference");
    m.clear();
    CHECK(m.size() == 0 && m.find(1) == nullptr);
}

static void test_time_format() {
    std::printf("time formatting\n");
    CHECK(fmt_time(T0, true, 3) == "2025-05-12 14:00:00.000");
    CHECK(fmt_time(T0 + 123456789, false, 3) == "14:00:00.123");
    CHECK(fmt_time(T0 + 3 * 86400LL * NS_PER_SEC, true, 0).substr(0, 10) == "2025-05-15");
    CHECK(fmt_day(days_from_civil(2025, 5, 12)) == "05-12");
    CHECK(floordiv(-1, 1000000000) == -1 && floordiv(1, 1000000000) == 0 && floormod(-1, 86400) == 86399);
}

// ---------------------------------------------------------------------------------------------
// tests that need a data file
// ---------------------------------------------------------------------------------------------
struct Loaded {
    std::vector<Msg> msgs;
    DbnInfo info;
};

static bool load_all(const std::string& path, Loaded& L) {
    DbnReader rd;
    std::string err;
    if (!rd.open(path, err)) {
        std::printf("  cannot open %s: %s\n", path.c_str(), err.c_str());
        return false;
    }
    L.info = rd.info();
    std::vector<Msg> buf(1 << 16);
    for (;;) {
        size_t n = rd.read(buf.data(), buf.size());
        if (!n) break;
        L.msgs.insert(L.msgs.end(), buf.begin(), buf.begin() + (long)n);
    }
    return true;
}

static i64 t0_of(const Loaded& L) {
    i64 first = INT64_MAX;
    for (size_t i = 0; i < std::min<size_t>(L.msgs.size(), 200000); ++i) first = std::min(first, L.msgs[i].ts);
    return floordiv(std::min((i64)L.info.start_ns, first), NS_PER_SEC) * NS_PER_SEC;
}

static void test_book_vs_brute_force(const Loaded& L) {
    std::printf("order book vs a slow brute-force rebuild (checked at the end of every exchange event)\n");
    TargetPick tp = pick_target(L.msgs.data(), std::min<size_t>(L.msgs.size(), 500000));
    std::vector<Params> P = {strategy("join", JOIN)};
    i64 t0 = t0_of(L);
    i64 nsec = floordiv((i64)L.info.end_ns - t0, NS_PER_SEC) + 2;
    Engine e(P, make_config(100, 60, 600, 1000, 600, true), t0, nsec, TICK_FX, (i64)tp.id, false);
    struct O { char side; i64 tick; i64 size; };
    std::unordered_map<u64, O> orders;
    std::map<i64, i64> lv[2];                                     // 0 = bid, 1 = ask: tick -> size
    i64 compared = 0, mismatches = 0;
    for (const Msg& m : L.msgs) {
        e.on_msg(m);
        if ((i64)m.inst != (i64)tp.id) continue;
        const char a = (char)m.action, s = (char)m.side;
        if (a == 'R') {
            orders.clear();
            lv[0].clear();
            lv[1].clear();
            continue;
        }
        if ((a == 'C' || a == 'M' || a == 'A') && orders.count(m.oid)) {
            O o = orders[m.oid];
            i64 rem = a == 'C' ? std::min<i64>(m.sz, o.size) : o.size;
            int sd = o.side == 'B' ? 0 : 1;
            lv[sd][o.tick] -= rem;
            if (lv[sd][o.tick] <= 0) lv[sd].erase(o.tick);
            if (a == 'C' && o.size - rem > 0) orders[m.oid].size = o.size - rem;
            else orders.erase(m.oid);
        }
        if ((a == 'A' || a == 'M') && m.sz > 0 && m.px != UNDEF_PRICE && (s == 'B' || s == 'A')) {
            i64 tk = floordiv(m.px, TICK_FX);
            orders[m.oid] = O{s, tk, (i64)m.sz};
            lv[s == 'B' ? 0 : 1][tk] += m.sz;
        }
        if ((m.flags & 128) && !(m.flags & 32) && !lv[0].empty() && !lv[1].empty()) {
            i64 bb = lv[0].rbegin()->first, ba = lv[1].begin()->first;
            if (bb < ba) {
                ++compared;
                if (e.bb != bb || e.ba != ba || e.bid_lvl()[(size_t)bb] != lv[0][bb] || e.ask_lvl()[(size_t)ba] != lv[1][ba]) ++mismatches;
            }
        }
    }
    std::printf("  book states compared: %lld | mismatches: %lld\n", (long long)compared, (long long)mismatches);
    CHECK(compared > 1000);
    CHECK(mismatches == 0);
}

static void test_accounting(const Loaded& L) {
    std::printf("accounting and risk limits, all strategy types at once (zero latency)\n");
    const double LIMIT = 3;
    std::vector<Params> P;
    int idx = 0;
    for (Kind k : {JOIN, AS, GLFT})
        for (double z : {0.0, 2.0}) P.push_back(strategy("s" + std::to_string(idx++), k, 0.05, 10, LIMIT, z, 1, 0.0, 1, 10, k == JOIN ? -1.0 : 0.5));
    TargetPick tp = pick_target(L.msgs.data(), std::min<size_t>(L.msgs.size(), 500000));
    i64 t0 = t0_of(L);
    i64 nsec = floordiv((i64)L.info.end_ns - t0, NS_PER_SEC) + 2;
    Engine e(P, make_config(100, 60, 600, 1000, 600, true), t0, nsec, TICK_FX, (i64)tp.id, true);
    for (const Msg& m : L.msgs) e.on_msg(m);
    for (size_t s = 0; s < P.size(); ++s) {
        const Strat& st = e.S[s];
        double c = 0, q = 0;
        i64 maxsz = 0;
        for (const Fill& f : st.fills) {
            c -= (double)f.side * f.px * f.sz;
            q += (double)f.side * f.sz;
            maxsz = std::max<i64>(maxsz, f.sz);
        }
        CHECK_MSG(st.fills.size() > 0, "strategy %zu: no fills", s);
        CHECK_MSG(std::fabs(c - (double)st.acc.cash) < 1e-6, "strategy %zu: cash does not match the fills", s);
        CHECK_MSG(std::fabs(q - (double)st.acc.q) < 1e-9, "strategy %zu: inventory does not match the fills", s);
        CHECK_MSG((double)st.acc.maxq <= LIMIT, "strategy %zu: inventory %lld passed the limit", s, (long long)st.acc.maxq);
        CHECK(maxsz <= 1);
        std::printf("  strategy %zu: %7zu fills | max |inventory| %lld (limit %g)\n", s, st.fills.size(), (long long)st.acc.maxq, LIMIT);
    }
}

static void test_no_lookahead(const Loaded& L) {
    std::printf("no look-ahead: the first 55%% of the file gives the same fills with or without the rest\n");
    std::vector<Params> P;
    for (Kind k : {JOIN, AS, GLFT})
        for (double z : {0.0, 2.0}) P.push_back(strategy("s", k, 0.05, 10, 5, z, 1, 1.0, 1, 10, k == JOIN ? -1.0 : 0.5));
    TargetPick tp = pick_target(L.msgs.data(), std::min<size_t>(L.msgs.size(), 200000));
    i64 t0 = t0_of(L);
    i64 nsec = floordiv((i64)L.info.end_ns - t0, NS_PER_SEC) + 2;
    Engine full(P, make_config(100, 60, 600, 1000, 600, true), t0, nsec, TICK_FX, (i64)tp.id, false);
    Engine part(P, make_config(100, 60, 600, 1000, 600, true), t0, nsec, TICK_FX, (i64)tp.id, false);
    size_t cut = (size_t)((double)L.msgs.size() * 0.55);
    for (size_t i = 0; i < L.msgs.size(); ++i) {
        full.on_msg(L.msgs[i]);
        if (i < cut) part.on_msg(L.msgs[i]);
    }
    for (size_t s = 0; s < P.size(); ++s) {
        size_t m = part.S[s].fills.size();
        bool same = m <= full.S[s].fills.size();
        for (size_t i = 0; same && i < m; ++i) {
            const Fill &a = full.S[s].fills[i], &b = part.S[s].fills[i];
            same = a.ts == b.ts && a.px == b.px && a.sz == b.sz && a.side == b.side && a.kind == b.kind;
        }
        CHECK_MSG(same, "strategy %zu: fills in the prefix run differ from the full run", s);
        CHECK_MSG(m > 50, "too few fills to be a meaningful test (%zu)", m);
        std::printf("  strategy %zu: fills in prefix run %6zu (full run %zu) -> %s\n", s, m, full.S[s].fills.size(), same ? "identical" : "DIFFERENT");
    }
}

static void test_readers(const Loaded& plain, const std::string& zst) {
    std::printf("readers: plain DBN and zstd DBN give the same records\n");
    Loaded z;
    if (!load_all(zst, z)) {
        CHECK(false);
        return;
    }
    CHECK(z.info.compressed && !plain.info.compressed);
    CHECK(z.msgs.size() == plain.msgs.size());
    bool same = z.msgs.size() == plain.msgs.size();
    for (size_t i = 0; same && i < z.msgs.size(); ++i)
        same = z.msgs[i].ts == plain.msgs[i].ts && z.msgs[i].oid == plain.msgs[i].oid && z.msgs[i].px == plain.msgs[i].px &&
               z.msgs[i].sz == plain.msgs[i].sz && z.msgs[i].action == plain.msgs[i].action && z.msgs[i].side == plain.msgs[i].side &&
               z.msgs[i].flags == plain.msgs[i].flags && z.msgs[i].inst == plain.msgs[i].inst;
    CHECK_MSG(same, "records differ between the plain and the compressed reader");
    std::printf("  %zu records, schema code %u (0 = MBO), DBN v%d\n", plain.msgs.size(), plain.info.schema, plain.info.version);
}

static void speed_report(const Loaded& L) {
    TargetPick tp = pick_target(L.msgs.data(), std::min<size_t>(L.msgs.size(), 500000));
    std::vector<Params> P;
    for (Kind k : {JOIN, AS, GLFT})
        for (double z : {0.0, 2.0}) P.push_back(strategy("s", k, 0.05, 10, 5, z, 1, 1.0, 1, 10, k == JOIN ? -1.0 : 0.5));
    i64 t0 = t0_of(L);
    i64 nsec = floordiv((i64)L.info.end_ns - t0, NS_PER_SEC) + 2;
    Engine e(P, make_config(100, 60, 600, 1000, 600, true), t0, nsec, TICK_FX, (i64)tp.id, false);
    double a = now_sec();
    for (const Msg& m : L.msgs) e.on_msg(m);
    double el = now_sec() - a;
    std::printf("speed (information only): %zu records, 6 strategies, %.3f s = %.2f M records/s\n", L.msgs.size(), el, (double)L.msgs.size() / el / 1e6);
}

int main(int argc, char** argv) {
    std::string file, zst;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--file") && i + 1 < argc) file = argv[++i];
        else if (!std::strcmp(argv[i], "--zst") && i + 1 < argc) zst = argv[++i];
    }
    test_time_format();
    test_order_map();
    test_step_by_step();
    test_modify_priority();
    test_trade_through_and_post_only();
    test_ofi_defense_sign();
    if (!file.empty()) {
        Loaded L;
        if (!load_all(file, L)) return 2;
        test_book_vs_brute_force(L);
        test_accounting(L);
        test_no_lookahead(L);
        if (!zst.empty()) test_readers(L, zst);
        speed_report(L);
    } else {
        std::printf("(no --file given: the data-file tests were skipped)\n");
    }
    std::printf("\n%s: %d checks, %d failed\n", g_fail ? "TESTS FAILED" : "ALL TESTS PASSED", g_checks, g_fail);
    return g_fail ? 1 : 0;
}
